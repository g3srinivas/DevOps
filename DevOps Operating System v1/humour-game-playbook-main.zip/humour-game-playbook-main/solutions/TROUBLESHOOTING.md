# Troubleshooting Guide: ALB Ingress Issues

Quick reference for common problems and solutions.

---

## 🔴 Issue: Ingress Has No ADDRESS

**Symptom:**
```bash
$ kubectl get ingress h-game -n h-game
NAME     CLASS   HOSTS   ADDRESS   PORTS   AGE
h-game   alb     *                 80      5m
```

**Diagnosis:**
```bash
# Check Ingress events
kubectl describe ingress h-game -n h-game | grep -A 10 "Events:"

# Check controller logs
kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50 | grep -i error
```

**Common Causes & Fixes:**

### 1. OIDC Provider Missing
**Error:** `No OpenIDConnect provider found`

**Fix:**
```bash
# Add to iam.tf
data "tls_certificate" "eks" {
  url = aws_eks_cluster.main.identity[0].oidc[0].issuer
}

resource "aws_iam_openid_connect_provider" "eks" {
  client_id_list  = ["sts.amazonaws.com"]
  thumbprint_list = [data.tls_certificate.eks.certificates[0].sha1_fingerprint]
  url             = aws_eks_cluster.main.identity[0].oidc[0].issuer
}

# Apply
terraform apply -target=aws_iam_openid_connect_provider.eks

# Restart controller
kubectl rollout restart deployment aws-load-balancer-controller -n kube-system
```

### 2. Security Group Not Found
**Error:** `Security group sg-xxx not found`

**Fix:**
```bash
# Verify security group exists
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform output alb_security_group_id

# Update Ingress with correct SG
kubectl edit ingress h-game -n h-game
# Fix the security-groups annotation
```

### 3. Subnet Not Found
**Error:** `Subnet subnet-xxx not found`

**Fix:**
```bash
# Verify subnets
terraform output public_subnet_ids

# Update Ingress with correct subnets
kubectl edit ingress h-game -n h-game
# Fix the subnets annotation
```

### 4. IAM Permission Missing
**Error:** `DescribeListenerAttributes permission denied`

**Fix:**
```bash
# Add to iam.tf in aws_iam_policy.aws_load_balancer_controller:
"elasticloadbalancing:DescribeListenerAttributes",

# Apply
terraform apply -target=aws_iam_policy.aws_load_balancer_controller

# Restart controller
kubectl rollout restart deployment aws-load-balancer-controller -n kube-system
```

---

## 🔴 Issue: Targets Not Registering

**Symptom:**
```bash
$ aws elbv2 describe-target-health --target-group-arn $TG_ARN
{
  "TargetHealthDescriptions": []
}
```

**Diagnosis:**
```bash
# Check target groups
aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `k8s-hgame`)].{Name:TargetGroupName,ARN:TargetGroupArn}'

# Check controller logs
kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50
```

**Fixes:**

### 1. Security Group Rules Missing
```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform apply -target=aws_security_group_rule.alb_to_eks_managed_nodes_backend \
  -target=aws_security_group_rule.alb_to_eks_managed_nodes_frontend
```

### 2. Pods Not Running
```bash
kubectl get pods -n h-game
kubectl describe pod <pod-name> -n h-game
```

### 3. Service Type Wrong
```bash
# Should be ClusterIP (not NodePort for Ingress)
kubectl get svc backend-service -n h-game -o jsonpath='{.spec.type}'
# Should show: ClusterIP
```

---

## 🔴 Issue: Targets Unhealthy

**Symptom:**
```bash
$ aws elbv2 describe-target-health --target-group-arn $TG_ARN
{
  "State": "unhealthy",
  "Reason": "Target.Timeout"
}
```

**Diagnosis:**
```bash
# Check security group rules
NODE_SG=$(aws ec2 describe-instances \
  --filters "Name=tag:eks:nodegroup-name,Values=h-game-nodes" \
  "Name=instance-state-name,Values=running" \
  --query 'Reservations[0].Instances[0].SecurityGroups[0].GroupId' \
  --output text)

aws ec2 describe-security-groups --group-ids "$NODE_SG" \
  --query 'SecurityGroups[0].IpPermissions[?FromPort==`3001` || FromPort==`80`]'
```

**Fixes:**

### 1. Security Group Rule Missing
```bash
# Apply security group rules
terraform apply -target=aws_security_group_rule.alb_to_eks_managed_nodes_backend \
  -target=aws_security_group_rule.alb_to_eks_managed_nodes_frontend
```

### 2. Health Endpoint Not Working
```bash
# Test from pod
kubectl exec -n h-game <pod-name> -- curl -s http://localhost:3001/health
# Backend should return: {"status":"healthy",...}

kubectl exec -n h-game <pod-name> -- curl -s http://localhost:80/health
# Frontend should return: healthy
```

### 3. Wrong Health Check Path
```bash
# Verify health check path in Ingress
kubectl get ingress h-game -n h-game -o yaml | grep healthcheck-path
# Should be: /health

# Verify endpoint exists
curl http://$ALB_URL/health
```

---

## 🔴 Issue: Frontend Timeout (504)

**Symptom:** Frontend shows 504 Gateway Timeout, backend works

**Diagnosis:**
```bash
# Check frontend target health
FRONTEND_TG=$(aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `frontend`)].TargetGroupArn' \
  --output text | head -1)

aws elbv2 describe-target-health --target-group-arn "$FRONTEND_TG"
```

**Fix:**
```bash
# Add security group rule for port 80
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform apply -target=aws_security_group_rule.alb_to_eks_managed_nodes_frontend

# Wait 60 seconds
sleep 60

# Check again
aws elbv2 describe-target-health --target-group-arn "$FRONTEND_TG"
```

---

## 🔴 Issue: "relation users does not exist" (500 Error)

**Symptom:** Game start returns 500 error

**Diagnosis:**
```bash
kubectl logs -n h-game -l app=backend --tail=50 | grep -i "relation\|users"
```

**Fix:**
```bash
# Run database migration
kubectl apply -f k8s/postgres-migration-configmap.yaml
kubectl apply -f k8s/postgres-migration-job.yaml

# Watch migration
kubectl logs -f job/postgres-migration -n h-game

# Verify
kubectl get job postgres-migration -n h-game
# Should show: COMPLETIONS 1/1
```

---

## 🔴 Issue: Webhook Timeout

**Symptom:**
```
Error: failed calling webhook "mtargetgroupbinding.elbv2.k8s.aws": context deadline exceeded
```

**Fix:**
```bash
# Delete broken webhook configs
kubectl delete validatingwebhookconfigurations aws-load-balancer-webhook 2>/dev/null || true
kubectl delete mutatingwebhookconfigurations aws-load-balancer-webhook 2>/dev/null || true

# Restart controller
kubectl delete pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller

# Wait 45 seconds
sleep 45

# Verify
kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller
```

---

## 🔴 Issue: Wrong Routing (404 on /api)

**Symptom:** `/api` endpoints return 404

**Diagnosis:**
```bash
# Check path order
kubectl get ingress h-game -n h-game -o yaml | grep -A 30 "paths:"
```

**Fix:**
Path order matters! Specific paths must come before catch-all:

**✅ Correct:**
```yaml
paths:
- path: /api        # First
- path: /health     # Second
- path: /           # Last (catch-all)
```

**❌ Wrong:**
```yaml
paths:
- path: /           # Wrong! Catches everything first
- path: /api        # Never reached
```

---

## 🔴 Issue: Controller Pods Crashing

**Symptom:**
```bash
$ kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller
NAME                                            READY   STATUS    RESTARTS   AGE
aws-load-balancer-controller-xxx               0/1     CrashLoopBackOff   5          10m
```

**Diagnosis:**
```bash
# Check logs
kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50

# Check service account
kubectl get sa aws-load-balancer-controller -n kube-system
kubectl describe sa aws-load-balancer-controller -n kube-system
```

**Fixes:**

### 1. IAM Role Not Attached
```bash
# Check annotation
kubectl get sa aws-load-balancer-controller -n kube-system \
  -o jsonpath='{.metadata.annotations.eks\.amazonaws\.com/role-arn}'

# If empty, create service account with role (see main guide)
```

### 2. OIDC Provider Missing
```bash
# Check OIDC provider
aws eks describe-cluster --name h-game-prod --query "cluster.identity.oidc.issuer" --output text

# Create if missing (see main guide)
```

---

## 🔴 Issue: ALB Not Accessible

**Symptom:** Can't reach ALB URL, connection timeout

**Diagnosis:**
```bash
# Check ALB status
ALB_DNS=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
aws elbv2 describe-load-balancers \
  --query "LoadBalancers[?DNSName=='$ALB_DNS'].State.Code" \
  --output text
# Should be: active

# Check security group
ALB_SG=$(cd "/Users/mac/Desktop/devops playbook/h-game-terraform" && terraform output -raw alb_security_group_id)
aws ec2 describe-security-groups --group-ids "$ALB_SG" \
  --query 'SecurityGroups[0].IpPermissions[?FromPort==`80`]'
```

**Fixes:**

### 1. ALB Still Provisioning
Wait 2-5 minutes after Ingress creation.

### 2. Security Group Blocking
Verify ALB security group allows HTTP (port 80) from `0.0.0.0/0`.

---

## 🟡 Issue: Slow Response Times

**Symptom:** Requests are slow but working

**Possible Causes:**
- Health checks taking too long
- Targets in different AZs
- Security group rules not optimized

**Fixes:**
```bash
# Optimize health check intervals
kubectl edit ingress h-game -n h-game
# Reduce healthcheck-interval-seconds to 10
# Reduce healthcheck-timeout-seconds to 5
```

---

## Quick Diagnostic Commands

```bash
# Get ALB URL
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

# Check Ingress status
kubectl describe ingress h-game -n h-game

# Check controller logs
kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50

# Check target health
TG_ARN=$(aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `k8s-hgame`)].TargetGroupArn' \
  --output text | head -1)
aws elbv2 describe-target-health --target-group-arn "$TG_ARN"

# Check pods
kubectl get pods -n h-game -o wide

# Check services
kubectl get svc -n h-game

# Test endpoints
curl -v http://$ALB_URL/health
curl -v http://$ALB_URL/api
```

---

**Still stuck?** Check the full guide: `ALB_INGRESS_GUIDE.md`

