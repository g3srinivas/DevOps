# Troubleshooting Guide

## Backend Pods Crashing - Database and Redis Connection Issues

### Problem Summary

Backend pods were crashing because they couldn't find the database: the backend code was looking for a service named `postgres`, but the actual Kubernetes service was named `postgres-service`, causing DNS resolution failures with `getaddrinfo ENOTFOUND postgres`. We fixed the database connection by updating the backend deployment to set `DB_HOST=postgres-service` and adding database environment variables that reference the postgres-secret. After fixing the database, the backend still failed because Redis wasn't deployed yet - the backend application requires both PostgreSQL and Redis to start successfully. We fixed it by deploying Redis (creating `redis-deployment.yaml` with a Service named `redis`) and adding `REDIS_HOST=redis` and `REDIS_PORT=6379` environment variables to the backend deployment, after which the backend pods started successfully.

### Symptoms
- Backend pods in `CrashLoopBackOff` status
- Logs showing: `getaddrinfo ENOTFOUND postgres`
- Logs showing: `getaddrinfo ENOTFOUND redis`
- Pods restarting repeatedly

### Root Causes
1. **Database Service Name Mismatch**: Backend expected `postgres` but service was `postgres-service`
2. **Missing Database Environment Variables**: Backend deployment didn't have DB connection env vars
3. **Redis Not Deployed**: Backend requires Redis but it wasn't deployed
4. **Missing Redis Environment Variables**: Backend deployment didn't have Redis connection env vars

### Solutions Applied
1. Updated `backend-deployment.yaml` to add:
   - `DB_HOST=postgres-service`
   - `DB_PORT=5432`
   - `DB_NAME`, `DB_USER`, `DB_PASSWORD` from `postgres-secret`
2. Created `redis-deployment.yaml` with Redis Deployment and Service
3. Added to `backend-deployment.yaml`:
   - `REDIS_HOST=redis`
   - `REDIS_PORT=6379`
4. Applied updated deployments: `kubectl apply -f k8s/backend-deployment.yaml`

### Verification
```bash
export KUBECONFIG=~/.kube/microk8s-config
kubectl get pods -n h-game -l app=backend
kubectl logs -l app=backend -n h-game --tail=200 | grep -i "redis\|database\|connected"
```

Expected output should show:
- `✅ Database connected successfully!`
- `✅ Redis connected successfully!`
- Pods in `Running` status with `1/1` ready

