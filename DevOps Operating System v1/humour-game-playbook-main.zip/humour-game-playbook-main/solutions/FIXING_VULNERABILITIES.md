# How to Fix Vulnerabilities Found by Trivy

When Trivy finds CRITICAL or HIGH severity vulnerabilities, here's how to fix them.

## Step 1: View the Vulnerabilities

### In GitHub:
1. Go to your repository → **Security** tab
2. Click **Code scanning alerts**
3. Review the vulnerabilities found

### In Workflow Logs:
1. Go to **Actions** → Your workflow run
2. Click on the **Scan backend/frontend image with Trivy** step
3. Review the detailed output

## Step 2: Understand the Vulnerability Types

### Common Types:

1. **Base Image Vulnerabilities**
   - Your Docker image uses an outdated base image (e.g., `node:18` → needs update)
   - **Fix:** Update to a newer base image version

2. **Package Vulnerabilities**
   - Outdated packages in your application (npm packages, system packages)
   - **Fix:** Update packages to patched versions

3. **OS Package Vulnerabilities**
   - Vulnerabilities in OS-level packages (apt, apk packages)
   - **Fix:** Update base image or run package updates in Dockerfile

## Step 3: Fix Base Image Vulnerabilities

### Example: Updating Node.js Base Image

**Before (vulnerable):**
```dockerfile
FROM node:18-alpine
```

**After (fixed):**
```dockerfile
FROM node:20-alpine  # Use latest LTS version
# Or use specific patched version
FROM node:18.20.4-alpine
```

### How to Find Latest Versions:
```bash
# Check Docker Hub for latest tags
# https://hub.docker.com/_/node

# Or use specific version with security patches
FROM node:18.20.4-alpine
```

## Step 4: Fix Package Vulnerabilities

### For npm/Node.js Projects:

**1. Update package.json:**
```bash
# Check for outdated packages
npm outdated

# Update packages (minor/patch updates)
npm update

# Update specific vulnerable package
npm install package-name@latest
```

**2. Update package-lock.json:**
```bash
# Regenerate lock file
rm package-lock.json
npm install
```

**3. Update Dockerfile:**
```dockerfile
# Make sure you're using updated packages
COPY package*.json ./
RUN npm ci  # Uses exact versions from package-lock.json
```

### For Python Projects:

**1. Update requirements.txt:**
```bash
# Check for outdated packages
pip list --outdated

# Update specific package
pip install --upgrade package-name

# Update requirements.txt
pip freeze > requirements.txt
```

**2. Update Dockerfile:**
```dockerfile
RUN pip install --upgrade pip
RUN pip install -r requirements.txt
```

## Step 5: Fix OS Package Vulnerabilities

### For Alpine-based Images:

**Add package updates to Dockerfile:**
```dockerfile
FROM node:18-alpine

# Update Alpine packages to fix vulnerabilities
RUN apk update && apk upgrade && apk add --no-cache \
    && rm -rf /var/cache/apk/*

# Your application code...
```

### For Debian/Ubuntu-based Images:

```dockerfile
FROM node:18

# Update system packages
RUN apt-get update && apt-get upgrade -y && \
    apt-get clean && rm -rf /var/lib/apt/lists/*

# Your application code...
```

## Step 6: Common Fix Patterns

### Pattern 1: Update Base Image

**Problem:** Base image has known vulnerabilities

**Solution:**
```dockerfile
# Old
FROM node:18-alpine

# New (check for latest patched version)
FROM node:18.20.4-alpine
# Or
FROM node:20-alpine
```

### Pattern 2: Update Application Dependencies

**Problem:** npm/pip packages have vulnerabilities

**Solution:**
```bash
# Update packages
npm audit fix          # Auto-fix vulnerabilities
npm audit fix --force  # Force updates (may break things)

# Or manually update in package.json
npm install package-name@latest
```

### Pattern 3: Use Multi-stage Builds

**Problem:** Build tools introduce vulnerabilities

**Solution:**
```dockerfile
# Build stage (can have build tools)
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# Production stage (minimal, secure)
FROM node:18-alpine
WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
# Only production dependencies, no build tools
```

## Step 7: Verify Fixes

### After Making Changes:

1. **Commit and push your changes:**
   ```bash
   git add .
   git commit -m "Fix security vulnerabilities"
   git push
   ```

2. **Wait for CI/CD to run:**
   - Trivy will scan again
   - Check if vulnerabilities are resolved

3. **Check GitHub Security tab:**
   - New scan should show fewer/no CRITICAL/HIGH vulnerabilities
   - Old alerts will be marked as "Fixed"

## Step 8: Handle False Positives

Sometimes Trivy reports vulnerabilities that don't affect your use case:

### Option 1: Ignore Specific CVEs (Not Recommended)
```yaml
# In workflow, add ignore patterns
- name: Scan backend image with Trivy
  uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.DOCKERHUB_USERNAME }}/${{ env.BACKEND_IMAGE }}:${{ steps.tag.outputs.tag }}
    ignore-unfixed: true  # Only report fixed vulnerabilities
    severity: 'CRITICAL,HIGH'
```

### Option 2: Document Why It's Safe
- Add comments in Dockerfile explaining why vulnerability doesn't apply
- Document in security review

## Quick Reference: Common Commands

```bash
# Check npm vulnerabilities
npm audit

# Fix npm vulnerabilities automatically
npm audit fix

# Check for outdated packages
npm outdated

# Update all packages (careful!)
npm update

# Check Docker image vulnerabilities locally
docker run --rm aquasec/trivy image your-image:tag

# Scan Dockerfile
docker run --rm -v /var/run/docker.sock:/var/run/docker.sock \
  aquasec/trivy fs ./path/to/Dockerfile
```

## Example: Complete Fix Workflow

**1. View vulnerabilities in GitHub Security tab**

**2. Identify the issue:**
   - Example: "CVE-2024-1234 in node:18-alpine base image"

**3. Update Dockerfile:**
   ```dockerfile
   # Before
   FROM node:18-alpine
   
   # After
   FROM node:18.20.4-alpine  # Patched version
   ```

**4. Update application packages:**
   ```bash
   npm audit fix
   npm install
   ```

**5. Test locally (optional):**
   ```bash
   docker build -t test-image .
   docker run --rm aquasec/trivy image test-image
   ```

**6. Commit and push:**
   ```bash
   git add Dockerfile package*.json
   git commit -m "Fix security vulnerabilities"
   git push
   ```

**7. Verify in CI/CD:**
   - Check workflow runs successfully
   - Verify no CRITICAL/HIGH vulnerabilities
   - Images should push to DockerHub

## Best Practices

1. **Update Regularly:**
   - Update base images monthly
   - Update npm/pip packages weekly
   - Monitor security advisories

2. **Use Specific Versions:**
   ```dockerfile
   # Good: Specific version
   FROM node:18.20.4-alpine
   
   # Bad: Latest (can break)
   FROM node:latest
   ```

3. **Minimize Attack Surface:**
   - Use minimal base images (Alpine)
   - Remove unnecessary packages
   - Use multi-stage builds

4. **Automate Updates:**
   - Use Dependabot for package updates
   - Schedule regular security scans
   - Set up alerts for new vulnerabilities

## Still Having Issues?

If vulnerabilities persist after updates:

1. **Check if it's a false positive:**
   - Verify the CVE actually affects your use case
   - Check if the vulnerability is in code you don't use

2. **Check Trivy database:**
   - Trivy might be using outdated vulnerability database
   - Wait for next database update

3. **Consider alternative base images:**
   - Switch to different base image
   - Use distroless images for minimal attack surface

4. **Review vulnerability details:**
   - Read the CVE description
   - Check if it requires specific conditions to exploit
   - Assess actual risk to your application

