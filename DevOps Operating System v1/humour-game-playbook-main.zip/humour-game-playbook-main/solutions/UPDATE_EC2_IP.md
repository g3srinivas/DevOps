# How to Update EC2 IP Address

Your EC2 instance IP has changed. Here's where to update it:

## Step 1: Get Your New EC2 IP

1. **AWS Console Method:**
   - Go to: https://console.aws.amazon.com/ec2
   - Click "Instances"
   - Find your instance
   - Copy the **Public IPv4 address**

2. **AWS CLI Method:**
   ```bash
   aws ec2 describe-instances --query 'Reservations[*].Instances[*].[InstanceId,PublicIpAddress]' --output table
   ```

## Step 2: Update SSH Config File

**Location:** `~/.ssh/config`

**Current entry:**
```
HostName 13.222.115.214
```

**Update to:**
```
HostName YOUR_NEW_IP_HERE
```

**Full command:**
```bash
# Edit SSH config
nano ~/.ssh/config

# Or use sed to replace (replace NEW_IP with your actual IP)
sed -i '' 's/13.222.115.214/YOUR_NEW_IP/g' ~/.ssh/config
```

## Step 3: Update GitHub Secrets (For CI/CD)

If your GitHub Actions workflow uses the EC2 IP:

1. Go to your GitHub repository
2. Click **Settings** → **Secrets and variables** → **Actions**
3. Find `PRODUCTION_SERVER` secret
4. Click **Update**
5. Enter your new EC2 IP address
6. Click **Update secret**

## Step 4: Update Files with Hardcoded IPs

The following files contain the old IP `13.222.115.214`:

### Files to Update:

1. **SSH_TROUBLESHOOTING.md** - Contains old IP in examples
2. **EC2_LOGS_GUIDE.md** - Contains old IP in examples
3. **~/.ssh/config** - Your SSH configuration (most important!)

### Quick Update Command:

```bash
# Replace all occurrences in your project (be careful!)
cd "/Users/mac/Desktop/devops playbook"
find . -type f -name "*.md" -exec sed -i '' 's/13.222.115.214/YOUR_NEW_IP/g' {} \;
```

⚠️ **Warning:** This replaces ALL occurrences. Review the changes before committing!

## Step 5: Test Connection

```bash
# Test SSH connection
ssh -i ~/.ssh/devops-lab-key.pem ubuntu@YOUR_NEW_IP

# Or if using SSH config
ssh ec2-devops  # (or whatever your Host name is)
```

## Step 6: Update Security Group (If Needed)

If you can't connect, your IP might have changed:

```bash
# Check your current IP
curl -s https://checkip.amazonaws.com

# Update security group to allow your new IP
# (See EC2_SECURITY_GROUP_UPDATE.md for details)
```

## Quick Checklist

- [ ] Get new EC2 IP from AWS Console
- [ ] Update `~/.ssh/config` file
- [ ] Update GitHub `PRODUCTION_SERVER` secret (if using CI/CD)
- [ ] Test SSH connection
- [ ] Update security group if needed
- [ ] Update documentation files (optional)

## Most Important: SSH Config

The **most critical** file to update is your SSH config:

```bash
# View current config
cat ~/.ssh/config

# Edit it
nano ~/.ssh/config

# Find the line with HostName and update the IP
```

