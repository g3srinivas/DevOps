# Terraform Workflow Control Guide

## Problem
When you push Terraform changes, multiple workflows can trigger simultaneously:
- `terraform.yml` (plan/apply)
- `terraform-backend-sync.yml` (backend sync)

This causes conflicts and state lock issues.

## Solution: Comment Out Auto-Triggers

### Step 1: Disable Auto-Trigger in `terraform-backend-sync.yml`

**File:** `.github/workflows/terraform-backend-sync.yml`

**Comment out the `push` trigger** (lines 21-24):

```yaml
on:
  workflow_dispatch:
    # ... manual trigger stays active ...
  # COMMENT OUT THIS SECTION TO PREVENT AUTO-TRIGGER:
  # push:
  #   branches: [main]
  #   paths:
  #     - 'h-game-terraform/backend.tf'
```

**Why:** This workflow should only run manually when you need to sync the backend.

### Step 2: Keep `terraform.yml` Active

**File:** `.github/workflows/terraform.yml`

**Keep as-is** - This is your main Terraform workflow for plan/apply.

### Step 3: `terraform-destroy.yml` is Already Manual

**File:** `.github/workflows/terraform-destroy.yml`

**Already manual-only** - No changes needed.

## Workflow Usage (After Changes)

### Normal Terraform Operations
```bash
# 1. Make Terraform changes
git add h-game-terraform/
git commit -m "feat: update infrastructure"
git push origin main

# Only terraform.yml will run (plan on PR, apply on main)
```

### Backend Sync (Manual Only)
```bash
# Only run when backend resources change
# Go to GitHub Actions → "Sync Terraform Backend" → Run workflow
```

### Destroy Infrastructure (Manual Only)
```bash
# Only run when you need to destroy
# Go to GitHub Actions → "Terraform Destroy" → Run workflow
```

## Quick Fix Command

To quickly comment out the push trigger:

```bash
cd .github/workflows
sed -i '' '21,24s/^/# /' terraform-backend-sync.yml
```

## Verify

After commenting out, when you push Terraform changes:
- ✅ `terraform.yml` will run (plan/apply)
- ❌ `terraform-backend-sync.yml` will NOT auto-run
- ✅ `terraform-backend-sync.yml` can still be run manually

