# How to Run CI/CD and Observability - Complete Beginner Guide

**Everything is automated via CI/CD. Just push code!**

## Quick Overview

**This guide has 3 parts:**
1. **Part 0: Create Infrastructure** (if it doesn't exist)
2. **Part 1: CI/CD** (build, test, deploy)
3. **Part 2: Observability** (monitor, dashboards, alerts)

**Start with Part 0 if you don't have infrastructure yet.**

---

## Part 0: Create Infrastructure (If It Doesn't Exist)

### What You Need Before Starting

**Before CI/CD or Observability can work, you need:**
- S3 bucket (for Terraform state) - **Manual one-time** (chicken-and-egg)
- DynamoDB table (for Terraform state locking) - **Manual one-time** (chicken-and-egg)
- EKS cluster (for running your app) - **Automated via CI/CD**
- ECR repositories (for storing Docker images) - **Automated via CI/CD**

**Key point:** Only S3 and DynamoDB are manual. Everything else is automated!

### Step 0.1: Check What Exists

```bash
# Check if EKS cluster exists
aws eks describe-cluster --name h-game-prod --region us-east-1 2>&1

# Check if S3 bucket exists (for Terraform backend)
aws s3 ls | grep h-game-tfstate

# Check if DynamoDB table exists (for Terraform state lock)
aws dynamodb describe-table --table-name h-game-terraform-state-lock --region us-east-1 2>&1

# Check if ECR repositories exist
aws ecr describe-repositories --region us-east-1 2>&1 | grep h-game
```

**If you see errors (not found):** Continue to Step 0.2 to create them.

**If everything exists:** Skip to Part 1 (CI/CD).

---

### Step 0.2: Create S3 Bucket and DynamoDB Table (One-Time Manual Step)

**NOTE:** These must be created manually ONCE because Terraform needs them to store its own state (chicken-and-egg problem). After this, everything else is automated via CI/CD.

**Option A: Quick Manual Creation (2 minutes)**

```bash
# Set your AWS region
export AWS_REGION=us-east-1

# 1. Create S3 bucket for Terraform state
# Replace 1769734069 with a random number (makes bucket name unique)
BUCKET_NAME="h-game-tfstate-playbook-1769734069"
aws s3api create-bucket \
  --bucket $BUCKET_NAME \
  --region $AWS_REGION

# Enable versioning and encryption
aws s3api put-bucket-versioning \
  --bucket $BUCKET_NAME \
  --versioning-configuration Status=Enabled

aws s3api put-bucket-encryption \
  --bucket $BUCKET_NAME \
  --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'

aws s3api put-public-access-block \
  --bucket $BUCKET_NAME \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

# 2. Create DynamoDB table for state locking
TABLE_NAME="h-game-terraform-state-lock"
aws dynamodb create-table \
  --table-name $TABLE_NAME \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region $AWS_REGION

aws dynamodb wait table-exists --table-name $TABLE_NAME --region $AWS_REGION

echo "S3 bucket created: $BUCKET_NAME"
echo "DynamoDB table created: $TABLE_NAME"
```

**Option B: Use Terraform Backend Sync Workflow (Automated)**

If you prefer automation, you can use the `terraform-backend-sync.yml` workflow:

1. Go to: **GitHub → Actions → Sync Terraform Backend → Run workflow**
2. Enter your bucket and table names
3. Workflow will create them automatically

**Verify they were created:**
```bash
aws s3 ls | grep h-game-tfstate
aws dynamodb describe-table --table-name h-game-terraform-state-lock --region us-east-1 \
  --query 'Table.TableStatus' --output text
# Should return: ACTIVE
```

---

### Step 0.3: Update Terraform Backend Configuration

**Update `h-game-terraform/backend.tf` with your bucket and table names:**

```bash
cd h-game-terraform

# The file should have:
# terraform {
#   backend "s3" {
#     bucket         = "h-game-tfstate-playbook-1769734069"  # Your bucket name
#     key            = "terraform.tfstate"
#     region         = "us-east-1"
#     dynamodb_table = "h-game-terraform-state-lock"  # Your table name
#     encrypt        = true
#   }
# }
```

**If names don't match:** Update `backend.tf` with the names you created.

---

### Step 0.4: Create EKS Cluster and Infrastructure (Automated via CI/CD)

**Use CI/CD to create infrastructure automatically!**

**Option A: Use Terraform CI/CD Workflow (Recommended)**

```bash
# 1. Make sure backend.tf is configured correctly
cd h-game-terraform
cat backend.tf  # Verify bucket and table names

# 2. Commit and push Terraform files
git add h-game-terraform/
git commit -m "feat: create infrastructure"
git push origin main
```

**What happens:**
1. `terraform.yml` workflow runs automatically
2. Runs `terraform fmt` (format code)
3. Runs `terraform validate` (check syntax)
4. Runs `terraform plan` (preview changes)
5. Runs security scans (Checkov, tfsec)
6. Requires approval (if production environment)
7. Runs `terraform apply` (creates infrastructure)

**Check progress:**
- Go to: **GitHub → Actions → Terraform CI/CD**
- Watch the workflow complete
- Approve if prompted (for production)

**Takes 15-20 minutes. Everything is automated!**

**Verify infrastructure was created:**
```bash
# Check EKS cluster
aws eks describe-cluster --name h-game-prod --region us-east-1 \
  --query 'cluster.status' --output text
# Should return: ACTIVE

# Check ECR repositories
aws ecr describe-repositories --region us-east-1 --query 'repositories[].repositoryName'
# Should show: h-game-backend, h-game-frontend

# Get ECR registry URL (you'll need this for GitHub secrets)
aws ecr describe-repositories --region us-east-1 \
  --query 'repositories[?repositoryName==`h-game-backend`].repositoryUri' --output text
# Save this URL! (e.g., 334091769766.dkr.ecr.us-east-1.amazonaws.com)
```


---

### Step 0.5: Configure kubectl to Access EKS

```bash
# Update kubeconfig to connect to your EKS cluster
aws eks update-kubeconfig --name h-game-prod --region us-east-1

# Verify connection
kubectl cluster-info

# Should show:
# Kubernetes control plane is running at https://...
```

**If you see cluster info:** You're connected!

**If connection fails:**
- Check EKS cluster exists: `aws eks describe-cluster --name h-game-prod --region us-east-1`
- Check AWS credentials: `aws sts get-caller-identity`
- Check cluster is ACTIVE (not CREATING)

---

## Infrastructure Checklist

**Before moving to CI/CD, verify:**

- [ ] S3 bucket exists: `aws s3 ls | grep h-game-tfstate`
- [ ] DynamoDB table exists: `aws dynamodb describe-table --table-name h-game-terraform-state-lock --region us-east-1`
- [ ] EKS cluster is ACTIVE: `aws eks describe-cluster --name h-game-prod --region us-east-1 --query 'cluster.status'`
- [ ] ECR repositories exist: `aws ecr describe-repositories --region us-east-1 | grep h-game`
- [ ] kubectl can connect: `kubectl cluster-info`

**All checked?** Move to Part 1 (CI/CD).

**Something missing?** Go back and fix it.

---

# ============================================
# PART 1: CI/CD (Section 7)
# ============================================
# Build, test, and deploy your application
# ============================================

## What CI/CD Does

**CI/CD = Continuous Integration / Continuous Deployment**

- **Builds** your Docker images
- **Tests** your code (unit tests, security scans)
- **Scans** for vulnerabilities (Trivy, SonarCloud)
- **Deploys** to Kubernetes automatically

**Result:** Push code → Automatically deployed to production

---

## CI/CD Step 1: Set Up GitHub Secrets (One-Time Setup)

**CRITICAL:** CI/CD workflows need these secrets to work. Add them once, then everything is automated.

**Go to:** GitHub → Your Repo → Settings → Secrets and variables → Actions → New repository secret

**Add these secrets (one by one):**

```
Name: AWS_ACCESS_KEY_ID
Value: (Your AWS access key ID)

Name: AWS_SECRET_ACCESS_KEY
Value: (Your AWS secret access key)

Name: ECR_REGISTRY
Value: (Your ECR registry URL - get after infrastructure is created)

Name: RDS_PASSWORD
Value: (Your RDS database password - create a strong password)
```

**How to get values:**

**AWS Credentials:**
```bash
# If you don't have AWS credentials:
# Go to: AWS Console → IAM → Users → Your User → Security Credentials
# Create Access Key → Download CSV
# Or use existing credentials
```

**ECR_REGISTRY (get after Part 0 completes):**
```bash
# After infrastructure is created via CI/CD, run:
aws ecr describe-repositories --region us-east-1 \
  --query 'repositories[?repositoryName==`h-game-backend`].repositoryUri' --output text
# Copy the URL (without /h-game-backend at the end)
# Example: 334091769766.dkr.ecr.us-east-1.amazonaws.com
```

**RDS_PASSWORD:**
- Create a strong password (save it securely!)
- This will be used when Terraform creates the RDS database

**After adding all secrets:** CI/CD workflows can now run automatically!

---

## Understanding CI/CD Workflows (For Beginners)

**Don't worry if the workflow YAML files look complex!** Here's what you need to know:

### What Are Workflow Files?

Workflow files (`.github/workflows/*.yml`) are like recipes that tell GitHub Actions what to do when you push code. Think of them as automated scripts that run in the cloud.

### The Three Main Workflows

1. **`terraform.yml`** - Infrastructure automation
   - **What it does:** Creates/updates AWS infrastructure (EKS, RDS, etc.)
   - **When it runs:** When you push changes to `h-game-terraform/` folder
   - **You don't need to understand it:** Just push Terraform files and it works

2. **`build.yml`** - Application build automation
   - **What it does:** Tests code, builds Docker images, scans for security issues
   - **When it runs:** When you push changes to `backend/` or `frontend/` folders
   - **You don't need to understand it:** Just push code and it builds automatically

3. **`deploy.yml`** - Application deployment automation
   - **What it does:** Deploys your app to Kubernetes (dev/staging/production)
   - **When it runs:** After `build.yml` succeeds, or when you push to specific branches
   - **You don't need to understand it:** Just push code and it deploys automatically

### Key Concepts (Simple Explanation)

- **Jobs:** Steps that run in sequence or parallel (like "test", "build", "deploy")
- **Secrets:** Passwords and keys stored securely in GitHub (you add these once)
- **Triggers:** What causes the workflow to run (push, pull request, manual)
- **Environments:** Different deployment targets (dev, staging, production)

### Do You Need to Edit Workflows?

**No!** The workflows are already set up and working. You just:
1. Push code → Workflows run automatically
2. Check GitHub Actions tab → See if they succeeded
3. That's it!

**Only edit workflows if:**
- You want to add new steps (like notifications)
- You want to change when they run
- You're learning how CI/CD works

### Where to Find Workflows

- **GitHub → Actions tab:** See all workflow runs (past and present)
- **`.github/workflows/` folder:** See the workflow files (YAML code)
- **Click on a workflow run:** See detailed logs of what happened

### Common Questions

**Q: What if a workflow fails?**
- Check the logs in GitHub Actions tab
- Look for error messages (they're usually clear)
- Most failures are: missing secrets, wrong credentials, or code errors

**Q: Can I skip workflows?**
- Yes! Add `[skip ci]` to your commit message
- Example: `git commit -m "docs: update README [skip ci]"`

**Q: How long do workflows take?**
- Build: 5-10 minutes
- Deploy: 3-5 minutes
- Terraform: 15-20 minutes (first time)

**Bottom line:** Workflows are automation magic. You push code, they do the work. You don't need to understand every line!

---

## CI/CD Step 2: Trigger Build and Deploy Pipeline

**Everything is automated! Just push code.**

```bash
# Make a small change to trigger the pipeline
echo "# CI/CD Test" >> backend/README.md
git add backend/README.md
git commit -m "test: trigger CI/CD pipeline"
git push origin main
```

**What happens automatically:**

1. **Build Pipeline (`build.yml`)** runs:
   - Runs unit tests (matrix: Node 18, 20)
   - Runs code quality scan (SonarCloud)
   - Builds Docker images (with caching)
   - Scans images for vulnerabilities (Trivy)
   - Pushes images to ECR

2. **Deploy Pipeline (`deploy.yml`)** runs automatically:
   - Determines environment (dev/staging/prod based on branch)
   - Deploys to Kubernetes (blue/green strategy)
   - Runs smoke tests
   - Switches traffic to new version
   - Keeps old version for rollback window

**Check progress:**
- Go to: **GitHub → Actions tab**
- You'll see both workflows running:
  - `Build and Push` (builds images)
  - `Deploy` (deploys to Kubernetes)
- Watch them complete

**Takes 5-10 minutes. Fully automated!**

**Pro tip:** You can also manually trigger:
- **GitHub → Actions → Build and Push → Run workflow**
- **GitHub → Actions → Deploy → Run workflow** (select environment)

---

## CI/CD Step 3: Verify Deployment

```bash
# Wait for pipeline to complete (check GitHub Actions)
# Then verify pods are running:

kubectl get pods -n h-game

# Expected output:
# NAME                          READY   STATUS    RESTARTS   AGE
# backend-xxxxx-xxxxx           1/1     Running   0          5m
# backend-xxxxx-xxxxx           1/1     Running   0          5m
# backend-xxxxx-xxxxx           1/1     Running   0          5m

# Good signs:
#   - STATUS = Running (not Pending, CrashLoopBackOff)
#   - READY = 1/1 (pod is ready)
#   - RESTARTS = 0 (or low number)
```

**If pods are running:** CI/CD is working! Move to Part 2 (Observability).

**If pods are not running:**
```bash
# Check what went wrong
kubectl get pods -n h-game
kubectl describe pod -n h-game <pod-name>
kubectl logs -n h-game deployment/backend

# Common issues:
# - ImagePullBackOff → Image not in ECR (check build.yml workflow)
# - CrashLoopBackOff → App is crashing (check logs)
# - Pending → Not enough resources (check nodes)
```

---

## CI/CD Summary

**What you just did (all automated):**
1. Created infrastructure via Terraform CI/CD (or manual)
2. Set up GitHub secrets (one-time)
3. Pushed code → CI/CD automatically:
   - Built images
   - Ran tests
   - Scanned for security
   - Deployed to Kubernetes
4. Verified deployment

**Your app is now deployed automatically!**

**Key point:** After initial setup, you just push code. Everything else is automated!

**Next:** Add observability to monitor it.

---

# ============================================
# PART 2: OBSERVABILITY (Section 8)
# ============================================
# Monitor, visualize, and alert on your application
# ============================================

## What Observability Does

**Observability = Understanding what's happening in your system**

- **Metrics** - CPU, memory, request rate, errors
- **Logs** - Application logs from all pods
- **Traces** - Request flow across services
- **Dashboards** - Visualize everything in Grafana
- **Alerts** - Get notified when something breaks

**Result:** Know exactly what's happening, before users complain

---

## Observability Prerequisites (MUST HAVE)

**CRITICAL: Observability needs a running application!**

**Before starting, verify:**

1. **EKS cluster is running**
2. **Application is deployed** (pods running)
3. **Application is healthy** (health check works)

**If any of these fail:** Go back to Part 1 and fix it first.

---

## Observability Step 1: Verify Application is Running

```bash
# 1. Check EKS cluster
aws eks describe-cluster --name h-game-prod --region us-east-1 \
  --query 'cluster.status' --output text
# Must return: ACTIVE

# 2. Check pods are running
kubectl get pods -n h-game
# Must show pods with STATUS = Running

# 3. Check application is healthy
# Terminal 1: Port-forward (keep this running)
kubectl port-forward -n h-game service/backend-service 3001:3001

# Terminal 2: Test health endpoint
curl http://localhost:3001/health

# Expected response:
# {"status":"healthy","services":{"database":"healthy","redis":"healthy","api":"healthy"}}
```

**If all checks pass:** Continue to Step 2.

**If any check fails:**
- Pods not running → Check Part 1 (CI/CD deployment)
- Health check fails → Check pod logs: `kubectl logs -n h-game deployment/backend`
- Fix issues before continuing!

---

## Observability Step 2: Install Helm

**Helm is a package manager for Kubernetes (like npm for Node.js)**

```bash
# Check if Helm is already installed
helm version

# If you see: version.BuildInfo{Version:"v3.x.x",...}
# Helm is installed! Skip to Step 3.

# If you see: command not found
# Install Helm:

# macOS:
brew install helm

# Linux:
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# Windows (PowerShell):
# Download from: https://github.com/helm/helm/releases
# Or: choco install kubernetes-helm

# Verify installation
helm version
# Should show: version.BuildInfo{Version:"v3.x.x",...}
```

**If Helm is installed:** Continue to Step 3.

---

## Observability Step 3: Add Prometheus Helm Repository

```bash
# Add the Prometheus Community Helm repository
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts

# Update Helm repositories
helm repo update

# Verify repository was added
helm repo list

# Should show:
# NAME                    URL
# prometheus-community    https://prometheus-community.github.io/helm-charts
```

**If repository is added:** Continue to Step 4.

---

## Observability Step 4: Install Prometheus & Grafana

```bash
# 1. Create namespace for observability tools
kubectl create namespace monitoring

# 2. Install Prometheus stack (includes Prometheus + Grafana + AlertManager)
helm install prometheus prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --wait

# This installs:
# - Prometheus (metrics collection)
# - Grafana (dashboards)
# - AlertManager (alerting)
# - Prometheus Operator (manages everything)

# Wait 2-3 minutes for everything to start
```

**Verify installation:**
```bash
# Check if pods are running
kubectl get pods -n monitoring

# Should show:
# NAME                                                     READY   STATUS    RESTARTS   AGE
# prometheus-kube-prometheus-operator-xxxxx               1/1     Running   0          2m
# prometheus-kube-prometheus-prometheus-0                 2/2     Running   0          2m
# prometheus-grafana-xxxxx                                2/2     Running   0          2m
# prometheus-kube-prometheus-alertmanager-0               2/2     Running   0          2m

# If all pods are Running: Continue to Step 5
# If pods are Pending/CrashLoopBackOff: Check logs
```

---

## Observability Step 5: Access Grafana

**Grafana = Beautiful dashboards to visualize your metrics**

```bash
# 1. Get Grafana admin password
kubectl get secret -n monitoring prometheus-grafana -o jsonpath='{.data.admin-password}' | base64 -d
# Copy this password! (you'll need it to login)

# 2. Port-forward to access Grafana
kubectl port-forward -n monitoring service/prometheus-grafana 3000:80

# Keep this terminal open! Port-forward runs in foreground.
# Open a NEW terminal for other commands.
```

**Access Grafana:**
1. Open browser: **http://localhost:3000**
2. Username: **admin**
3. Password: **(the one you copied above)**

**You should see Grafana dashboard!**

**What you can do:**
- View pre-built dashboards (Kubernetes, Node Exporter, etc.)
- Create custom dashboards
- Query Prometheus metrics
- Set up alerts

---

## Observability Step 6: Access Prometheus

**Prometheus = Metrics database and query engine**

```bash
# In a new terminal (keep Grafana port-forward running)
kubectl port-forward -n monitoring service/prometheus-kube-prometheus-prometheus 9090:9090
```

**Access Prometheus:**
1. Open browser: **http://localhost:9090**
2. No login required

**What you can do:**
- Query metrics using PromQL
- Check targets (see what Prometheus is scraping)
- View alerts
- Explore metrics

**Try this query:**
```
up
```
This shows all targets Prometheus is monitoring (should show many "1" values = UP)

---

## Observability Summary

**What you just did:**
1. Verified application is running
2. Installed Helm
3. Installed Prometheus & Grafana
4. Accessed Grafana dashboards
5. Accessed Prometheus UI

**Your observability stack is running!**

**Next steps:**
- Follow `book/observability/o1-metrics-prometheus-grafana.md` to add metrics to your app
- Follow `book/observability/o2-logging-loki-promtail.md` to add log aggregation
- Follow `book/observability/o3-distributed-tracing-jaeger.md` to add tracing

---

# ============================================
# QUICK REFERENCE
# ============================================

## CI/CD Commands

```bash
# Check workflow status
# Go to: GitHub → Actions tab

# Manually trigger deployment
# Go to: GitHub → Actions → Deploy → Run workflow

# Check deployment
kubectl get pods -n h-game
kubectl logs -n h-game deployment/backend
kubectl describe deployment backend -n h-game
```

## Observability Commands

```bash
# Check Prometheus/Grafana pods
kubectl get pods -n monitoring

# Access Grafana
kubectl port-forward -n monitoring service/prometheus-grafana 3000:80
# Browser: http://localhost:3000

# Access Prometheus
kubectl port-forward -n monitoring service/prometheus-kube-prometheus-prometheus 9090:9090
# Browser: http://localhost:9090

# Check application metrics
kubectl port-forward -n h-game service/backend-service 3001:3001
curl http://localhost:3001/metrics
```

## Infrastructure Commands

```bash
# Check EKS cluster
aws eks describe-cluster --name h-game-prod --region us-east-1

# Check ECR repositories
aws ecr describe-repositories --region us-east-1

# Check S3 bucket
aws s3 ls | grep h-game-tfstate

# Check DynamoDB table
aws dynamodb describe-table --table-name h-game-terraform-state-lock --region us-east-1
```

---

# ============================================
# TROUBLESHOOTING
# ============================================

## CI/CD Issues

### Problem: Workflow fails

**Check:**
1. GitHub Actions logs (click on failed workflow)
2. Common issues:
   - Missing secrets → Add in GitHub Settings
   - ECR repository missing → Create via Terraform
   - AWS credentials wrong → Check secrets

### Problem: Deployment fails

```bash
# Check pod status
kubectl get pods -n h-game

# Check pod logs
kubectl logs -n h-game deployment/backend --tail=50

# Check deployment events
kubectl describe deployment backend -n h-game
```

## Observability Issues

### Problem: Can't access Grafana

```bash
# Check if Grafana pod is running
kubectl get pods -n monitoring | grep grafana

# If not running, check why
kubectl describe pod -n monitoring <grafana-pod-name>

# Check service exists
kubectl get services -n monitoring | grep grafana
```

### Problem: No metrics showing

```bash
# 1. Check if application has metrics endpoint
kubectl port-forward -n h-game service/backend-service 3001:3001
curl http://localhost:3001/metrics

# 2. If 404, metrics not enabled yet (this is OK - you'll add in O1)

# 3. Check if Prometheus is scraping
# Go to: http://localhost:9090 → Status → Targets
# Should show your service as "UP"
```

## Infrastructure Issues

### Problem: Terraform apply fails

```bash
# Check error message
terraform apply

# Common issues:
# - Missing variables → Check variables.tf
# - AWS permissions → Check IAM permissions
# - Resource limits → Check AWS quotas
# - State lock → Wait or force unlock (careful!)
```

### Problem: Can't connect to EKS

```bash
# Update kubeconfig
aws eks update-kubeconfig --name h-game-prod --region us-east-1

# Check cluster exists
aws eks describe-cluster --name h-game-prod --region us-east-1

# Check AWS credentials
aws sts get-caller-identity
```

---

# ============================================
# COMPLETE CHECKLIST
# ============================================

## Before Starting CI/CD

- [ ] S3 bucket created
- [ ] DynamoDB table created
- [ ] Terraform backend configured
- [ ] EKS cluster created (ACTIVE)
- [ ] ECR repositories exist
- [ ] kubectl can connect to cluster
- [ ] GitHub secrets added (AWS keys, ECR registry, RDS password)

## Before Starting Observability

- [ ] EKS cluster is ACTIVE
- [ ] Application pods are running
- [ ] Application health check works
- [ ] Helm is installed
- [ ] Prometheus Helm repository added

## After CI/CD

- [ ] Build workflow succeeds
- [ ] Deploy workflow succeeds
- [ ] Pods are running in Kubernetes
- [ ] Application is accessible

## After Observability

- [ ] Prometheus pods are running
- [ ] Grafana pods are running
- [ ] Can access Grafana (http://localhost:3000)
- [ ] Can access Prometheus (http://localhost:9090)

---

## That's It!

**Simple automated workflow:**
1. **Part 0:** Create S3/DynamoDB (one-time manual) → Push Terraform → CI/CD creates infrastructure
2. **Part 1:** Set up GitHub secrets (one-time) → Push code → CI/CD auto-builds and deploys
3. **Part 2:** Install observability → Monitor in Grafana

**Key point:** After initial setup, everything is automated. Just push code!

**No over-engineering. Just automation.**

**Questions?** Check detailed guides:
- CI/CD: `book/cicd/section-7-overview.md`
- Observability: `book/observability/O0-BEGINNER-SETUP-GUIDE.md`
