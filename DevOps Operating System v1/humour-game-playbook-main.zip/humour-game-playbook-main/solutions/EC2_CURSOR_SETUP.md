# Connecting EC2 to Cursor IDE

This guide will help you connect your EC2 instance to Cursor IDE for remote development.

## Prerequisites

1. **EC2 Instance Running**: Your EC2 instance should be running and accessible
2. **SSH Key Pair**: You need the `.pem` key file for your EC2 instance
3. **Security Group**: Ensure your EC2 security group allows SSH (port 22) from your IP

## Step 1: Install Remote-SSH Extension in Cursor

1. Open Cursor IDE
2. Go to Extensions (Cmd+Shift+X on Mac, Ctrl+Shift+X on Windows/Linux)
3. Search for "Remote - SSH" by Microsoft
4. Install the extension

## Step 2: Configure SSH Config File

### On macOS/Linux:

1. Open your SSH config file:
```bash
nano ~/.ssh/config
```

2. Add your EC2 configuration:
```
Host ec2-devops
    HostName YOUR_EC2_PUBLIC_IP_OR_DNS
    User ec2-user  # or 'ubuntu' for Ubuntu instances, 'admin' for Debian
    IdentityFile ~/.ssh/your-key.pem
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
```

**Replace:**
- `ec2-devops`: A friendly name for your connection
- `YOUR_EC2_PUBLIC_IP_OR_DNS`: Your EC2's public IP or DNS name
- `your-key.pem`: Path to your EC2 key file
- `ec2-user`: Default user (varies by AMI: `ec2-user` for Amazon Linux, `ubuntu` for Ubuntu)

### On Windows:

1. Create/edit the SSH config file at: `C:\Users\YourUsername\.ssh\config`
2. Use the same format as above

## Step 3: Set Correct Permissions (macOS/Linux)

If you're on macOS or Linux, ensure your key file has the correct permissions:

```bash
chmod 400 ~/.ssh/your-key.pem
```

## Step 4: Connect via Cursor

1. In Cursor, press `Cmd+Shift+P` (Mac) or `Ctrl+Shift+P` (Windows/Linux)
2. Type "Remote-SSH: Connect to Host"
3. Select your configured host (e.g., `ec2-devops`)
4. Cursor will open a new window and connect to your EC2 instance
5. Once connected, you can open any folder on the remote server

## Step 5: Install Extensions on Remote Server

After connecting, you may need to install extensions on the remote server:
1. Go to Extensions
2. Install any extensions you need (they'll be installed on the remote server)

## Troubleshooting

### Connection Issues

1. **Check EC2 Security Group**: Ensure port 22 is open to your IP
   - Your IP may have changed! Check your current IP:
     ```bash
     curl -s https://checkip.amazonaws.com
     ```
   - See `EC2_SECURITY_GROUP_UPDATE.md` for detailed instructions on updating your security group
2. **Verify Key File Path**: Make sure the path in your SSH config is correct
3. **Test SSH Connection**: Try connecting via terminal first:
   ```bash
   ssh -i ~/.ssh/your-key.pem ec2-user@YOUR_EC2_IP
   ```

### "Operation timed out" Error

This usually means your IP has changed and the security group doesn't allow your current IP:
1. Check your current public IP: `curl -s https://checkip.amazonaws.com`
2. Update your EC2 security group to allow SSH from your new IP
3. See `EC2_SECURITY_GROUP_UPDATE.md` for step-by-step instructions

### Permission Denied

- Ensure your key file has correct permissions: `chmod 400 your-key.pem`
- Verify the username matches your EC2 AMI type

### Host Key Verification Failed

- The config includes `StrictHostKeyChecking no` to bypass this
- For production, consider adding the host key properly

## Alternative: Using SSH Command Directly

If you prefer not to use SSH config, you can connect directly:

1. Press `Cmd+Shift+P` / `Ctrl+Shift+P`
2. Type "Remote-SSH: Connect to Host"
3. Enter: `ec2-user@YOUR_EC2_IP`
4. Select your key file when prompted

## Example SSH Config Entry

Here's a complete example:

```
Host ec2-devops-playbook
    HostName ec2-54-123-45-67.compute-1.amazonaws.com
    User ec2-user
    IdentityFile ~/Desktop/devops-playbook/keys/my-ec2-key.pem
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
```

## Next Steps

Once connected:
- Open the folder you want to work on (e.g., `/home/ec2-user/projects`)
- Install any required extensions
- Start coding!

