# Route53 & ACM Setup Guide (Optional - Requires Domain Name)

**Difficulty:** Intermediate  
**Time:** ~30 minutes  
**Prerequisites:** Domain name registered, Ingress ALB already created

---

## 🎯 What You'll Build

```
Custom Domain (game.yourdomain.com) → Route53 → ALB → Your Application
HTTPS (SSL/TLS) → Secure encrypted connections
```

**Simple explanation:**
- **Route53** = AWS DNS service (maps domain to ALB)
- **ACM** = AWS Certificate Manager (free SSL certificates)
- **HTTPS** = Secure HTTP (encrypted traffic)

---

## ⚠️ Important Notes

1. **This is OPTIONAL** - You can skip this if you don't have a domain
2. **Domain Required** - You need a registered domain (e.g., yourdomain.com)
3. **Ingress First** - Complete Ingress setup first (ALB must exist)
4. **DNS Propagation** - Changes take 24-48 hours to propagate globally

---

## Step 1: Add Variables to Terraform

**Add to `h-game-terraform/variables.tf`:**

```hcl
# ============================================
# ROUTE53 & ACM VARIABLES (OPTIONAL)
# ============================================

variable "domain_name" {
  description = "Domain name for the application (e.g., yourdomain.com). Leave empty to skip Route53 setup."
  type        = string
  default     = ""  # Empty = skip Route53 setup
}

variable "app_subdomain" {
  description = "Subdomain for the application (e.g., game for game.yourdomain.com)"
  type        = string
  default     = "game"
}

variable "certificate_domain" {
  description = "Domain for ACM certificate (can be wildcard, e.g., *.yourdomain.com). Leave empty to skip ACM setup."
  type        = string
  default     = ""  # Empty = skip ACM setup
}
```

**Add to `h-game-terraform/terraform.tfvars`:**

```hcl
# Route53 & ACM Configuration (OPTIONAL - leave empty to skip)
domain_name       = ""           # e.g., "yourdomain.com" or "" to skip
app_subdomain     = "game"        # e.g., "game" for game.yourdomain.com
certificate_domain = ""           # e.g., "*.yourdomain.com" or "" to skip
```

**If you have a domain, fill in the values:**

```hcl
domain_name       = "yourdomain.com"
app_subdomain     = "game"        # Results in: game.yourdomain.com
certificate_domain = "*.yourdomain.com"  # Wildcard covers all subdomains
```

---

## Step 2: Add ACM Provider (Required for Certificates)

**Update `h-game-terraform/provider.tf`:**

```hcl
# Provider alias for us-east-1 (required for ACM certificates used by ALB)
# ACM certificates for ALB must be in us-east-1 (AWS requirement)
provider "aws" {
  alias  = "us_east_1"
  region = "us-east-1"

  default_tags {
    tags = {
      Project     = var.project_name
      Environment = var.environment
      ManagedBy   = "Terraform"
    }
  }
}
```

---

## Step 3: Verify Ingress ALB Exists

**Before setting up Route53, ensure your Ingress ALB is created:**

```bash
# Get ALB DNS name from Ingress
kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'

# Should return: h-game-alb-ingress-XXXXX.us-east-1.elb.amazonaws.com
```

**If empty, apply Ingress first:**

```bash
kubectl apply -f k8s/ingress.yaml
# Wait 2-3 minutes for ALB to be created
```

---

## Step 4: Apply Route53 Configuration

**The Route53 configuration is already in `route53.tf` (created automatically).**

**If you have a domain, apply it:**

```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"

# Preview changes
terraform plan -target=aws_route53_zone.main -target=aws_route53_record.alb

# Apply Route53
terraform apply -target=aws_route53_zone.main -target=aws_route53_record.alb
```

**Expected output:**
```
aws_route53_zone.main[0]: Creating...
aws_route53_zone.main[0]: Creation complete after 5s
aws_route53_record.alb[0]: Creating...
aws_route53_record.alb[0]: Creation complete after 2s
```

**Get nameservers:**

```bash
terraform output route53_nameservers
# Example: ["ns-123.awsdns-12.com", "ns-456.awsdns-45.net", ...]
```

---

## Step 5: Update Domain Registrar

**Update your domain registrar with Route53 nameservers:**

1. **Go to your domain registrar** (GoDaddy, Namecheap, Google Domains, etc.)
2. **Find DNS/Nameserver settings**
3. **Replace nameservers** with Route53 nameservers from Step 4
4. **Save changes**

**Example:**
- Old nameservers: `ns1.godaddy.com`, `ns2.godaddy.com`
- New nameservers: `ns-123.awsdns-12.com`, `ns-456.awsdns-45.net`, `ns-789.awsdns-78.org`, `ns-012.awsdns-01.co.uk`

**Wait 24-48 hours** for DNS propagation.

---

## Step 6: Apply ACM Certificate Configuration

**The ACM configuration is already in `acm.tf` (created automatically).**

**If you have a domain and want HTTPS, apply it:**

```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"

# Preview changes
terraform plan -target=aws_acm_certificate.main -target=aws_acm_certificate_validation.main

# Apply ACM (this may take 5-10 minutes for validation)
terraform apply -target=aws_acm_certificate.main -target=aws_route53_record.cert_validation -target=aws_acm_certificate_validation.main
```

**Expected output:**
```
aws_acm_certificate.main[0]: Creating...
aws_acm_certificate.main[0]: Creation complete after 2s
aws_route53_record.cert_validation["*.yourdomain.com"]: Creating...
aws_route53_record.cert_validation["*.yourdomain.com"]: Creation complete after 2s
aws_acm_certificate_validation.main[0]: Creating...
aws_acm_certificate_validation.main[0]: Still creating... [30s elapsed]
aws_acm_certificate_validation.main[0]: Still creating... [1m0s elapsed]
aws_acm_certificate_validation.main[0]: Creation complete after 5m30s
```

**Get certificate ARN:**

```bash
terraform output certificate_arn
# Example: arn:aws:acm:us-east-1:334091769766:certificate/12345678-1234-1234-1234-123456789012
```

---

## Step 7: Update Ingress for HTTPS

**Get certificate ARN:**

```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
CERT_ARN=$(terraform output -raw certificate_arn)
echo "Certificate ARN: $CERT_ARN"
```

**Update `k8s/ingress.yaml` with HTTPS annotations:**

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: h-game
  namespace: h-game
  annotations:
    # ... existing annotations ...
    
    # HTTPS Configuration (ADD THESE)
    alb.ingress.kubernetes.io/certificate-arn: REPLACE_WITH_CERTIFICATE_ARN
    alb.ingress.kubernetes.io/ssl-policy: ELBSecurityPolicy-TLS-1-2-2017-01
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
    alb.ingress.kubernetes.io/ssl-redirect: '443'  # Redirect HTTP to HTTPS
```

**Replace certificate ARN:**

```bash
cd "/Users/mac/Desktop/devops playbook/k8s"
CERT_ARN=$(cd ../h-game-terraform && terraform output -raw certificate_arn)

# Replace placeholder (macOS syntax)
sed -i '' "s|REPLACE_WITH_CERTIFICATE_ARN|$CERT_ARN|g" ingress.yaml

# Verify replacement
grep certificate-arn ingress.yaml
```

**Apply updated Ingress:**

```bash
kubectl apply -f k8s/ingress.yaml

# Wait 2-3 minutes for ALB to update
kubectl get ingress h-game -n h-game -w
```

---

## Step 8: Test Custom Domain & HTTPS

**After DNS propagation (24-48 hours):**

```bash
# Get custom domain URL
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
DOMAIN_URL=$(terraform output -raw custom_domain_url)
echo "Custom Domain: $DOMAIN_URL"

# Test HTTP (should redirect to HTTPS)
curl -I http://game.yourdomain.com/health
# Should show: 301 redirect to HTTPS

# Test HTTPS
curl https://game.yourdomain.com/health
# Should return: JSON health status (over HTTPS)
```

**Test in browser:**
1. Open `https://game.yourdomain.com`
2. You should see a padlock icon (🔒) indicating HTTPS
3. Verify the game works

---

## ✅ Verification Checklist

- [ ] Route53 hosted zone created
- [ ] A record pointing to ALB created
- [ ] Nameservers updated at domain registrar
- [ ] DNS propagated (24-48 hours wait)
- [ ] ACM certificate requested
- [ ] Certificate validated (DNS records created)
- [ ] Certificate ARN obtained
- [ ] Ingress updated with HTTPS annotations
- [ ] HTTPS working: `curl https://game.yourdomain.com/health`
- [ ] HTTP redirect working: `curl -I http://game.yourdomain.com/health`

---

## 🔧 Troubleshooting

### Issue: Route53 Zone Not Found

**Symptom:** `Error: No matching Route53 zone found`

**Fix:**
```bash
# Verify domain_name variable is set
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform output domain_name

# If empty, set it in terraform.tfvars
```

### Issue: ALB Not Found

**Symptom:** `Error: No matching ALB found`

**Fix:**
```bash
# Ensure Ingress ALB exists first
kubectl get ingress h-game -n h-game

# Verify ALB name matches
kubectl get ingress h-game -n h-game -o yaml | grep load-balancer-name
# Should show: h-game-alb-ingress
```

### Issue: Certificate Validation Failing

**Symptom:** Certificate stuck in "Pending validation"

**Fix:**
```bash
# Check validation DNS records
aws route53 list-resource-record-sets \
  --hosted-zone-id $(terraform output -raw route53_zone_id) \
  --query 'ResourceRecordSets[?Type==`CNAME`]'

# Verify DNS records exist
# Wait 5-10 minutes for validation
```

### Issue: DNS Not Resolving

**Symptom:** `curl game.yourdomain.com` times out

**Fix:**
- Wait 24-48 hours for DNS propagation
- Verify nameservers updated at registrar
- Check Route53 record: `aws route53 list-resource-record-sets --hosted-zone-id <zone-id>`

---

## 📝 Notes for Readers Without Domain

**If you don't have a domain:**

1. **Skip Route53 setup** - Leave `domain_name = ""` in `terraform.tfvars`
2. **Skip ACM setup** - Leave `certificate_domain = ""` in `terraform.tfvars`
3. **Use ALB DNS name** - Continue using `http://h-game-alb-ingress-XXXXX.us-east-1.elb.amazonaws.com`
4. **HTTP is fine for learning** - Production requires HTTPS, but HTTP works for testing

**When you get a domain later:**
1. Set `domain_name` and `certificate_domain` in `terraform.tfvars`
2. Run `terraform apply`
3. Update nameservers at registrar
4. Wait for DNS propagation
5. Update Ingress with HTTPS annotations

---

## 🎓 What You Learned

1. **Route53** - AWS DNS service for custom domains
2. **ACM** - Free SSL certificates for HTTPS
3. **DNS Propagation** - Time for DNS changes to spread globally
4. **HTTPS Configuration** - Secure encrypted connections
5. **Ingress HTTPS** - Adding SSL to Kubernetes Ingress

---

**Congratulations!** 🎉 You've configured custom domain and HTTPS for your application!

