# CI/CD Setup Checklist

## ✅ What's Fixed

- ✅ All dependency issues resolved
- ✅ Parallelism controls added (prevents rate limiting)
- ✅ State management fixed
- ✅ No more "resource already exists" errors

## ⚠️ Prerequisites for CI/CD

### 1. Backend Resources (One-Time Setup)

**Must exist before CI/CD can run:**

- S3 bucket: `h-game-tfstate-playbook-1769734069`
- DynamoDB table: `h-game-terraform-state-lock`

**Setup:**
```bash
cd h-game-terraform
./bootstrap-backend.sh
```

Or manually create them (see README.md).

### 2. GitHub Secrets Required

**Must be set in GitHub repository settings:**

1. `AWS_ACCESS_KEY_ID` - AWS access key
2. `AWS_SECRET_ACCESS_KEY` - AWS secret key
3. `RDS_PASSWORD` - RDS database password (optional but recommended)

**To set secrets:**
1. Go to GitHub repo → Settings → Secrets and variables → Actions
2. Click "New repository secret"
3. Add each secret

**Note:** If `RDS_PASSWORD` is not set, CI/CD will try to use `terraform.tfvars` (which doesn't exist in CI), then fail.

### 3. AWS Permissions

The AWS credentials must have permissions for:
- VPC, EC2, EKS, RDS, ElastiCache, ALB, ECR
- IAM (create roles/policies)
- S3, DynamoDB (state backend)
- CloudWatch, CloudTrail, Secrets Manager

## 🚀 How CI/CD Works

### On Pull Request:
1. **Validate** - Checks Terraform syntax
2. **Plan** - Shows what will change (uses `RDS_PASSWORD` secret if available)
3. **Security** - Runs Checkov and tfsec scans

### On Push to Main:
1. **Validate** - Checks Terraform syntax
2. **Security** - Runs security scans
3. **Apply** - Creates/updates infrastructure
   - Uses `terraform.tfvars` if it exists (it won't in CI)
   - Falls back to `RDS_PASSWORD` secret
   - Fails if neither exists

## ✅ Team Member Checklist

Before running CI/CD, ensure:

- [ ] Backend S3 bucket exists (`h-game-tfstate-playbook-1769734069`)
- [ ] Backend DynamoDB table exists (`h-game-terraform-state-lock`)
- [ ] GitHub secret `AWS_ACCESS_KEY_ID` is set
- [ ] GitHub secret `AWS_SECRET_ACCESS_KEY` is set
- [ ] GitHub secret `RDS_PASSWORD` is set (recommended)
- [ ] AWS credentials have required permissions

## 🐛 Troubleshooting

### "Error: Failed to get existing workspaces: NoSuchBucket"
- **Fix:** Backend S3 bucket doesn't exist. Run `./bootstrap-backend.sh`

### "Error: rds_password is required"
- **Fix:** Set `RDS_PASSWORD` secret in GitHub, or create `terraform.tfvars` (not recommended for CI)

### "Error: Access Denied"
- **Fix:** AWS credentials don't have sufficient permissions

### "Error: Resource already exists"
- **Fix:** This should be fixed now. If it still happens, check state sync:
  ```bash
  terraform refresh
  ```

## 📝 Notes

- CI/CD uses `-parallelism=5` to prevent AWS API throttling
- State is locked during apply (prevents concurrent modifications)
- Apply only runs on `main` branch push (with production environment protection)

