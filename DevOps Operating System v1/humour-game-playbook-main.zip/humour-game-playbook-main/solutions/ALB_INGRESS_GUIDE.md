# Complete Guide: Exposing Your Application with ALB via Kubernetes Ingress

**Difficulty:** Beginner to Intermediate  
**Time:** ~45 minutes  
**Prerequisites:** EKS cluster, backend/frontend deployments running

---

## 🎯 What You'll Build

```
Internet → ALB (Ingress-managed) → Target Groups → Pod IPs → Your Application
```

**Simple explanation:**
- **Ingress** = Kubernetes resource that defines routing rules
- **ALB** = AWS Load Balancer (created automatically by Ingress Controller)
- **Target Groups** = Lists of Pod IPs (created automatically)
- **Path-based routing** = `/api` → Backend, `/` → Frontend

---

## ✅ Prerequisites Checklist

**Before starting, verify you have:**

- [ ] EKS cluster created and running
- [ ] Backend pods running (`kubectl get pods -n h-game -l app=backend`)
- [ ] Frontend pods running (`kubectl get pods -n h-game -l app=frontend`)
- [ ] Backend and frontend services created
- [ ] Database migrated to RDS (tables exist)
- [ ] Redis/ElastiCache accessible
- [ ] OIDC provider created in IAM
- [ ] AWS Load Balancer Controller installed

### Quick Prerequisites Setup

If any items above are missing, follow these steps:

#### 1. Verify EKS Cluster

```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform output eks_cluster_name
# Should show: h-game-prod
```

#### 2. Create OIDC Provider (Required for Controller)

**Check if it exists:**
```bash
aws eks describe-cluster --name h-game-prod --query "cluster.identity.oidc.issuer" --output text
# Should return: https://oidc.eks.us-east-1.amazonaws.com/id/...

# Check if provider exists in IAM
aws iam list-open-id-connect-providers | grep -i eks
```

**If missing, add to `h-game-terraform/iam.tf`:**

```hcl
# ============================================
# EKS OIDC PROVIDER
# ============================================
# Required for IAM Roles for Service Accounts (IRSA)

data "tls_certificate" "eks" {
  url = aws_eks_cluster.main.identity[0].oidc[0].issuer
}

resource "aws_iam_openid_connect_provider" "eks" {
  client_id_list  = ["sts.amazonaws.com"]
  thumbprint_list = [data.tls_certificate.eks.certificates[0].sha1_fingerprint]
  url             = aws_eks_cluster.main.identity[0].oidc[0].issuer

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-eks-oidc-provider"
      Task = "T7"
    }
  )
}
```

**Add TLS provider to `h-game-terraform/provider.tf`:**

```hcl
required_providers {
  aws = {
    source  = "hashicorp/aws"
    version = "~> 6.0"
  }
  tls = {
    source  = "hashicorp/tls"
    version = "~> 4.0"
  }
}
```

**Apply:**
```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform init
terraform apply -target=aws_iam_openid_connect_provider.eks -target=data.tls_certificate.eks
```

#### 3. Install AWS Load Balancer Controller

**Check if installed:**
```bash
kubectl get deployment -n kube-system aws-load-balancer-controller
```

**If not installed:**

```bash
# Add Helm repo
helm repo add eks https://aws.github.io/eks-charts
helm repo update

# Get cluster name
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
CLUSTER_NAME=$(terraform output -raw eks_cluster_name)

# Install controller
helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system \
  --set clusterName=$CLUSTER_NAME \
  --set serviceAccount.create=false \
  --set serviceAccount.name=aws-load-balancer-controller

# Wait for pods
sleep 30
kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller
```

**Verify IAM role is attached:**
```bash
kubectl get sa aws-load-balancer-controller -n kube-system \
  -o jsonpath='{.metadata.annotations.eks\.amazonaws\.com/role-arn}'
# Should show: arn:aws:iam::...:role/...
```

#### 4. Run Database Migration (If Not Done)

**Check if tables exist:**
```bash
# Test via backend pod
kubectl exec -n h-game $(kubectl get pods -n h-game -l app=backend -o jsonpath='{.items[0].metadata.name}') -- \
  node -e "const {Pool}=require('pg'); const p=new Pool({host:process.env.DB_HOST,user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME}); p.query('SELECT 1 FROM users LIMIT 1').then(()=>console.log('✅ Tables exist')).catch(e=>console.log('❌ Tables missing:',e.message));"
```

**If tables are missing, run migration:**
```bash
# Apply migration ConfigMap and Job
kubectl apply -f k8s/postgres-migration-configmap.yaml
kubectl apply -f k8s/postgres-migration-job.yaml

# Watch migration
kubectl logs -f job/postgres-migration -n h-game

# Verify success
kubectl get job postgres-migration -n h-game
# Should show: COMPLETIONS 1/1
```

#### 5. Verify Services Are Running

```bash
# Check pods
kubectl get pods -n h-game

# Check services
kubectl get svc -n h-game

# Test backend health
kubectl port-forward -n h-game svc/backend-service 3001:3001 &
curl http://localhost:3001/health
pkill -f "kubectl port-forward"

# Test frontend health
kubectl port-forward -n h-game svc/frontend-service 8080:80 &
curl http://localhost:8080/health
pkill -f "kubectl port-forward"
```

---

## Step 0: Configure Variables

**Why:** Variables separate configuration from code, making infrastructure reusable.

**Add ALB variables to `h-game-terraform/variables.tf`:**

```hcl
# ============================================
# ALB VARIABLES
# ============================================

variable "alb_name" {
  description = "Name of the Application Load Balancer"
  type        = string
  default     = "h-game-alb"
}

variable "backend_port" {
  description = "Backend application port"
  type        = number
  default     = 3001
}

variable "alb_health_check_path" {
  description = "Health check path for ALB target group"
  type        = string
  default     = "/health"
  
  validation {
    condition     = can(regex("^/.*$", var.alb_health_check_path))
    error_message = "Health check path must start with / (e.g., /health)."
  }
}

variable "alb_health_check_timeout" {
  description = "Health check timeout in seconds"
  type        = number
  default     = 5
}

variable "alb_health_check_interval" {
  description = "Health check interval in seconds"
  type        = number
  default     = 30
}

variable "alb_health_check_healthy_threshold" {
  description = "Number of consecutive successful health checks required to mark target as healthy"
  type        = number
  default     = 2
}

variable "alb_health_check_unhealthy_threshold" {
  description = "Number of consecutive failed health checks required to mark target as unhealthy"
  type        = number
  default     = 2
}

variable "alb_deregistration_delay" {
  description = "Time in seconds to wait before removing unhealthy target"
  type        = number
  default     = 30
}

variable "alb_enable_deletion_protection" {
  description = "Enable ALB deletion protection"
  type        = bool
  default     = false  # Set to true for production
}
```

**Add to `h-game-terraform/terraform.tfvars`:**

```hcl
# ALB Configuration
alb_name                        = "h-game-alb"
backend_port                    = 3001
alb_health_check_path            = "/health"
alb_health_check_timeout         = 5
alb_health_check_interval        = 30
alb_health_check_healthy_threshold   = 2
alb_health_check_unhealthy_threshold = 2
alb_deregistration_delay         = 30
alb_enable_deletion_protection   = false
```

**Apply variables:**
```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform fmt
terraform validate
```

✅ **Checkpoint:** Variables configured!

---

## Step 1: Ensure ALB Security Group Exists

**Why:** The Ingress controller needs a security group to attach to the ALB it creates.

**Check if it exists in `h-game-terraform/security-groups.tf`:**

```hcl
resource "aws_security_group" "alb" {
  name        = "${local.name_prefix}-alb-sg"
  description = "Security group for Application Load Balancer"
  vpc_id      = aws_vpc.main.id

  ingress {
    description = "HTTP from internet"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "HTTPS from internet"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
```

**If missing, add it. Then apply:**
```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform apply -target=aws_security_group.alb
```

**Get the security group ID:**
```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform output -raw alb_security_group_id
# Save this value - you'll need it in Step 2
```

✅ **Checkpoint:** ALB security group ready!

---

## Step 2: Configure Security Groups for Pod Access

**Why:** With IP target type, ALB routes directly to Pod IPs. We need to allow ALB → Pods communication.

**Add to `h-game-terraform/security-groups.tf`:**

```hcl
# ============================================
# EKS-Managed Security Group Rules
# ============================================
# EKS automatically creates a security group for the cluster
# These rules allow ALB to reach pods on the EKS-managed security group

data "aws_security_group" "eks_cluster_managed" {
  filter {
    name   = "tag:aws:eks:cluster-name"
    values = [aws_eks_cluster.main.name]
  }
  filter {
    name   = "tag:Name"
    values = ["eks-cluster-sg-${aws_eks_cluster.main.name}-*"]
  }
}

# Allow ALB to reach backend pods (port 3001)
resource "aws_security_group_rule" "alb_to_eks_managed_nodes_backend" {
  description              = "Allow ALB to reach backend pods on EKS-managed node security group"
  type                     = "ingress"
  from_port                = var.backend_port  # 3001
  to_port                  = var.backend_port
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.alb.id
  security_group_id        = data.aws_security_group.eks_cluster_managed.id
  
  lifecycle {
    create_before_destroy = true
  }
}

# Allow ALB to reach frontend pods (port 80)
resource "aws_security_group_rule" "alb_to_eks_managed_nodes_frontend" {
  description              = "Allow ALB to reach frontend pods on EKS-managed node security group"
  type                     = "ingress"
  from_port                = 80
  to_port                  = 80
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.alb.id
  security_group_id        = data.aws_security_group.eks_cluster_managed.id
  
  lifecycle {
    create_before_destroy = true
  }
}
```

**Apply:**
```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform apply -target=data.aws_security_group.eks_cluster_managed \
  -target=aws_security_group_rule.alb_to_eks_managed_nodes_backend \
  -target=aws_security_group_rule.alb_to_eks_managed_nodes_frontend
```

✅ **Checkpoint:** Security groups configured!

---

## Step 3: Verify Service Types

**Why:** Ingress works with ClusterIP services (default). Verify your services are correct.

**Check backend service (`k8s/backend-service.yaml`):**

```yaml
apiVersion: v1
kind: Service
metadata:
  name: backend-service
  namespace: h-game
spec:
  type: ClusterIP  # ✅ Correct for Ingress
  selector:
    app: backend
  ports:
  - port: 3001
    targetPort: 3001
```

**Check frontend service (`k8s/frontend-service.yaml`):**

```yaml
apiVersion: v1
kind: Service
metadata:
  name: frontend-service
  namespace: h-game
spec:
  type: ClusterIP  # ✅ Correct for Ingress
  selector:
    app: frontend
  ports:
  - port: 80
    targetPort: 80  # ✅ Frontend runs on port 80
```

**Apply if needed:**
```bash
kubectl apply -f k8s/backend-service.yaml
kubectl apply -f k8s/frontend-service.yaml
```

✅ **Checkpoint:** Services configured correctly!

---

## Step 4: Create Ingress Resource

**Why:** Ingress is the Kubernetes-native way to expose services. It automatically creates and manages the ALB.

**Get Terraform outputs:**
```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"

# Get ALB security group ID
ALB_SG=$(terraform output -raw alb_security_group_id)
echo "ALB Security Group: $ALB_SG"

# Get public subnet IDs
PUBLIC_SUBNETS=$(terraform output -json public_subnet_ids | jq -r 'join(",")')
echo "Public Subnets: $PUBLIC_SUBNETS"
```

**Create `k8s/ingress.yaml`:**

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: h-game
  namespace: h-game
  annotations:
    # ALB Configuration
    alb.ingress.kubernetes.io/scheme: internet-facing
    alb.ingress.kubernetes.io/target-type: ip
    alb.ingress.kubernetes.io/security-groups: REPLACE_WITH_ALB_SG
    alb.ingress.kubernetes.io/subnets: REPLACE_WITH_PUBLIC_SUBNETS
    
    # Health Check Configuration
    alb.ingress.kubernetes.io/healthcheck-interval-seconds: '15'
    alb.ingress.kubernetes.io/healthcheck-timeout-seconds: '10'
    alb.ingress.kubernetes.io/healthcheck-path: /health
    alb.ingress.kubernetes.io/healthy-threshold-count: '2'
    alb.ingress.kubernetes.io/unhealthy-threshold-count: '3'
    
    # ALB Name
    alb.ingress.kubernetes.io/load-balancer-name: h-game-alb-ingress

spec:
  ingressClassName: alb
  rules:
  - http:
      paths:
      # Backend API routes (specific paths first - order matters!)
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: backend-service
            port:
              number: 3001
      
      # Health check endpoint
      - path: /health
        pathType: Exact
        backend:
          service:
            name: backend-service
            port:
              number: 3001
      
      # Frontend routes (catch-all, comes last)
      - path: /
        pathType: Prefix
        backend:
          service:
            name: frontend-service
            port:
              number: 80
```

**Replace placeholders:**
```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
ALB_SG=$(terraform output -raw alb_security_group_id)
PUBLIC_SUBNETS=$(terraform output -json public_subnet_ids | jq -r 'join(",")')

cd ../k8s

# Replace placeholders (macOS syntax)
sed -i '' "s|REPLACE_WITH_ALB_SG|$ALB_SG|g" ingress.yaml
sed -i '' "s|REPLACE_WITH_PUBLIC_SUBNETS|$PUBLIC_SUBNETS|g" ingress.yaml

# Verify replacements
grep -E "security-groups|subnets" ingress.yaml
```

**Apply Ingress:**
```bash
kubectl apply -f k8s/ingress.yaml
```

**Watch Ingress creation:**
```bash
# Watch for ADDRESS to appear (takes 2-3 minutes)
kubectl get ingress h-game -n h-game -w

# Press Ctrl+C when you see the ADDRESS column populated
```

**Expected output:**
```
NAME     CLASS   HOSTS   ADDRESS                                                     PORTS   AGE
h-game   alb     *       h-game-alb-ingress-XXXXX.us-east-1.elb.amazonaws.com   80      2m
```

✅ **Checkpoint:** Ingress created! ALB is being provisioned.

---

## Step 5: Wait for ALB Provisioning

**Why:** AWS needs 2-3 minutes to create the ALB infrastructure.

**Monitor progress:**
```bash
# Check Ingress status
kubectl get ingress h-game -n h-game

# Check controller logs
kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=20

# Wait for ADDRESS
echo "Waiting for ALB to be created..."
while [ -z "$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')" ]; do
  echo "Still waiting... (checking every 10 seconds)"
  sleep 10
done

ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
echo "✅ ALB created: http://$ALB_URL"
```

**Expected wait time:** 2-3 minutes

✅ **Checkpoint:** ALB is provisioning!

---

## Step 6: Verify Target Registration

**Why:** Ensure Pod IPs are registered and healthy in the target groups.

**Wait for targets to register:**
```bash
# Wait 60 seconds for targets to register
echo "Waiting 60 seconds for targets to register..."
sleep 60

# Get target group ARNs created by Ingress
aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `k8s-hgame`)].{Name:TargetGroupName,ARN:TargetGroupArn}' \
  --output table
```

**Check target health:**
```bash
# Get backend target group ARN
BACKEND_TG=$(aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `backend`)].TargetGroupArn' \
  --output text | head -1)

# Check backend targets
aws elbv2 describe-target-health --target-group-arn "$BACKEND_TG" \
  --output json | jq '.TargetHealthDescriptions[] | {Target: .Target.Id, State: .TargetHealth.State}'

# Get frontend target group ARN
FRONTEND_TG=$(aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `frontend`)].TargetGroupArn' \
  --output text | head -1)

# Check frontend targets
aws elbv2 describe-target-health --target-group-arn "$FRONTEND_TG" \
  --output json | jq '.TargetHealthDescriptions[] | {Target: .Target.Id, State: .TargetHealth.State}'
```

**Expected output:**
```json
{
  "Target": "10.0.11.129",
  "State": "healthy"
}
```

**If targets show "initial" or "unhealthy":**
- Wait another 60 seconds (health checks need time)
- Check security group rules (Step 2)
- Verify pods are running: `kubectl get pods -n h-game`

✅ **Checkpoint:** Targets registered and healthy!

---

## Step 7: Test Your Application

**Why:** Verify everything works end-to-end.

**Get ALB URL:**
```bash
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
echo "Your ALB URL: http://$ALB_URL"
```

**Test endpoints:**

```bash
# 1. Health check
echo "=== Testing Health Endpoint ==="
curl -s http://$ALB_URL/health | jq '.'

# Expected: {"status":"healthy","services":{"database":"connected",...}}

# 2. API welcome
echo ""
echo "=== Testing API Endpoint ==="
curl -s http://$ALB_URL/api | jq '.message'

# Expected: "Welcome to the Humor Memory Game API! 🎮😂"

# 3. Leaderboard
echo ""
echo "=== Testing Leaderboard ==="
curl -s http://$ALB_URL/api/leaderboard | jq '.success, (.leaderboard | length)'

# Expected: true, 8

# 4. Game start
echo ""
echo "=== Testing Game Start ==="
curl -s -X POST http://$ALB_URL/api/game/start \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser"}' | jq '.success, .message'

# Expected: true, "🎯 Game started! Good luck, testuser! 🍀"

# 5. Frontend (in browser)
echo ""
echo "=== Frontend URL ==="
echo "Open in browser: http://$ALB_URL"
```

**Test in browser:**
1. Open `http://$ALB_URL` in your browser
2. You should see the game UI
3. Try starting a new game
4. Verify it works without errors

✅ **Checkpoint:** Application is accessible and working!

---

## Step 8: Update Frontend API URL

**Why:** Frontend needs to know the ALB URL to make API calls.

**Get ALB URL:**
```bash
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
echo "ALB URL: http://$ALB_URL"
```

**Update frontend deployment (`k8s/frontend-deployment.yaml`):**

```yaml
env:
- name: API_BASE_URL
  value: "http://$ALB_URL/api"  # Replace $ALB_URL with actual value
- name: NODE_ENV
  value: "production"
```

**Or use sed to replace:**
```bash
cd "/Users/mac/Desktop/devops playbook/k8s"
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

# Replace in frontend deployment (macOS syntax)
sed -i '' "s|value: \".*api\"|value: \"http://$ALB_URL/api\"|g" frontend-deployment.yaml

# Apply updated deployment
kubectl apply -f frontend-deployment.yaml

# Wait for rollout
kubectl rollout status deployment/frontend -n h-game
```

✅ **Checkpoint:** Frontend configured with correct API URL!

---

## 🎉 Success! What You've Accomplished

✅ Created Kubernetes Ingress resource  
✅ ALB automatically created and managed by Kubernetes  
✅ Target groups automatically created  
✅ Path-based routing configured (`/api` → Backend, `/` → Frontend)  
✅ Pod IPs automatically registered as targets  
✅ Security groups configured for ALB → Pods communication  
✅ Application accessible via public URL  

**Your application is now accessible at:**
```
http://h-game-alb-ingress-XXXXX.us-east-1.elb.amazonaws.com
```

---

## 🔧 Troubleshooting

### Issue 1: Ingress Has No ADDRESS

**Symptom:** `kubectl get ingress` shows empty ADDRESS column

**Diagnosis:**
```bash
# Check Ingress events
kubectl describe ingress h-game -n h-game | tail -20

# Check controller logs
kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50
```

**Common causes:**
- Security group not found → Verify `ALB_SG` value
- Subnet not found → Verify `PUBLIC_SUBNETS` value
- IAM permissions missing → Check controller IAM role
- OIDC provider missing → Create OIDC provider (see Prerequisites)

**Fix:**
```bash
# Verify security group exists
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform output alb_security_group_id

# Verify subnets
terraform output public_subnet_ids

# Check controller IAM role
kubectl get sa aws-load-balancer-controller -n kube-system \
  -o jsonpath='{.metadata.annotations.eks\.amazonaws\.com/role-arn}'
```

---

### Issue 2: Targets Not Registering

**Symptom:** Target groups show no targets or targets are unhealthy

**Diagnosis:**
```bash
# Check target groups
aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `k8s-hgame`)].TargetGroupName' \
  --output text

# Check target health
TG_ARN="<target-group-arn>"
aws elbv2 describe-target-health --target-group-arn "$TG_ARN"
```

**Fixes:**

**A. Security group rules missing:**
```bash
# Verify security group rules exist
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform apply -target=aws_security_group_rule.alb_to_eks_managed_nodes_backend \
  -target=aws_security_group_rule.alb_to_eks_managed_nodes_frontend
```

**B. Pods not running:**
```bash
kubectl get pods -n h-game
kubectl describe pod <pod-name> -n h-game
```

**C. Health check failing:**
```bash
# Test health endpoint from pod
kubectl exec -n h-game <pod-name> -- curl -s http://localhost:3001/health
```

---

### Issue 3: Frontend Timeout (504 Gateway Timeout)

**Symptom:** Frontend shows timeout, backend works

**Diagnosis:**
```bash
# Check frontend target health
FRONTEND_TG=$(aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `frontend`)].TargetGroupArn' \
  --output text | head -1)

aws elbv2 describe-target-health --target-group-arn "$FRONTEND_TG"
```

**Fix:**
```bash
# Verify security group rule for port 80 exists
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform apply -target=aws_security_group_rule.alb_to_eks_managed_nodes_frontend

# Verify frontend pods are running
kubectl get pods -n h-game -l app=frontend

# Test frontend health endpoint
kubectl exec -n h-game $(kubectl get pods -n h-game -l app=frontend -o jsonpath='{.items[0].metadata.name}') -- \
  curl -s http://localhost:80/health
```

---

### Issue 4: "relation users does not exist" (500 Error)

**Symptom:** Game start returns 500 error

**Diagnosis:**
```bash
# Check backend logs
kubectl logs -n h-game -l app=backend --tail=50 | grep -i "relation\|users\|error"
```

**Fix:**
```bash
# Run database migration
kubectl apply -f k8s/postgres-migration-configmap.yaml
kubectl apply -f k8s/postgres-migration-job.yaml

# Watch migration
kubectl logs -f job/postgres-migration -n h-game

# Verify tables exist
kubectl exec -n h-game $(kubectl get pods -n h-game -l app=backend -o jsonpath='{.items[0].metadata.name}') -- \
  node -e "const {Pool}=require('pg'); const p=new Pool({host:process.env.DB_HOST,user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME}); p.query('SELECT COUNT(*) FROM users').then(r=>console.log('✅ Users table exists:',r.rows[0].count)).catch(e=>console.log('❌ Error:',e.message));"
```

---

### Issue 5: Controller Not Working

**Symptom:** Controller pods crashing or not starting

**Diagnosis:**
```bash
# Check controller status
kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller

# Check logs
kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50
```

**Common errors:**

**A. "No OpenIDConnect provider found":**
```bash
# Create OIDC provider (see Prerequisites section)
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform apply -target=aws_iam_openid_connect_provider.eks

# Restart controller
kubectl rollout restart deployment aws-load-balancer-controller -n kube-system
```

**B. "DescribeListenerAttributes permission denied":**
```bash
# Add missing permission to IAM policy
# In iam.tf, add to aws_iam_policy.aws_load_balancer_controller:
"elasticloadbalancing:DescribeListenerAttributes",

# Apply
terraform apply -target=aws_iam_policy.aws_load_balancer_controller

# Restart controller
kubectl rollout restart deployment aws-load-balancer-controller -n kube-system
```

---

### Issue 6: Wrong Routing (404 on /api)

**Symptom:** `/api` endpoints return 404

**Diagnosis:**
```bash
# Check Ingress path order
kubectl get ingress h-game -n h-game -o yaml | grep -A 30 "rules:"
```

**Fix:**
Path order matters! Specific paths (`/api`, `/health`) must come **before** catch-all (`/`).

**Correct order:**
```yaml
paths:
- path: /api        # ✅ First (specific)
- path: /health     # ✅ Second (specific)
- path: /           # ✅ Last (catch-all)
```

**Wrong order:**
```yaml
paths:
- path: /           # ❌ Wrong! Catches everything first
- path: /api        # ❌ Never reached
```

---

## 📚 Key Concepts Explained

### Ingress vs Manual ALB

**Ingress (What we used):**
- ✅ Kubernetes-native
- ✅ One YAML file
- ✅ Automatic ALB management
- ✅ Industry standard
- ✅ Easy path-based routing

**Manual ALB (Alternative):**
- Educational (understand components)
- More control
- More files to manage
- More steps

### Path-Based Routing

**How it works:**
1. Request comes to ALB: `http://alb-url/api/leaderboard`
2. ALB checks paths in order:
   - `/api` matches → Route to backend-service:3001
   - Request forwarded to backend pod
3. Backend responds with leaderboard data

**Path matching:**
- `Prefix` = Matches path and all sub-paths
  - `/api` matches `/api`, `/api/leaderboard`, `/api/game/start`
- `Exact` = Matches only exact path
  - `/health` matches only `/health` (not `/health/check`)

### IP Target Type

**What it means:**
- ALB routes directly to Pod IPs (e.g., `10.0.11.129`)
- Not node IPs (e.g., `10.0.11.50`)

**Why it's better:**
- Pod-level health checks
- Works when pods move between nodes
- Better for Kubernetes

---

## 🚀 Next Steps (Optional Enhancements)

### 1. Add HTTPS/SSL

**Add ACM certificate annotation to Ingress:**
```yaml
annotations:
  alb.ingress.kubernetes.io/certificate-arn: arn:aws:acm:...
  alb.ingress.kubernetes.io/ssl-policy: ELBSecurityPolicy-TLS-1-2-2017-01
  alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
  alb.ingress.kubernetes.io/ssl-redirect: '443'
```

### 2. Add Custom Domain

**Create Route53 record:**
```bash
# Get ALB DNS name
ALB_DNS=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
ALB_ZONE=$(aws elbv2 describe-load-balancers \
  --query "LoadBalancers[?DNSName=='$ALB_DNS'].CanonicalHostedZoneId" \
  --output text)

# Create Route53 record (replace with your domain)
aws route53 change-resource-record-sets \
  --hosted-zone-id YOUR_ZONE_ID \
  --change-batch '{
    "Changes": [{
      "Action": "UPSERT",
      "ResourceRecordSet": {
        "Name": "game.yourdomain.com",
        "Type": "A",
        "AliasTarget": {
          "DNSName": "'$ALB_DNS'",
          "HostedZoneId": "'$ALB_ZONE'",
          "EvaluateTargetHealth": true
        }
      }
    }]
  }'
```

### 3. Enable Access Logs

**Add annotation:**
```yaml
annotations:
  alb.ingress.kubernetes.io/load-balancer-attributes: |
    access_logs.s3.enabled=true,
    access_logs.s3.bucket=your-logs-bucket
```

---

## ✅ Final Verification Checklist

- [ ] Ingress created and has ADDRESS
- [ ] ALB visible in AWS Console
- [ ] Target groups created (backend and frontend)
- [ ] Targets registered and healthy
- [ ] Health endpoint works: `curl http://$ALB_URL/health`
- [ ] API endpoint works: `curl http://$ALB_URL/api`
- [ ] Frontend loads in browser: `http://$ALB_URL`
- [ ] Game start works: No 500 errors
- [ ] Leaderboard loads: `curl http://$ALB_URL/api/leaderboard`

---

## 🎓 What You Learned

1. **Kubernetes Ingress** - Industry-standard way to expose services
2. **AWS Load Balancer Controller** - Automates ALB management
3. **Path-based routing** - Route different paths to different services
4. **IP target type** - Direct pod-level routing
5. **Security groups** - Network isolation for ALB → Pods
6. **Troubleshooting** - How to diagnose and fix common issues

---

## 📖 Additional Resources

- [AWS Load Balancer Controller Docs](https://kubernetes-sigs.github.io/aws-load-balancer-controller/)
- [Kubernetes Ingress Documentation](https://kubernetes.io/docs/concepts/services-networking/ingress/)
- [ALB Best Practices](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/best-practices.html)

---

**Congratulations!** 🎉 You've successfully exposed your application using production-grade Kubernetes Ingress with automatic ALB management!

