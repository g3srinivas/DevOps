# 🚀 Complete Guide: Deploy to EKS and Access via Ingress

**⏱️ Total Time:** ~15-20 minutes  
**📋 Difficulty:** Beginner-friendly with step-by-step instructions

---

## 📋 Before You Start: Prerequisites Checklist

**✅ Check each item before proceeding:**

- [ ] **Terraform infrastructure is deployed** (EKS cluster, RDS, ElastiCache, ECR repositories exist)
- [ ] **AWS CLI is installed and configured** (`aws --version` should work)
- [ ] **kubectl is installed** (`kubectl version --client` should work)
- [ ] **Docker is installed** (`docker --version` should work)
- [ ] **jq is installed** (`jq --version` should work) - for JSON parsing
- [ ] **Helm is installed** (for Load Balancer Controller) - `helm version` should work
- [ ] **You have AWS credentials configured** (`aws sts get-caller-identity` should show your account)
- [ ] **You're in the correct directory:** `/Users/mac/Desktop/devops playbook`

**❓ Not sure if something is installed?**
```bash
# Test each tool
aws --version
kubectl version --client
docker --version
jq --version
helm version
```

**🔧 Need to install something?**
- **AWS CLI:** https://aws.amazon.com/cli/
- **kubectl:** https://kubernetes.io/docs/tasks/tools/
- **Docker:** https://www.docker.com/products/docker-desktop
- **jq:** `brew install jq` (macOS) or `sudo apt-get install jq` (Linux)
- **Helm:** `brew install helm` (macOS) or see https://helm.sh/docs/intro/install/

---

## 🎯 What You're Building

**In simple terms:**
1. Connect to your EKS cluster (Kubernetes)
2. Install a controller that creates AWS Load Balancers
3. Deploy your backend application (API server)
4. Deploy your frontend application (web UI)
5. Create an Ingress (load balancer) to expose everything
6. Connect frontend to backend automatically
7. Run database migration to create tables

**End result:** Your game application accessible via a public URL!

---

## 📍 Step 1: Connect to Your EKS Cluster

**⏱️ Time:** 1 minute  
**🎯 What this does:** Configures `kubectl` to talk to your EKS cluster

```bash
# Navigate to Terraform directory
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"

# Get cluster name from Terraform
CLUSTER_NAME=$(terraform output -raw eks_cluster_name)
REGION=$(terraform output -raw aws_region || echo "us-east-1")

echo "📡 Connecting to cluster: $CLUSTER_NAME in region: $REGION"

# Configure kubectl to use this cluster
aws eks update-kubeconfig --name $CLUSTER_NAME --region $REGION

# ✅ VERIFY: Check if connection works
echo ""
echo "🔍 Verifying connection..."
kubectl get nodes
```

**✅ What you should see:**
```
NAME                          STATUS   ROLES    AGE   VERSION
ip-10-0-1-xxx.ec2.internal    Ready    <none>   5d    v1.28.x
ip-10-0-2-xxx.ec2.internal    Ready    <none>   5d    v1.28.x
```

**❌ If you see an error:**
- **"Unable to locate credentials"** → Run `aws configure` first
- **"cluster not found"** → Make sure Terraform has been applied
- **"command not found: kubectl"** → Install kubectl (see prerequisites)

**💡 What's happening:** `kubectl` is now configured to communicate with your EKS cluster. All future `kubectl` commands will target this cluster.

---

## 📍 Step 2: Install AWS Load Balancer Controller

**⏱️ Time:** 2-3 minutes  
**🎯 What this does:** Installs a Kubernetes controller that creates AWS Application Load Balancers (ALBs) when you create an Ingress

**First, check if it's already installed:**
```bash
kubectl get deployment -n kube-system aws-load-balancer-controller 2>/dev/null && echo "✅ Already installed - skip to Step 3" || echo "❌ Need to install"
```

**If you see "Need to install", continue:**

```bash
# Make sure Helm is installed
helm version
# If not installed: brew install helm (macOS) or see https://helm.sh/docs/intro/install/

# Add the AWS EKS Helm repository
echo "📦 Adding Helm repository..."
helm repo add eks https://aws.github.io/eks-charts
helm repo update

# Get cluster name and IAM role ARN from Terraform
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
CLUSTER_NAME=$(terraform output -raw eks_cluster_name)
ROLE_ARN=$(terraform output -raw aws_load_balancer_controller_role_arn)

echo "📋 Cluster: $CLUSTER_NAME"
echo "📋 Role ARN: $ROLE_ARN"

# Create namespace (if it doesn't exist)
kubectl create namespace kube-system 2>/dev/null || echo "Namespace already exists"

# Create service account with IAM role annotation
echo "🔐 Creating service account..."
kubectl create serviceaccount aws-load-balancer-controller -n kube-system 2>/dev/null || \
kubectl annotate serviceaccount aws-load-balancer-controller -n kube-system \
  eks.amazonaws.com/role-arn=$ROLE_ARN --overwrite

# Install the controller using Helm
echo "🚀 Installing AWS Load Balancer Controller..."
helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system \
  --set clusterName=$CLUSTER_NAME \
  --set serviceAccount.create=false \
  --set serviceAccount.name=aws-load-balancer-controller

# Wait for controller to start (this takes 30-60 seconds)
echo ""
echo "⏳ Waiting for controller to start (this takes ~1 minute)..."
kubectl wait --for=condition=available --timeout=300s \
  deployment/aws-load-balancer-controller -n kube-system

# ✅ VERIFY: Check if controller is running
echo ""
echo "🔍 Verifying controller is running..."
kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller
```

**✅ What you should see:**
```
NAME                                           READY   STATUS    RESTARTS   AGE
aws-load-balancer-controller-xxxxxxxxx-xxxxx   1/1     Running   0          30s
```

**❌ If you see "Pending" or "CrashLoopBackOff":**
- Check logs: `kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50`
- Common issue: IAM role permissions - check the troubleshooting section

**💡 What's happening:** The controller watches for Ingress resources and automatically creates AWS ALBs. Without this, your Ingress won't get an ADDRESS.

---

## 📍 Step 3: Create Kubernetes Namespace

**⏱️ Time:** 5 seconds  
**🎯 What this does:** Creates a namespace (like a folder) to organize your application resources

```bash
# Create namespace for your application
kubectl create namespace h-game 2>/dev/null || echo "✅ Namespace already exists"

# ✅ VERIFY
kubectl get namespace h-game
```

**✅ What you should see:**
```
NAME     STATUS   AGE
h-game   Active   5s
```

**💡 What's happening:** All your application resources (pods, services, etc.) will be created in this namespace. This keeps them organized and separate from other applications.

---

## 📍 Step 4: Create Secrets and ConfigMaps

**⏱️ Time:** 2-3 minutes  
**🎯 What this does:** 
- Creates a ConfigMap with application settings
- Syncs your RDS database password from AWS Secrets Manager to Kubernetes (so pods can use it)

```bash
cd "/Users/mac/Desktop/devops playbook/k8s"

# Step 4a: Create ConfigMap (application settings)
echo "📝 Creating ConfigMap..."
kubectl apply -f app-config.yaml

# ✅ VERIFY ConfigMap
kubectl get configmap -n h-game
```

**✅ What you should see:**
```
NAME          DATA   AGE
app-config    3      5s
```

**Now, sync the database secret from AWS Secrets Manager:**

```bash
# Step 4b: Get secret ARN from Terraform
# ⚠️ IMPORTANT: Must run from terraform directory
cd "../h-game-terraform"
SECRET_ARN=$(terraform output -raw rds_password_secret_arn)
REGION="us-east-1"  # Change if your region is different

echo "🔍 Secret ARN: $SECRET_ARN"

# Check if we got the ARN
if [ -z "$SECRET_ARN" ]; then
  echo "❌ ERROR: Could not get secret ARN from Terraform"
  echo "   Make sure you're in the h-game-terraform directory"
  echo "   Make sure Terraform has been applied"
  exit 1
fi

# Step 4c: Retrieve secret from AWS Secrets Manager
echo "🔐 Retrieving secret from AWS Secrets Manager..."
SECRET_JSON=$(aws secretsmanager get-secret-value \
  --secret-id "$SECRET_ARN" \
  --region "$REGION" \
  --query SecretString \
  --output text)

# Check if we got the secret
if [ -z "$SECRET_JSON" ]; then
  echo "❌ ERROR: Could not retrieve secret from AWS Secrets Manager"
  echo "   Check your AWS credentials: aws sts get-caller-identity"
  exit 1
fi

# Step 4d: Extract database credentials from JSON
echo "📋 Extracting credentials..."
DB_USER=$(echo "$SECRET_JSON" | jq -r '.username')
DB_PASSWORD=$(echo "$SECRET_JSON" | jq -r '.password')
DB_NAME=$(echo "$SECRET_JSON" | jq -r '.dbname')

echo "✅ Extracted: User=$DB_USER, Database=$DB_NAME"

# Step 4e: Create Kubernetes secret
cd "../k8s"
echo "🔐 Creating Kubernetes secret..."
kubectl create secret generic postgres-secret \
  --from-literal=postgres-user="$DB_USER" \
  --from-literal=postgres-password="$DB_PASSWORD" \
  --from-literal=postgres-db="$DB_NAME" \
  --namespace=h-game \
  --dry-run=client -o yaml | kubectl apply -f -

# ✅ VERIFY: Secret should show DATA 3 (not 0!)
echo ""
echo "🔍 Verifying secret was created..."
kubectl get secret postgres-secret -n h-game
```

**✅ What you should see:**
```
NAME              TYPE     DATA   AGE
postgres-secret   Opaque   3     5s
```

**❌ If DATA is 0:**
- The secret is empty - check the troubleshooting section "Secret Shows 0 DATA"
- Make sure you ran all the commands above in order

**💡 What's happening:** 
- **ConfigMap:** Stores non-sensitive configuration (like app settings)
- **Secret:** Stores sensitive data (database password). Kubernetes will inject this into your backend pods so they can connect to RDS.

**🤔 Why sync from AWS Secrets Manager?**
- Your password is already in AWS Secrets Manager (created by Terraform)
- Kubernetes can't directly read from AWS Secrets Manager (unless you use a special driver)
- So we sync it once - Kubernetes gets its own copy
- If you change the password in AWS later, you'll need to update the Kubernetes secret too

---

## 📍 Step 5: Build and Push Docker Images

**⏱️ Time:** 5-10 minutes (depends on image size)  
**🎯 What this does:** Builds your application Docker images and pushes them to AWS ECR (Elastic Container Registry) so Kubernetes can pull them

**⚠️ IMPORTANT:** You must do this BEFORE deploying pods, otherwise pods will fail with `ImagePullBackOff` error.

**Option A: Use CI/CD (Recommended - if you have GitHub Actions set up)**
```bash
# Push code to trigger build
git add .
git commit -m "Trigger build"
git push origin main

# Then go to GitHub → Actions → Wait for build to complete
# Skip to Step 6 once images are built
```

**Option B: Build and Push Manually**

```bash
# ⚠️ IMPORTANT: Start from terraform directory to get ECR URLs
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"

# Get ECR repository URLs
ECR_REGISTRY=$(terraform output -raw ecr_backend_repository_url | cut -d/ -f1)
ECR_BACKEND=$(terraform output -raw ecr_backend_repository_url)
ECR_FRONTEND=$(terraform output -raw ecr_frontend_repository_url)

echo "📦 ECR Registry: $ECR_REGISTRY"
echo "📦 Backend Repository: $ECR_BACKEND"
echo "📦 Frontend Repository: $ECR_FRONTEND"

# Verify we got the URLs
if [ -z "$ECR_BACKEND" ] || [ -z "$ECR_FRONTEND" ]; then
  echo "❌ ERROR: Could not get ECR URLs from Terraform"
  exit 1
fi

# Login to ECR (so Docker can push images)
echo "🔐 Logging into ECR..."
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin $ECR_REGISTRY

# Build and push BACKEND image
echo ""
echo "🔨 Building backend image..."
cd ../backend
docker build -t "${ECR_BACKEND}:latest" .
echo "📤 Pushing backend image..."
docker push "${ECR_BACKEND}:latest"

# Build and push FRONTEND image
echo ""
echo "🔨 Building frontend image..."
cd ../frontend
docker build -t "${ECR_FRONTEND}:latest" .
echo "📤 Pushing frontend image..."
docker push "${ECR_FRONTEND}:latest"

# ✅ VERIFY: Check if images exist in ECR
echo ""
echo "🔍 Verifying images in ECR..."
aws ecr describe-images --repository-name h-game-backend --region us-east-1 --query 'imageDetails[*].imageTags' --output table
aws ecr describe-images --repository-name h-game-frontend --region us-east-1 --query 'imageDetails[*].imageTags' --output table
```

**✅ What you should see:**
```
----------------------------------------
|         DescribeImages               |
+--------------------------------------+
|  ['latest']                          |
+--------------------------------------+
```

**❌ Common errors:**
- **"repository does not exist"** → ECR repositories weren't created by Terraform. Run `terraform apply` first.
- **"unauthorized"** → ECR login failed. Check AWS credentials.
- **"Dockerfile not found"** → You're in the wrong directory. Make sure you `cd` into `backend/` or `frontend/` before building.

**💡 What's happening:** 
- Docker builds your application code into container images
- Images are pushed to AWS ECR (like Docker Hub, but private to your AWS account)
- Kubernetes will pull these images when creating pods

---

## 📍 Step 6: Deploy Backend

**⏱️ Time:** 2-3 minutes  
**🎯 What this does:** Deploys your backend API server to Kubernetes

```bash
cd "/Users/mac/Desktop/devops playbook/k8s"

# Deploy backend deployment (creates pods)
echo "🚀 Deploying backend..."
kubectl apply -f backend-deployment.yaml

# Deploy backend service (exposes pods internally)
echo "🔌 Creating backend service..."
kubectl apply -f backend-service.yaml

# Wait for pods to be ready (this takes 1-2 minutes)
echo ""
echo "⏳ Waiting for backend pods to start (this takes ~2 minutes)..."
kubectl wait --for=condition=ready pod -l app=backend -n h-game --timeout=300s

# ✅ VERIFY: Check pod status
echo ""
echo "🔍 Checking backend pods..."
kubectl get pods -n h-game -l app=backend

# ✅ VERIFY: Check service
echo ""
echo "🔍 Checking backend service..."
kubectl get svc -n h-game backend-service
```

**✅ What you should see:**
```
# Pods
NAME                          READY   STATUS    RESTARTS   AGE
backend-xxxxxxxxx-xxxxx       1/1     Running   0          2m

# Service
NAME              TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)    AGE
backend-service   ClusterIP   10.100.xxx.xxx   <none>        3001/TCP   2m
```

**❌ If pods show `ImagePullBackOff`:**
- **Cause:** Docker image doesn't exist in ECR
- **Fix:** Go back to Step 5 and build/push the image first
- **Verify:** `aws ecr describe-images --repository-name h-game-backend --region us-east-1`

**❌ If pods show `CrashLoopBackOff`:**
- **Cause:** Application is crashing (wrong config, missing secrets, database connection issue)
- **Debug:** `kubectl logs -n h-game -l app=backend --tail=50`
- **Check:** Make sure Step 4 (secrets) was completed successfully

**❌ If pods show `Pending`:**
- **Cause:** Not enough resources or node issues
- **Debug:** `kubectl describe pod <pod-name> -n h-game`
- **Check:** `kubectl get nodes` - are nodes Ready?

**💡 What's happening:**
- **Deployment:** Creates and manages pods (containers) running your backend
- **Service:** Creates a stable IP address that other pods can use to reach your backend
- Pods pull the Docker image from ECR and start your backend application

---

## 📍 Step 7: Deploy Ingress (Creates ALB)

**⏱️ Time:** 3-5 minutes (ALB creation takes time)  
**🎯 What this does:** Creates an AWS Application Load Balancer (ALB) that exposes your application to the internet

**⚠️ IMPORTANT:** Deploy Ingress BEFORE frontend so we know the ALB URL to configure frontend.

```bash
cd "/Users/mac/Desktop/devops playbook/k8s"

# Deploy ingress (this triggers ALB creation)
echo "🌐 Creating Ingress (this will create an ALB)..."
kubectl apply -f ingress.yaml

# Wait for ALB to be created (this takes 2-3 minutes)
echo ""
echo "⏳ Waiting for ALB to be created (this takes 2-3 minutes)..."
echo "   The AWS Load Balancer Controller is creating an ALB in AWS..."
echo "   This is normal - AWS needs time to provision the load balancer"
echo ""

# Check every 10 seconds until ALB is ready
TIMEOUT=300  # 5 minutes max
ELAPSED=0
while [ $ELAPSED -lt $TIMEOUT ]; do
  ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null)
  
  if [ -n "$ALB_URL" ] && [ "$ALB_URL" != "null" ]; then
    echo "✅ ALB created successfully!"
    echo "   URL: http://$ALB_URL"
    break
  fi
  
  echo "   Still waiting... (${ELAPSED}s / ${TIMEOUT}s) - checking every 10 seconds"
  sleep 10
  ELAPSED=$((ELAPSED + INTERVAL))
done

# Get final ALB URL
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
if [ -z "$ALB_URL" ] || [ "$ALB_URL" == "null" ]; then
  echo "❌ ERROR: ALB not created within 5 minutes"
  echo "   Check controller logs: kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50"
  exit 1
fi

echo ""
echo "✅ ALB is ready: http://$ALB_URL"
```

**✅ What you should see:**
```
⏳ Waiting for ALB to be created (this takes 2-3 minutes)...
   Still waiting... (0s / 300s) - checking every 10 seconds
   Still waiting... (10s / 300s) - checking every 10 seconds
   ...
✅ ALB created successfully!
   URL: http://h-game-alb-ingress-xxxxxxxxx.us-east-1.elb.amazonaws.com
```

**❌ If ALB doesn't appear after 5 minutes:**
- Check controller logs: `kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50`
- Check ingress events: `kubectl describe ingress h-game -n h-game | tail -20`
- Common issue: IAM permissions - see troubleshooting section

**💡 What's happening:**
- Ingress resource tells Kubernetes "expose this application"
- AWS Load Balancer Controller sees the Ingress and creates an ALB in AWS
- ALB gets a public URL (like `h-game-alb-ingress-xxx.elb.amazonaws.com`)
- Traffic to that URL is routed to your backend/frontend pods

**Alternative: Watch manually (if you prefer)**
```bash
kubectl get ingress h-game -n h-game -w
# Press Ctrl+C when you see ADDRESS populated
```

---

## 📍 Step 8: Deploy Frontend (Auto-Configured with ALB URL)

**⏱️ Time:** 2-3 minutes  
**🎯 What this does:** Deploys your frontend web application and automatically configures it to use the ALB URL for API calls

```bash
cd "/Users/mac/Desktop/devops playbook/k8s"

# Deploy frontend (with placeholder API URL)
echo "🚀 Deploying frontend..."
kubectl apply -f frontend-deployment.yaml

# Deploy frontend service
echo "🔌 Creating frontend service..."
kubectl apply -f frontend-service.yaml

# Get ALB URL (from Step 7)
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

if [ -z "$ALB_URL" ] || [ "$ALB_URL" == "null" ]; then
  echo "❌ ERROR: ALB URL not found. Make sure Step 7 completed successfully."
  exit 1
fi

# Automatically update frontend with ALB URL
echo ""
echo "🔧 Configuring frontend to use ALB URL: http://$ALB_URL/api"
kubectl set env deployment/frontend -n h-game API_BASE_URL="http://$ALB_URL/api"

# Wait for rollout (pods will restart with new configuration)
echo ""
echo "⏳ Waiting for frontend pods to restart with new config (this takes ~1 minute)..."
kubectl rollout status deployment/frontend -n h-game --timeout=120s

# ✅ VERIFY: Check pod status
echo ""
echo "🔍 Checking frontend pods..."
kubectl get pods -n h-game -l app=frontend

# ✅ VERIFY: Check that API_BASE_URL was set correctly
echo ""
echo "🔍 Verifying API URL configuration..."
ACTUAL_URL=$(kubectl get deployment frontend -n h-game -o jsonpath='{.spec.template.spec.containers[0].env[?(@.name=="API_BASE_URL")].value}')
echo "   Configured API URL: $ACTUAL_URL"
if [[ "$ACTUAL_URL" == *"$ALB_URL"* ]]; then
  echo "   ✅ Configuration correct!"
else
  echo "   ⚠️  Warning: URL might not match. Expected: http://$ALB_URL/api"
fi
```

**✅ What you should see:**
```
# Pods
NAME                          READY   STATUS    RESTARTS   AGE
frontend-xxxxxxxxx-xxxxx      1/1     Running   0          1m
frontend-xxxxxxxxx-yyyyy      1/1     Running   0          1m

# Configuration
   Configured API URL: http://h-game-alb-ingress-xxx.elb.amazonaws.com/api
   ✅ Configuration correct!
```

**❌ If pods show errors:**
- Same troubleshooting as Step 6 (ImagePullBackOff, CrashLoopBackOff, etc.)

**💡 What's happening:**
- Frontend deployment creates pods running your web UI
- `kubectl set env` updates the `API_BASE_URL` environment variable
- Kubernetes automatically restarts pods with the new configuration
- Frontend now knows where to send API requests (to the ALB)

**🤔 Why this approach?**
- No manual YAML editing needed
- Uses native Kubernetes commands
- If ALB URL changes, just run `kubectl set env` again

---

## 📍 Step 9: Get Your Application URLs

**⏱️ Time:** 10 seconds  
**🎯 What this does:** Shows you the public URLs to access your application

```bash
# Get ALB URL
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

echo ""
echo "=========================================="
echo "🎉 YOUR APPLICATION IS LIVE!"
echo "=========================================="
echo ""
echo "🌐 Public URLs (ALB DNS):"
echo "   Frontend:  http://$ALB_URL"
echo "   API:       http://$ALB_URL/api"
echo "   Health:    http://$ALB_URL/health"
echo ""
echo "📱 Open in browser:"
echo "   http://$ALB_URL"
echo ""
echo "💡 Optional: Want a custom domain (e.g., game.yourdomain.com)?"
echo "   See Step 12: Set Up Custom Domain with Route53"
echo ""
echo "=========================================="
```

**✅ Save these URLs!** You'll need them to test your application.

**💡 Want a friendly URL?** If you have a domain name, you can set up Route53 (Step 12) to use `game.yourdomain.com` instead of the long ALB DNS name. This is optional - the ALB URL works fine for testing!

---

## 📍 Step 10: Test Your Application

**⏱️ Time:** 2 minutes  
**🎯 What this does:** Verifies that your application is working correctly

```bash
# Get ALB URL
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

# Test health endpoint
echo "🔍 Testing health endpoint..."
HEALTH_RESPONSE=$(curl -s http://$ALB_URL/health)
echo "$HEALTH_RESPONSE" | jq '.' || echo "$HEALTH_RESPONSE"

# Test API endpoint
echo ""
echo "🔍 Testing API endpoint..."
API_RESPONSE=$(curl -s http://$ALB_URL/api)
echo "$API_RESPONSE" | jq '.message' || echo "$API_RESPONSE"

# Test leaderboard (might fail if database not migrated yet)
echo ""
echo "🔍 Testing leaderboard endpoint..."
LEADERBOARD_RESPONSE=$(curl -s http://$ALB_URL/api/leaderboard)
echo "$LEADERBOARD_RESPONSE" | jq '.success' || echo "$LEADERBOARD_RESPONSE"
```

**✅ What you should see:**
```json
# Health
{"status":"ok","timestamp":"..."}

# API
"Welcome to the Humor Memory Game API! 🎮😂"

# Leaderboard (if database migrated)
{"success":true,"data":[...]}
```

**❌ If health check fails:**
- Backend pods might not be ready yet - wait 1-2 minutes and try again
- Check backend logs: `kubectl logs -n h-game -l app=backend --tail=50`

**❌ If API returns error:**
- Frontend might not be configured correctly - check Step 8
- Check frontend logs: `kubectl logs -n h-game -l app=frontend --tail=50`

**💡 What's happening:** These tests verify that:
1. Backend is running and responding
2. ALB is routing traffic correctly
3. Frontend can reach backend (if leaderboard works)

---

## 📍 Step 11: Run Database Migration

**⏱️ Time:** 2-3 minutes  
**🎯 What this does:** Creates database tables in your RDS PostgreSQL database

**⚠️ IMPORTANT:** Your backend needs database tables to store game data. This step creates them.

**First, check if tables already exist:**
```bash
# Check if backend pod is running
BACKEND_POD=$(kubectl get pods -n h-game -l app=backend -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)

if [ -n "$BACKEND_POD" ]; then
  echo "🔍 Checking if database tables exist..."
  kubectl exec -n h-game $BACKEND_POD -- \
    node -e "const {Pool}=require('pg'); const p=new Pool({host:process.env.DB_HOST,user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME}); p.query('SELECT 1 FROM users LIMIT 1').then(()=>console.log('✅ Tables already exist - skip migration')).catch(e=>console.log('❌ Tables missing - need to run migration:',e.message));"
else
  echo "⚠️  Backend pods not running - will check after migration"
fi
```

**If tables don't exist, run migration:**

```bash
cd "/Users/mac/Desktop/devops playbook/k8s"

# Step 11a: Get RDS endpoint from Terraform
echo "🔍 Getting RDS endpoint from Terraform..."
cd "../h-game-terraform"
RDS_ENDPOINT=$(terraform output -raw rds_endpoint | cut -d: -f1)  # Remove port
echo "   RDS Endpoint: $RDS_ENDPOINT"

if [ -z "$RDS_ENDPOINT" ]; then
  echo "❌ ERROR: Could not get RDS endpoint from Terraform"
  exit 1
fi

# Step 11b: Update migration job with RDS endpoint
cd "../k8s"
echo "📝 Updating migration job with RDS endpoint..."
if [[ "$OSTYPE" == "darwin"* ]]; then
  # macOS
  sed -i '' "s|value: \".*rds.amazonaws.com\"|value: \"$RDS_ENDPOINT\"|g" postgres-migration-job.yaml
else
  # Linux
  sed -i "s|value: \".*rds.amazonaws.com\"|value: \"$RDS_ENDPOINT\"|g" postgres-migration-job.yaml
fi
echo "   ✅ Updated migration job"

# Step 11c: Apply migration ConfigMap (contains SQL schema)
echo ""
echo "📦 Creating migration ConfigMap (SQL schema)..."
kubectl apply -f postgres-migration-configmap.yaml

# Step 11d: Apply migration Job (runs the SQL)
echo ""
echo "🚀 Starting database migration..."
kubectl apply -f postgres-migration-job.yaml

# Step 11e: Watch migration progress
echo ""
echo "⏳ Watching migration logs (this takes 1-2 minutes)..."
echo "   Look for: 'Migration complete!' or 'HUMOR MEMORY GAME DATABASE READY!'"
echo "   Press Ctrl+C when you see success message"
echo ""
kubectl logs -f job/postgres-migration -n h-game

# Step 11f: Verify migration succeeded
echo ""
echo "🔍 Verifying migration..."
kubectl get job postgres-migration -n h-game
# Should show: COMPLETIONS 1/1
```

**✅ What you should see:**
```
# Job status
NAME                  COMPLETIONS   DURATION   AGE
postgres-migration    1/1           45s        2m

# Logs should show:
Migration complete!
HUMOR MEMORY GAME DATABASE READY!
```

**❌ If migration fails:**
- Check logs: `kubectl logs job/postgres-migration -n h-game`
- Common issues:
  - RDS endpoint wrong → Check Step 11a
  - Secret missing → Go back to Step 4
  - RDS not accessible → Check security groups in Terraform

**💡 What's happening:**
- Migration job runs a one-time SQL script
- Creates tables: `users`, `games`, `game_matches`
- Creates indexes and views
- Inserts sample data (8 test users)

**What the migration creates:**
- ✅ `users` table (stores player accounts)
- ✅ `games` table (stores game sessions)
- ✅ `game_matches` table (stores card matches)
- ✅ Indexes for performance
- ✅ Leaderboard view
- ✅ 8 sample users with funny usernames

---

## ✅ Quick Status Check

**Run this anytime to see the status of everything:**

```bash
echo "=== 📊 APPLICATION STATUS ==="
echo ""

echo "=== Pods ==="
kubectl get pods -n h-game

echo ""
echo "=== Services ==="
kubectl get svc -n h-game

echo ""
echo "=== Ingress ==="
kubectl get ingress -n h-game

echo ""
echo "=== ALB URL ==="
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null)
if [ -n "$ALB_URL" ]; then
  echo "   ALB DNS: http://$ALB_URL"
  
  # Check if Route53 is configured
  cd "/Users/mac/Desktop/devops playbook/h-game-terraform" 2>/dev/null
  CUSTOM_URL=$(terraform output -raw custom_domain_url 2>/dev/null)
  if [ -n "$CUSTOM_URL" ] && [ "$CUSTOM_URL" != "null" ]; then
    echo "   Custom Domain: $CUSTOM_URL"
  fi
  cd - > /dev/null
else
  echo "   ⚠️  Not ready yet"
fi

echo ""
echo "=== Secrets ==="
kubectl get secret postgres-secret -n h-game
```

---

## 🔧 Troubleshooting

### ❌ Secret Shows 0 DATA

**Symptom:** `kubectl get secret postgres-secret -n h-game` shows `DATA 0`

**Why this happens:**
- The `postgres-secret.yaml` file is a template (intentionally empty to prevent committing secrets to Git)
- When you run `kubectl apply -f postgres-secret.yaml`, it creates an empty secret
- Your actual RDS credentials are stored in AWS Secrets Manager (created by Terraform)

**Fix:**
```bash
# Delete the empty secret
kubectl delete secret postgres-secret -n h-game

# Get secret ARN from Terraform
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
SECRET_ARN=$(terraform output -raw rds_password_secret_arn)
REGION="us-east-1"

# Retrieve secret from AWS Secrets Manager
cd "../k8s"
SECRET_JSON=$(aws secretsmanager get-secret-value \
  --secret-id "$SECRET_ARN" \
  --region "$REGION" \
  --query SecretString \
  --output text)

# Extract values from JSON
DB_USER=$(echo "$SECRET_JSON" | jq -r '.username')
DB_PASSWORD=$(echo "$SECRET_JSON" | jq -r '.password')
DB_NAME=$(echo "$SECRET_JSON" | jq -r '.dbname')

# Create Kubernetes secret from AWS Secrets Manager values
kubectl create secret generic postgres-secret \
  --from-literal=postgres-user="$DB_USER" \
  --from-literal=postgres-password="$DB_PASSWORD" \
  --from-literal=postgres-db="$DB_NAME" \
  --namespace=h-game

# Verify (should show DATA 3, not 0)
kubectl get secret postgres-secret -n h-game
```

**Why we use AWS Secrets Manager:**
- ✅ Secrets stored securely in AWS (encrypted at rest)
- ✅ Terraform manages the secret lifecycle
- ✅ No secrets committed to Git
- ✅ Can rotate secrets without changing Kubernetes manifests

---

### ❌ Frontend Cannot Connect to API (Wrong ALB URL)

**Symptom:** Frontend shows "Cannot Connect to Game Server" error

**Why this happens:**
- ALB URL changed (e.g., after recreating ingress)
- Frontend deployment still has old ALB URL in environment variable

**Fix (Automated - No Scripts):**
```bash
# Get current ALB URL
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

# Update frontend deployment with correct ALB URL using native kubectl
kubectl set env deployment/frontend -n h-game API_BASE_URL="http://$ALB_URL/api"

# Wait for rollout
kubectl rollout status deployment/frontend -n h-game --timeout=120s

# Verify
kubectl get deployment frontend -n h-game -o jsonpath='{.spec.template.spec.containers[0].env[?(@.name=="API_BASE_URL")].value}' && echo ""
```

**Why this is better than editing YAML:**
- ✅ No file editing needed
- ✅ Uses native Kubernetes commands
- ✅ Automatically triggers pod rollout
- ✅ Can be run anytime ALB URL changes

---

### ❌ Ingress has no ADDRESS

**Symptom:** `kubectl get ingress h-game -n h-game` shows no ADDRESS

**Check controller logs:**
```bash
kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller --tail=50
```

**Check ingress events:**
```bash
kubectl describe ingress h-game -n h-game | tail -20
```

**Common issues:**
- **IAM permission error:** Controller doesn't have permission to create ALB
  - Fix: Check Step 2 - make sure service account has correct IAM role annotation
- **Controller not running:** Check `kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller`
- **Subnet/security group issues:** Check Terraform outputs match ingress.yaml annotations

---

### ❌ Pods not starting

**Check pod status:**
```bash
kubectl get pods -n h-game
kubectl describe pod <pod-name> -n h-game
kubectl logs <pod-name> -n h-game
```

**If pods show `ImagePullBackOff`:**
```bash
# Check the error
kubectl describe pod <pod-name> -n h-game | grep -A 5 "Events:"

# Common error: "not found" means image doesn't exist in ECR
# Fix: Build and push image to ECR (see Step 5)

# Verify image exists
aws ecr describe-images --repository-name h-game-backend --region us-east-1 --query 'imageDetails[*].imageTags' --output table
```

**If pods show `CrashLoopBackOff`:**
```bash
# Check logs to see why it's crashing
kubectl logs <pod-name> -n h-game --tail=50

# Common causes:
# - Missing secrets (check Step 4)
# - Database connection failed (check RDS endpoint, security groups)
# - Application error (check logs)
```

**If pods show `Pending`:**
```bash
# Check why it's pending
kubectl describe pod <pod-name> -n h-game

# Common causes:
# - Not enough resources (check node capacity)
# - Node issues (check: kubectl get nodes)
```

**If pods fail due to missing secrets:**
```bash
# Check if secret exists and has data
kubectl get secret postgres-secret -n h-game

# If DATA is 0, follow the "Secret Shows 0 DATA" fix above
```

---

### ❌ Targets unhealthy

**Symptom:** ALB shows targets as unhealthy

**Wait 60 seconds for health checks:**
```bash
sleep 60

# Check target groups
aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `k8s-hgame`)].TargetGroupName' \
  --output table
```

**Common causes:**
- Pods not ready yet (wait 2-3 minutes after deployment)
- Health check path wrong (check ingress.yaml healthcheck-path annotation)
- Security groups blocking traffic (check Terraform security group rules)

---

## 📍 Step 12: Set Up Custom Domain with Route53 (Optional)

**⏱️ Time:** 10-15 minutes (plus DNS propagation wait)  
**🎯 What this does:** Maps a custom domain (e.g., `game.yourdomain.com`) to your ALB so you can access your app with a friendly URL instead of the long ALB DNS name

**⚠️ PREREQUISITES:**
- You must own a domain name (e.g., `yourdomain.com`)
- Domain must be registered with a registrar (GoDaddy, Namecheap, Route53, etc.)
- Access to your domain registrar to update nameservers

**💡 Why use Route53?**
- ✅ Friendly URL: `game.yourdomain.com` instead of `h-game-alb-ingress-xxx.elb.amazonaws.com`
- ✅ Professional appearance
- ✅ Easy to remember and share
- ✅ Can add HTTPS/SSL later

**📝 Note:** If you don't have a domain, you can skip this step and use the ALB URL directly (it works fine for testing/learning).

---

### Step 12a: Configure Terraform Variables

**First, add your domain to Terraform configuration:**

```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"

# Edit terraform.tfvars
# Add these lines at the end of the file:
```

**Add to `terraform.tfvars`:**
```hcl
# Route53 Configuration (Optional - only if you have a domain)
domain_name   = "yourdomain.com"  # Replace with YOUR actual domain
app_subdomain = "game"            # Creates game.yourdomain.com (change if you want different subdomain)
```

**Example:**
- If your domain is `example.com` and you want `game.example.com`:
  ```hcl
  domain_name   = "example.com"
  app_subdomain = "game"
  ```

- If you want `app.example.com` instead:
  ```hcl
  domain_name   = "example.com"
  app_subdomain = "app"
  ```

---

### Step 12b: Apply Terraform Changes

**This creates the Route53 hosted zone and DNS record:**

```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"

# Plan to see what will be created
terraform plan

# Apply changes (creates Route53 hosted zone and DNS record)
terraform apply
```

**✅ What you should see:**
```
Plan: 2 to add, 0 to change, 0 to destroy.

  # aws_route53_zone.main[0] will be created
  # aws_route53_record.alb[0] will be created

Apply complete! Resources: 2 added, 0 changed, 0 destroyed.
```

---

### Step 12c: Get Nameservers

**Route53 will create a hosted zone with nameservers. You need to update your domain registrar with these:**

```bash
# Get nameservers from Terraform
terraform output route53_nameservers
```

**✅ What you should see:**
```
[
  "ns-123.awsdns-12.com",
  "ns-456.awsdns-45.net",
  "ns-789.awsdns-78.org",
  "ns-012.awsdns-01.co.uk"
]
```

**📝 Save these nameservers!** You'll need them in the next step.

---

### Step 12d: Update Domain Registrar

**⚠️ IMPORTANT:** You must update your domain registrar with the Route53 nameservers.

**Steps vary by registrar, but generally:**

1. **Log in to your domain registrar** (GoDaddy, Namecheap, Route53, etc.)

2. **Find DNS/Nameserver settings:**
   - GoDaddy: Domain Settings → DNS Management → Nameservers
   - Namecheap: Domain List → Manage → Advanced DNS → Nameservers
   - Route53: Already using Route53 nameservers (skip this step)

3. **Update nameservers:**
   - Change from default nameservers to the Route53 nameservers from Step 12c
   - Replace ALL nameservers with the 4 Route53 nameservers

4. **Save changes**

**Example (GoDaddy):**
```
Before:
ns1.godaddy.com
ns2.godaddy.com

After (use Route53 nameservers):
ns-123.awsdns-12.com
ns-456.awsdns-45.net
ns-789.awsdns-78.org
ns-012.awsdns-01.co.uk
```

**⏳ Wait for DNS propagation:** This can take 5 minutes to 48 hours (usually 15-60 minutes).

---

### Step 12e: Verify DNS Propagation

**Check if DNS has propagated:**

```bash
# Check if your custom domain resolves to the ALB
dig game.yourdomain.com +short
# Replace game.yourdomain.com with your actual subdomain.domain

# Or use nslookup
nslookup game.yourdomain.com
```

**✅ What you should see:**
```
# Should show ALB DNS name
h-game-alb-ingress-1808933917.us-east-1.elb.amazonaws.com
```

**❌ If you see "not found" or wrong IP:**
- DNS hasn't propagated yet - wait 15-60 minutes and try again
- Check that nameservers were updated correctly at your registrar
- Verify domain_name and app_subdomain in terraform.tfvars are correct

---

### Step 12f: Test Your Custom Domain

**Once DNS has propagated, test your custom domain:**

```bash
# Get your custom domain URL
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
CUSTOM_URL=$(terraform output -raw custom_domain_url)

echo "🌐 Your custom domain: $CUSTOM_URL"
echo "   Testing connection..."

# Test health endpoint
curl -s $CUSTOM_URL/health | jq '.' || curl -s $CUSTOM_URL/health

# Test API endpoint
curl -s $CUSTOM_URL/api | jq '.message' || curl -s $CUSTOM_URL/api
```

**✅ What you should see:**
```json
# Health
{"status":"ok","timestamp":"..."}

# API
"Welcome to the Humor Memory Game API! 🎮😂"
```

**🎉 Success!** Your app is now accessible via your custom domain!

**Open in browser:**
```
http://game.yourdomain.com
```
(Replace with your actual subdomain.domain)

---

### Route53 Troubleshooting

**❌ Terraform Error: "domain_name is required"**
- **Fix:** Make sure you added `domain_name` and `app_subdomain` to `terraform.tfvars`
- **Check:** `grep domain_name terraform.tfvars` should show your domain

**❌ Terraform Error: "ALB not found"**
- **Cause:** Ingress hasn't created the ALB yet
- **Fix:** Make sure you completed Step 7 (Deploy Ingress) first
- **Verify:** `kubectl get ingress h-game -n h-game` should show an ADDRESS

**❌ Custom domain doesn't resolve**
- **Check nameservers:** Make sure you updated your registrar with Route53 nameservers
- **Wait longer:** DNS propagation can take up to 48 hours (usually 15-60 minutes)
- **Verify nameservers:** `dig NS yourdomain.com` should show Route53 nameservers
- **Check Route53 record:** `terraform output ingress_alb_dns` should show ALB DNS

**❌ Custom domain resolves but app doesn't load**
- **Check ALB:** Make sure ALB is healthy: `kubectl get ingress h-game -n h-game`
- **Check pods:** Make sure backend/frontend pods are running
- **Check security groups:** Make sure ALB security group allows traffic from internet

**❌ "Certificate not found" (if using HTTPS)**
- **Cause:** ACM certificate not created or not validated
- **Fix:** See Step 13 (Add HTTPS/SSL) for certificate setup

---

### Route53 Quick Reference

**Get your custom domain URL:**
```bash
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform output custom_domain_url
```

**Get Route53 nameservers:**
```bash
terraform output route53_nameservers
```

**Get ALB DNS (for reference):**
```bash
terraform output ingress_alb_dns
```

**Check DNS resolution:**
```bash
dig game.yourdomain.com +short
# Replace with your actual subdomain.domain
```

---

## 🎉 Success! What's Next?

**Your application is now live!** Here are some next steps:

1. **✅ Custom Domain:** You just set up Route53! Access your app at `http://game.yourdomain.com`
2. **Add HTTPS/SSL:** See `ALB_INGRESS_GUIDE.md` for SSL certificate setup (requires Route53)
3. **Monitoring:** Set up CloudWatch or Prometheus/Grafana
4. **Auto-scaling:** HPA is already configured in `backend-hpa.yaml`
5. **Backup:** Set up RDS automated backups

**For detailed troubleshooting, see:** `ALB_INGRESS_GUIDE.md`

---

## 📚 Quick Reference

**Common Commands:**
```bash
# Check everything
kubectl get all -n h-game

# View logs
kubectl logs -n h-game -l app=backend --tail=50
kubectl logs -n h-game -l app=frontend --tail=50

# Restart deployment
kubectl rollout restart deployment/backend -n h-game
kubectl rollout restart deployment/frontend -n h-game

# Get ALB URL
kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'

# Update frontend API URL (if ALB changes)
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
kubectl set env deployment/frontend -n h-game API_BASE_URL="http://$ALB_URL/api"

# Route53 commands (if custom domain is set up)
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
terraform output custom_domain_url        # Get custom domain URL
terraform output route53_nameservers      # Get nameservers for registrar
terraform output ingress_alb_dns          # Get ALB DNS name
```

---

**🎮 Happy deploying!**
