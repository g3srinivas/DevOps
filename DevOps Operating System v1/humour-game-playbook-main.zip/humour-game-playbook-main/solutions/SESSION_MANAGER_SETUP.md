# AWS Systems Manager Session Manager - Quick Guide

## What This Solves

- No SSH timeouts
- No IP whitelisting needed
- Works from anywhere
- No SSH keys to manage
- More secure (IAM-based)

---

## Prerequisites

1. **AWS CLI installed:** `aws --version`
2. **Session Manager plugin:** `session-manager-plugin --version`
3. **AWS credentials configured:** `aws configure`

---

## Setup (One-Time)

### Step 1: Create IAM Role and Attach to EC2

Replace `i-YOUR-INSTANCE-ID` with your instance ID:

```bash
# Create IAM role
aws iam create-role \
  --role-name EC2-SSM-Role \
  --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Principal": {"Service": "ec2.amazonaws.com"},
      "Action": "sts:AssumeRole"
    }]
  }'

# Attach SSM policy
aws iam attach-role-policy \
  --role-name EC2-SSM-Role \
  --policy-arn arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore

# Create instance profile
aws iam create-instance-profile \
  --instance-profile-name EC2-SSM-Profile

# Add role to profile
aws iam add-role-to-instance-profile \
  --instance-profile-name EC2-SSM-Profile \
  --role-name EC2-SSM-Role

# Attach to EC2 instance
aws ec2 associate-iam-instance-profile \
  --instance-id i-YOUR-INSTANCE-ID \
  --iam-instance-profile Name=EC2-SSM-Profile

# Reboot instance (required)
aws ec2 reboot-instances --instance-ids i-YOUR-INSTANCE-ID

# Wait 60-90 seconds, then verify
aws ssm describe-instance-information \
  --filters "Key=InstanceIds,Values=i-YOUR-INSTANCE-ID" \
  --query 'InstanceInformationList[0].PingStatus' \
  --output text
# Should show: Online
```

---

## Connect

### Terminal Connection:
```bash
aws ssm start-session --target i-YOUR-INSTANCE-ID
```

**Switch to ubuntu user (to access your files):**
```bash
sudo su - ubuntu
```

### Create Alias (Optional):
Add to `~/.zshrc` or `~/.bashrc`:
```bash
alias ec2-ssm='aws ssm start-session --target i-YOUR-INSTANCE-ID'
```

Then run: `ec2-ssm`

---

## Connect Cursor / VS Code IDE (Remote SSH)

This allows you to use full IDE features (IntelliSense, debugging, extensions) through Session Manager.

### Step 1: Install Remote-SSH Extension

**In Cursor or VS Code:**
- Press `Cmd+Shift+X` (Mac) or `Ctrl+Shift+X` (Windows/Linux)
- Search for "Remote - SSH" by Microsoft
- Click Install

### Step 2: Enable SSH on EC2 (one-time setup)

```bash
# Connect via SSM first
aws ssm start-session --target i-YOUR-INSTANCE-ID

# Run on EC2:
sudo su - ubuntu
sudo sed -i 's/#AllowTcpForwarding yes/AllowTcpForwarding yes/' /etc/ssh/sshd_config
sudo systemctl restart sshd
exit
```

### Step 3: Add SSH Config

Edit `~/.ssh/config` (create if it doesn't exist):
```bash
nano ~/.ssh/config
# or
code ~/.ssh/config
```

Add this configuration:
```
Host ec2-ssm
    HostName i-YOUR-INSTANCE-ID
    User ubuntu
    ProxyCommand sh -c "aws ssm start-session --target %h --document-name AWS-StartSSHSession --parameters 'portNumber=%p'"
```

Save and set permissions:
```bash
chmod 600 ~/.ssh/config
```

### Step 4: Connect in Cursor/VS Code

1. Press `Cmd+Shift+P` (Mac) or `Ctrl+Shift+P` (Windows/Linux)
2. Type "Remote-SSH: Connect to Host"
3. Select `ec2-ssm`
4. Cursor/VS Code will open a new window connected to your EC2 instance

**You now have full IDE access with:**
- File explorer
- IntelliSense/autocomplete
- Debugging
- Extensions
- Terminal integrated

---

## Troubleshooting

**"TargetNotConnected" or connection fails:**
- Wait 2-3 minutes after attaching IAM role
- Reboot instance: `aws ec2 reboot-instances --instance-ids i-YOUR-INSTANCE-ID`
- Verify status: `aws ssm describe-instance-information --filters "Key=InstanceIds,Values=i-YOUR-INSTANCE-ID"`

**"Permission denied" when accessing files:**
- You're logged in as `ssm-user`, switch: `sudo su - ubuntu`

**Cursor/VS Code Remote SSH fails:**
- Make sure you enabled `AllowTcpForwarding yes` and restarted SSH on EC2
- Verify SSH config: `cat ~/.ssh/config`
- Test connection manually: `ssh ec2-ssm`
- Check extension is installed: Extensions → Search "Remote - SSH"
- Try reconnecting: `Cmd+Shift+P` → "Remote-SSH: Kill VS Code Server on Host" → then reconnect
