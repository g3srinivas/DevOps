# How to Check EC2 Logs

Complete guide for viewing EC2 instance logs for troubleshooting.

---

## Quick Reference

```bash
# Get instance ID from IP
aws ec2 describe-instances \
  --filters "Name=ip-address,Values=YOUR_IP" \
  --query 'Reservations[0].Instances[0].InstanceId' \
  --output text

# View console output (boot logs)
aws ec2 get-console-output \
  --instance-id i-YOUR-INSTANCE-ID \
  --latest \
  --output text

# Get last 50 lines
aws ec2 get-console-output \
  --instance-id i-YOUR-INSTANCE-ID \
  --latest \
  --output text | tail -50
```

---

## Method 1: AWS CLI (Recommended for Automation)

### A. System Console Log (Boot Log)

This shows the boot process, kernel messages, and service startup:

```bash
# Full log
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --output text

# Latest log (recommended)
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --latest \
  --output text

# Last 100 lines
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --latest \
  --output text | tail -100

# Save to file
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --latest \
  --output text > ec2-console.log
```

**What you'll see:**
- Boot messages
- Service startup (SSH, Docker, etc.)
- Kernel errors
- Cloud-init output
- Last login information

### B. Search for Specific Issues

```bash
# Check if SSH started
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --latest --output text | grep -i "ssh"

# Check for errors
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --latest --output text | grep -i "error\|fail\|fatal"

# Check for specific service
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --latest --output text | grep -i "docker"
```

### C. Instance Metadata

```bash
# Get instance details
aws ec2 describe-instances \
  --instance-ids i-07dbe222639631eab \
  --query 'Reservations[0].Instances[0].[
    InstanceId,
    State.Name,
    InstanceType,
    PublicIpAddress,
    LaunchTime,
    Placement.AvailabilityZone
  ]' \
  --output table

# Check status checks
aws ec2 describe-instance-status \
  --instance-ids i-07dbe222639631eab \
  --query 'InstanceStatuses[0].{
    Instance:InstanceId,
    Status:InstanceStatus.Status,
    System:SystemStatus.Status,
    State:InstanceState.Name
  }' \
  --output table
```

---

## Method 2: AWS Console (Web UI)

### Step-by-Step:

1. **Go to EC2 Console:**
   - https://console.aws.amazon.com/ec2

2. **Select Your Instance:**
   - Find instance by IP: `13.222.115.214`
   - Or search by instance ID: `i-07dbe222639631eab`

3. **View System Log:**
   ```
   Actions → Monitor and troubleshoot → Get system log
   ```
   
   - Shows boot messages
   - Service startup
   - Errors and warnings

4. **Get Instance Screenshot:**
   ```
   Actions → Monitor and troubleshoot → Get instance screenshot
   ```
   
   - What's currently on the console
   - Useful if system is frozen

5. **Check Monitoring Tab:**
   - CPU utilization
   - Network traffic
   - Disk I/O
   - Status checks

---

## Method 3: Via SSH (If Connected)

If you can SSH into the instance:

### A. System Logs

```bash
# System log (main log file)
sudo tail -f /var/log/syslog

# Authentication logs (SSH attempts)
sudo tail -f /var/log/auth.log

# Kernel messages
sudo dmesg | tail -50

# All logs in real-time
sudo journalctl -f

# Logs since last boot
sudo journalctl -b
```

### B. Service-Specific Logs

```bash
# SSH daemon logs
sudo journalctl -u ssh -n 50

# Docker logs
sudo journalctl -u docker -n 50

# Nginx logs (if installed)
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/access.log

# Cloud-init logs (instance initialization)
sudo cat /var/log/cloud-init.log
sudo cat /var/log/cloud-init-output.log
```

### C. System Status

```bash
# Check SSH service status
sudo systemctl status sshd

# Check all failed services
sudo systemctl --failed

# Check system load
uptime
top
htop

# Check disk space
df -h

# Check memory usage
free -h

# Check network connections
sudo netstat -tulpn | grep :22
```

---

## Method 4: CloudWatch Logs (If Configured)

If CloudWatch agent is installed:

### Via AWS CLI:
```bash
# List log groups
aws logs describe-log-groups

# List log streams
aws logs describe-log-streams \
  --log-group-name /aws/ec2/instance-logs

# View recent logs
aws logs tail /aws/ec2/instance-logs --follow
```

### Via Console:
```
CloudWatch → Logs → Log groups → /aws/ec2/instance-logs
```

---

## Common Issues and What to Check

### 1. SSH Connection Timeout

**Check console log for:**
```bash
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --latest --output text | grep -E "ssh|sshd|Started.*SSH"
```

**Should see:**
```
[  OK  ] Started ssh.service - OpenBSD Secure Shell server.
```

**If missing:** SSH service didn't start

### 2. Instance Won't Boot

**Check console log for:**
```bash
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --latest --output text | grep -i "error\|panic\|fatal"
```

**Look for:**
- Kernel panics
- Filesystem errors
- Out of memory errors

### 3. High CPU/Memory

**Via CLI:**
```bash
# Check instance metrics
aws cloudwatch get-metric-statistics \
  --namespace AWS/EC2 \
  --metric-name CPUUtilization \
  --dimensions Name=InstanceId,Value=i-07dbe222639631eab \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 300 \
  --statistics Average \
  --output table
```

**Via SSH:**
```bash
ssh -i ~/.ssh/devops-lab-key.pem ubuntu@13.222.115.214 'top -bn1 | head -20'
```

### 4. Network Issues

**Check security groups:**
```bash
# Get security group info
aws ec2 describe-instances \
  --instance-ids i-07dbe222639631eab \
  --query 'Reservations[0].Instances[0].SecurityGroups[*].[GroupId,GroupName]' \
  --output table

# Check security group rules
aws ec2 describe-security-groups \
  --group-ids sg-YOUR-GROUP-ID \
  --query 'SecurityGroups[0].IpPermissions' \
  --output json
```

### 5. Disk Full

**Via console log:**
```bash
aws ec2 get-console-output \
  --instance-id i-07dbe222639631eab \
  --latest --output text | grep -i "no space\|disk full"
```

**Via SSH:**
```bash
ssh -i ~/.ssh/devops-lab-key.pem ubuntu@13.222.115.214 'df -h'
```

---

## Your Current Instance Status

Based on your instance `i-07dbe222639631eab`:

### Services Running Successfully:
- SSH service: **Started** (line: "Started ssh.service")
- Docker: **Started** (line: "Started docker.service")
- Nginx: **Started** (line: "Started nginx.service")
- System status: **Healthy**

### Known Issues:
- **SSM Agent error**: IAM role not configured
  ```
  Systems Manager's instance management role is not configured
  ```
  - This doesn't affect SSH
  - Only needed for Session Manager (optional)

### 📊 Last Boot:
- **Date:** Mon, 19 Jan 2026 17:06:25 +0000
- **Boot time:** 9.39 seconds
- **Cloud-init:** Completed successfully

---

## Useful Scripts

### Script 1: Quick Health Check

```bash
#!/bin/bash
# save as: ec2-health-check.sh

INSTANCE_ID="i-07dbe222639631eab"

echo "=== EC2 Health Check ==="
echo ""
echo "Instance Status:"
aws ec2 describe-instance-status \
  --instance-ids $INSTANCE_ID \
  --query 'InstanceStatuses[0]' \
  --output table

echo ""
echo "Last 20 lines of console log:"
aws ec2 get-console-output \
  --instance-id $INSTANCE_ID \
  --latest --output text | tail -20

echo ""
echo "Checking for errors:"
aws ec2 get-console-output \
  --instance-id $INSTANCE_ID \
  --latest --output text | grep -i "error\|fail" | tail -10
```

### Script 2: SSH Service Check

```bash
#!/bin/bash
# save as: check-ssh-service.sh

INSTANCE_ID="i-07dbe222639631eab"
IP="13.222.115.214"

echo "=== SSH Service Check ==="
echo ""

echo "1. Checking console log for SSH startup:"
aws ec2 get-console-output \
  --instance-id $INSTANCE_ID \
  --latest --output text | grep -i "ssh" | tail -5

echo ""
echo "2. Testing port 22 connectivity:"
nc -zv -G 5 $IP 22 2>&1

echo ""
echo "3. Your current IP:"
curl -s https://checkip.amazonaws.com

echo ""
echo "4. Security group rules for port 22:"
SG_ID=$(aws ec2 describe-instances \
  --instance-ids $INSTANCE_ID \
  --query 'Reservations[0].Instances[0].SecurityGroups[0].GroupId' \
  --output text)

aws ec2 describe-security-groups \
  --group-ids $SG_ID \
  --query 'SecurityGroups[0].IpPermissions[?FromPort==`22`]' \
  --output table
```

Make executable:
```bash
chmod +x ec2-health-check.sh check-ssh-service.sh
```

Run:
```bash
./ec2-health-check.sh
./check-ssh-service.sh
```

---

## Real-Time Monitoring

### Terminal-Based Monitoring:

```bash
# Watch console log in real-time (refresh every 5 seconds)
watch -n 5 'aws ec2 get-console-output --instance-id i-07dbe222639631eab --latest --output text | tail -20'

# Monitor instance status
watch -n 10 'aws ec2 describe-instance-status --instance-ids i-07dbe222639631eab'

# Monitor SSH connectivity
watch -n 5 'nc -zv -G 3 13.222.115.214 22 2>&1'
```

---

## Troubleshooting Workflow

When SSH fails:

1. **Check instance state:**
   ```bash
   aws ec2 describe-instances --instance-ids i-07dbe222639631eab \
     --query 'Reservations[0].Instances[0].State.Name'
   ```

2. **Check system status:**
   ```bash
   aws ec2 describe-instance-status --instance-ids i-07dbe222639631eab
   ```

3. **View console log:**
   ```bash
   aws ec2 get-console-output --instance-id i-07dbe222639631eab \
     --latest --output text | tail -100
   ```

4. **Check security group:**
   ```bash
   # Your current IP
   curl -s https://checkip.amazonaws.com
   
   # Security group rules
   aws ec2 describe-security-groups --group-ids YOUR-SG-ID
   ```

5. **Test port 22:**
   ```bash
   nc -zv 13.222.115.214 22
   ```

6. **Try SSH with verbose:**
   ```bash
   ssh -v -i ~/.ssh/devops-lab-key.pem ubuntu@13.222.115.214
   ```

---

## Log Locations Reference

### On EC2 Instance (via SSH):

| Log Type | Location |
|----------|----------|
| System log | `/var/log/syslog` |
| Authentication | `/var/log/auth.log` |
| SSH daemon | `/var/log/auth.log` |
| Kernel messages | `dmesg` or `/var/log/kern.log` |
| Cloud-init | `/var/log/cloud-init.log` |
| Docker | `journalctl -u docker` |
| Nginx access | `/var/log/nginx/access.log` |
| Nginx error | `/var/log/nginx/error.log` |
| Application logs | `/var/log/` (varies) |

### Via AWS:

| Log Type | How to Access |
|----------|---------------|
| Console output | AWS CLI: `get-console-output` |
| Instance screenshot | AWS Console only |
| CloudWatch Logs | AWS CLI: `aws logs` |
| Flow Logs | VPC → Flow Logs |
| CloudTrail | Management events |

---

## Tips for Students

1. **Always check logs in this order:**
   - Console output (boot log)
   - System status
   - Security groups
   - SSH daemon logs

2. **Save logs for debugging:**
   ```bash
   aws ec2 get-console-output \
     --instance-id i-07dbe222639631eab \
     --latest --output text > debug-$(date +%Y%m%d-%H%M%S).log
   ```

3. **Use grep effectively:**
   ```bash
   # Find errors
   grep -i "error"
   
   # Find SSH-related lines
   grep -i "ssh"
   
   # Exclude noise
   grep -v "INFO\|DEBUG"
   ```

4. **Monitor continuously:**
   ```bash
   # Real-time via SSH
   ssh ubuntu@IP 'sudo tail -f /var/log/syslog'
   
   # Or use journalctl
   ssh ubuntu@IP 'sudo journalctl -f'
   ```

---

## Summary

**Quick commands you'll use most:**

```bash
# 1. Get console log
aws ec2 get-console-output --instance-id i-07dbe222639631eab --latest --output text | tail -50

# 2. Check instance status
aws ec2 describe-instance-status --instance-ids i-07dbe222639631eab

# 3. View SSH logs (via SSH)
ssh ubuntu@13.222.115.214 'sudo journalctl -u ssh -n 50'

# 4. Monitor in real-time (via SSH)
ssh ubuntu@13.222.115.214 'sudo tail -f /var/log/syslog'
```

**Remember:** Console logs show boot process, but for application logs you need SSH access or CloudWatch Logs configured!

