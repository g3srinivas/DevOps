# Terraform Recreation Guide

Complete guide for recreating infrastructure manually and via CI/CD.

---

## 🔍 PRE-CHECKS (Do Before Starting)

> **💡 Tip:** Run the commands below - they will automatically create missing resources!

### For Both Manual & CI/CD:

- [ ] **AWS CLI configured and working**
  ```bash
  aws sts get-caller-identity
  # Should return your AWS account ID
  ```

- [ ] **AWS credentials have required permissions**
  - VPC, EC2, EKS, RDS, ElastiCache, ALB, ECR
  - IAM (create roles/policies)
  - S3, DynamoDB (for state backend)
  - CloudWatch, CloudTrail, Secrets Manager

- [ ] **Backend S3 bucket and DynamoDB table exist**
  ```bash
  # Easiest: Use bootstrap script
  cd h-game-terraform
  ./bootstrap-backend.sh
  ```
  
  **Or check manually:**
  ```bash
  # Check S3 bucket
  aws s3 ls s3://h-game-tfstate-playbook-1769734069 && echo "✅ S3 bucket exists" || echo "❌ Run ./bootstrap-backend.sh"
  
  # Check DynamoDB table
  aws dynamodb describe-table --table-name h-game-terraform-state-lock --region us-east-1 2>/dev/null | grep -q "TableStatus" && echo "✅ DynamoDB table exists" || echo "❌ Run ./bootstrap-backend.sh"
  ```

- [ ] **Terraform installed** (version >= 1.0)
  ```bash
  terraform version
  ```

### For Manual Only:

- [ ] **terraform.tfvars file exists**
  ```bash
  cd h-game-terraform
  # Create if missing
  if [ ! -f terraform.tfvars ]; then
  cp terraform.tfvars.example terraform.tfvars
  echo "✅ Created terraform.tfvars - Edit it now!"
else
  echo "✅ terraform.tfvars already exists"
fi
  ```

- [ ] **terraform.tfvars has all required values**
  - `rds_password` (must meet requirements: 16+ chars, uppercase, lowercase, number)
  - All other variables (check `terraform.tfvars.example`)

### For CI/CD Only:

- [ ] **GitHub secrets configured**
  - Go to: Repository → Settings → Secrets and variables → Actions
  - Verify these secrets exist:
    - `AWS_ACCESS_KEY_ID`
    - `AWS_SECRET_ACCESS_KEY`
    - `RDS_PASSWORD` (recommended)

- [ ] **GitHub Actions enabled**
  - Repository → Settings → Actions → General
  - "Allow all actions and reusable workflows"

---

## 📋 MANUAL RECREATION

### Step 1: Navigate to Terraform Directory
```bash
cd h-game-terraform
```

### Step 2: Verify Backend Setup

**Option A: Use Bootstrap Script (Recommended)**
```bash
./bootstrap-backend.sh
```

**Option B: Manual Commands (if script doesn't work)**
```bash
# Create S3 bucket (if missing)
aws s3 ls s3://h-game-tfstate-playbook-1769734069 2>/dev/null || (aws s3 mb s3://h-game-tfstate-playbook-1769734069 --region us-east-1 && aws s3api put-bucket-versioning --bucket h-game-tfstate-playbook-1769734069 --versioning-configuration Status=Enabled --region us-east-1 && aws s3api put-bucket-encryption --bucket h-game-tfstate-playbook-1769734069 --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}' --region us-east-1 && aws s3api put-public-access-block --bucket h-game-tfstate-playbook-1769734069 --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true" --region us-east-1 && echo "✅ S3 bucket created") && echo "✅ S3 bucket ready"

# Create DynamoDB table (if missing)
aws dynamodb describe-table --table-name h-game-terraform-state-lock --region us-east-1 2>/dev/null | grep -q "TableStatus" || (aws dynamodb create-table --table-name h-game-terraform-state-lock --attribute-definitions AttributeName=LockID,AttributeType=S --key-schema AttributeName=LockID,KeyType=HASH --billing-mode PAY_PER_REQUEST --region us-east-1 --tags Key=Name,Value="Terraform State Lock" Key=ManagedBy,Value="Terraform" && aws dynamodb wait table-exists --table-name h-game-terraform-state-lock --region us-east-1 && echo "✅ DynamoDB table created") && echo "✅ DynamoDB table ready"
```

**Note:** The one-liners above use `||` (if command fails, run the creation) and `&&` (if succeeds, continue). For easier copy-paste, use the bootstrap script instead.

### Step 3: Verify terraform.tfvars
```bash
# Check and create terraform.tfvars if missing (single-line version)
[ ! -f terraform.tfvars ] && cp terraform.tfvars.example terraform.tfvars && echo "✅ Created terraform.tfvars from example" || echo "✅ terraform.tfvars exists"

# Verify rds_password is set (check for placeholder)
if grep -q "rds_password.*=.*CHANGE_THIS" terraform.tfvars 2>/dev/null || ! grep -q "rds_password" terraform.tfvars 2>/dev/null; then
  echo "⚠️  WARNING: rds_password not set or still has placeholder value!"
  echo "   Edit terraform.tfvars and set a secure password (16+ chars, uppercase, lowercase, number)"
else
  echo "✅ terraform.tfvars looks good"
fi
```

**Or use the bootstrap script approach:**
```bash
# Simple one-liner
[ ! -f terraform.tfvars ] && cp terraform.tfvars.example terraform.tfvars && echo "⚠️  Edit terraform.tfvars now!" || echo "✅ File exists"
```

### Step 4: Initialize Terraform
```bash
terraform init
```

**Expected output:**
```
Initializing the backend...
Successfully configured the backend "s3"!
Terraform has been successfully initialized!
```

**If you see errors:**
- "NoSuchBucket" → Run `./bootstrap-backend.sh`
- "Access Denied" → Check AWS credentials and permissions

### Step 5: Validate Configuration
```bash
terraform validate
```

**Expected output:**
```
Success! The configuration is valid.
```

### Step 6: Plan Changes
```bash
terraform plan -out=tfplan
```

**What to check:**
- Review the plan output
- Verify it shows resources being created (not destroyed)
- Check for any errors or warnings

**Common issues:**
- "rds_password validation failed" → Check password meets requirements
- "Resource already exists" → State might be out of sync (see troubleshooting)

### Step 7: Apply Changes
```bash
terraform apply tfplan
```

**Or:**
```bash
terraform apply
# Review plan, type 'yes' to confirm
```

**Expected output:**
```
Apply complete! Resources: X added, Y changed, Z destroyed.
```

**Time:** First apply takes 15-30 minutes (EKS cluster creation is slow)

### Step 8: Verify Outputs
```bash
terraform output
```

**Check these outputs:**
- `eks_cluster_name` - Should show cluster name
- `rds_endpoint` - Should show database endpoint
- `ecr_backend_repository_url` - Should show ECR URL
- `ecr_frontend_repository_url` - Should show ECR URL

---

## 🤖 CI/CD RECREATION

### Step 1: Verify Backend Setup
```bash
cd h-game-terraform

# Use bootstrap script (easiest)
./bootstrap-backend.sh
```

**Or manually:**
```bash
# Quick check and create (one-liners)
aws s3 ls s3://h-game-tfstate-playbook-1769734069 2>/dev/null || ./bootstrap-backend.sh
aws dynamodb describe-table --table-name h-game-terraform-state-lock --region us-east-1 2>/dev/null | grep -q "TableStatus" || echo "Run ./bootstrap-backend.sh to create table"
```

### Step 2: Verify GitHub Secrets
1. Go to: **Repository → Settings → Secrets and variables → Actions**
2. Verify these secrets exist:
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`
   - `RDS_PASSWORD` (recommended)

3. If missing, add them:
   - Click "New repository secret"
   - Add each secret with correct values

**Quick check via GitHub CLI (if installed):**
```bash
# List secrets (names only, not values)
gh secret list

# If missing, you'll need to add via GitHub UI or:
gh secret set AWS_ACCESS_KEY_ID --body "your-access-key"
gh secret set AWS_SECRET_ACCESS_KEY --body "your-secret-key"
gh secret set RDS_PASSWORD --body "your-secure-password"
```

**Note:** GitHub CLI requires authentication: `gh auth login`

### Step 3: Trigger CI/CD

**Option A: Push to Main Branch**
```bash
# Make a small change to trigger workflow
cd h-game-terraform
echo "# Trigger rebuild" >> README.md
git add README.md
git commit -m "Trigger Terraform apply"
git push origin main
```

**Option B: Create Pull Request**
```bash
# Make changes to Terraform files
git checkout -b terraform-recreate
# Make your changes
git add .
git commit -m "Recreate infrastructure"
git push origin terraform-recreate
# Create PR on GitHub
```

### Step 4: Monitor CI/CD

1. Go to: **Repository → Actions tab**
2. Click on the running workflow
3. Watch these jobs:
   - ✅ **Validate** - Should pass
   - ✅ **Plan** (on PR) - Review plan output
   - ✅ **Security** - Should pass (warnings OK)
   - ✅ **Apply** (on main push) - Should create resources

**Expected timeline:**
- Validate: ~1 minute
- Plan: ~2-3 minutes
- Security: ~1-2 minutes
- Apply: ~15-30 minutes (first time)

### Step 5: Check Workflow Logs

**If workflow fails:**
1. Click on failed job
2. Expand failed step
3. Check error message

**Common errors:**
- "NoSuchBucket" → Backend S3 bucket missing
- "rds_password is required" → `RDS_PASSWORD` secret missing
- "Access Denied" → AWS credentials lack permissions

---

## ✅ POST-CHECKS (Verify It Worked)

### 1. Check Terraform State
```bash
cd h-game-terraform
terraform state list
```

**Expected:** Should list all resources (VPC, EKS, RDS, ECR, etc.)

### 2. Verify Resources in AWS

**VPC:**
```bash
aws ec2 describe-vpcs --filters "Name=tag:Project,Values=h-game" --query 'Vpcs[*].[VpcId,State]' --output table
```

**EKS Cluster:**
```bash
aws eks list-clusters --region us-east-1
# Should show: h-game-prod
```

**RDS:**
```bash
aws rds describe-db-instances --query 'DBInstances[*].[DBInstanceIdentifier,DBInstanceStatus]' --output table
# Should show: h-game-postgres | available
```

**ECR Repositories:**
```bash
aws ecr describe-repositories --query 'repositories[*].[repositoryName,repositoryUri]' --output table
# Should show: h-game-backend and h-game-frontend
```

### 3. Check Terraform Outputs
```bash
terraform output
```

**Verify these exist:**
- `eks_cluster_name`
- `eks_cluster_endpoint`
- `rds_endpoint`
- `rds_address`
- `ecr_backend_repository_url`
- `ecr_frontend_repository_url`

### 4. Verify EKS Cluster is Ready
```bash
# Get kubeconfig
aws eks update-kubeconfig --name h-game-prod --region us-east-1

# Check cluster status
kubectl cluster-info
kubectl get nodes
```

**Expected:** Should show 2+ nodes in Ready state

### 5. Verify RDS is Accessible
```bash
# Get RDS endpoint from Terraform output
terraform output rds_endpoint

# Test connection (if you have psql)
# psql -h <rds-endpoint> -U gameuser -d humor_memory_game
```

### 6. Check CloudWatch Logs
```bash
# EKS cluster logs
aws logs describe-log-groups --log-group-name-prefix "/aws/eks/h-game-prod" --query 'logGroups[*].logGroupName' --output table

# Should show log groups for cluster
```

### 7. Verify Security Groups
```bash
aws ec2 describe-security-groups --filters "Name=tag:Project,Values=h-game" --query 'SecurityGroups[*].[GroupName,GroupId]' --output table
```

**Expected:** Multiple security groups (ALB, backend, database, cache, EKS, etc.)

---

## 🐛 TROUBLESHOOTING

### "Resource Already Exists" Error

**Cause:** State out of sync with AWS

**Fix:**
```bash
# Option 1: Import existing resource
terraform import <resource_type>.<name> <resource_id>

# Option 2: Remove from state (if you want Terraform to recreate it)
terraform state rm <resource_type>.<name>
terraform apply
```

### "Failed to get existing workspaces: NoSuchBucket"

**Cause:** Backend S3 bucket doesn't exist

**Fix:**
```bash
# Option 1: Use bootstrap script
./bootstrap-backend.sh

# Option 2: Create manually
aws s3 mb s3://h-game-tfstate-playbook-1769734069 --region us-east-1
aws s3api put-bucket-versioning \
  --bucket h-game-tfstate-playbook-1769734069 \
  --versioning-configuration Status=Enabled \
  --region us-east-1
aws s3api put-bucket-encryption \
  --bucket h-game-tfstate-playbook-1769734069 \
  --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}' \
  --region us-east-1
aws s3api put-public-access-block \
  --bucket h-game-tfstate-playbook-1769734069 \
  --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true" \
  --region us-east-1
```

### "rds_password is required"

**Manual:** Check `terraform.tfvars` has `rds_password` set

**CI/CD:** Add `RDS_PASSWORD` secret in GitHub

### "Access Denied" Errors

**Cause:** AWS credentials lack permissions

**Fix:** Add required IAM permissions (see README.md)

### EKS Cluster Creation Stuck

**Cause:** Normal - EKS takes 10-15 minutes

**Fix:** Wait. Check status:
```bash
aws eks describe-cluster --name h-game-prod --region us-east-1 --query 'cluster.status'
```

### EKS Node Group Creation Failed: "Unhealthy nodes in the kubernetes cluster"

**Error Message:**
```
Error: waiting for EKS Node Group (h-game-prod:h-game-nodes) create: unexpected state 'CREATE_FAILED', wanted target 'ACTIVE'. last error: NodeCreationFailure: Unhealthy nodes in the kubernetes cluster
```

**Root Cause:**
Nodes were created but couldn't become Ready because the **VPC CNI addon was not installed** before the node group was created. Without VPC CNI:
- Nodes can't get pod IPs from the VPC
- Nodes remain in `NotReady` state
- Kubernetes reports "cni plugin not initialized"
- EKS marks the node group as `CREATE_FAILED` after timeout

**Why It Happened:**
The original configuration had a **circular dependency**:
- Node group waited for addons to be healthy
- But CoreDNS addon needs nodes to schedule pods
- This created a deadlock where nothing could complete

**The Fix (Already Applied):**
The dependency chain was corrected to:
```
Cluster → VPC CNI → Node Group → CoreDNS + kube-proxy
```

**How to Verify the Fix:**
```bash
# Check addon status
aws eks describe-addon --cluster-name h-game-prod --addon-name vpc-cni --region us-east-1 --query 'addon.status'
# Should show: "ACTIVE"

# Check node group status
aws eks describe-nodegroup --cluster-name h-game-prod --nodegroup-name h-game-nodes --region us-east-1 --query 'nodegroup.status'
# Should show: "ACTIVE"

# Check nodes are Ready
kubectl get nodes
# Should show nodes in Ready state
```

**If You Encounter This Issue:**
1. **Check if node group exists in Terraform state:**
   ```bash
   terraform state list | grep node_group
   ```

2. **If node group is NOT in state (failed creation):**
   - Just run `terraform apply` - it will create with correct dependencies
   - No manual cleanup needed

3. **If node group IS in state but failed:**
   ```bash
   # Remove failed node group from state
   terraform state rm aws_eks_node_group.main
   
   # Recreate with correct dependencies
   terraform apply
   ```

4. **Verify addons are installed:**
   ```bash
   aws eks list-addons --cluster-name h-game-prod --region us-east-1
   # Should show: vpc-cni, coredns, kube-proxy
   ```

**Prevention:**
- ✅ **Dependencies are now correct** - VPC CNI installs before nodes
- ✅ **Use ON_DEMAND instances** for initial setup (avoids Spot interruptions)
- ✅ **Check addon status** before creating node groups manually

**Related Files:**
- `eks-addons.tf` - Defines addon dependencies
- `eks-nodes.tf` - Node group depends on VPC CNI
- `terraform.tfvars` - Set `node_capacity_type = "ON_DEMAND"` for stability

### State Lock Error

**Cause:** Another Terraform process is running

**Fix:**
```bash
# Check who has the lock
aws dynamodb get-item --table-name h-game-terraform-state-lock --key '{"LockID":{"S":"<lock-id>"}}'

# Force unlock (use with caution!)
terraform force-unlock <lock-id>
```

---

## 📊 SUCCESS CRITERIA

✅ **Manual Recreation:**
- `terraform apply` completes without errors
- All resources show in `terraform state list`
- Terraform outputs show correct values
- Resources visible in AWS console

✅ **CI/CD Recreation:**
- All workflow jobs pass (Validate, Plan, Security, Apply)
- No errors in workflow logs
- Resources created in AWS
- Terraform outputs accessible

---

## ⏱️ TIMELINE

**Manual:**
- Pre-checks: 5 minutes
- Terraform init: 1 minute
- Terraform plan: 2-3 minutes
- Terraform apply: 15-30 minutes (first time)
- Post-checks: 5 minutes
- **Total: ~30-45 minutes**

**CI/CD:**
- Pre-checks: 5 minutes
- Workflow trigger: Instant
- Validate job: ~1 minute
- Plan job: ~2-3 minutes
- Security job: ~1-2 minutes
- Apply job: ~15-30 minutes
- Post-checks: 5 minutes
- **Total: ~25-45 minutes** (mostly waiting)

---

## 📝 NOTES

- **First apply is slowest** - EKS cluster creation takes 10-15 minutes
- **Subsequent applies are faster** - Only changed resources are updated
- **State is locked during apply** - Prevents concurrent modifications
- **CI/CD uses parallelism=5** - Prevents AWS API throttling
- **Backend must exist first** - Always run `./bootstrap-backend.sh` if unsure
- **EKS dependency order is critical** - Must follow: Cluster → VPC CNI → Node Group → CoreDNS/kube-proxy
  - VPC CNI must be installed before nodes (nodes need it to get pod IPs)
  - Nodes must exist before CoreDNS/kube-proxy (they need nodes to schedule pods)
  - This prevents "Unhealthy nodes" errors during node group creation
- **Use ON_DEMAND instances initially** - Switch to SPOT after cluster is stable (saves 50% cost)

---

## 🆘 GETTING HELP

If something goes wrong:

1. Check error message carefully
2. Review troubleshooting section above
3. Check Terraform logs: `terraform apply -debug`
4. Verify AWS resources in console
5. Check state: `terraform state list`
6. Review [TERRAFORM_FIXES.md](./TERRAFORM_FIXES.md) for known issues

