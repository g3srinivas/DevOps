# Image Scanning Explained (For Beginners)

## What is Image Scanning?

Think of Docker images like shipping containers. Before you ship a container, you want to check if it has any dangerous items inside. Image scanning does the same thing - it checks your Docker images for known security vulnerabilities (like bugs or weaknesses that hackers could exploit).

## Why Scan Before Pushing?

**The Problem:** If you push a vulnerable image to DockerHub, anyone who pulls it gets the vulnerabilities too. It's like shipping a container with dangerous items - bad for everyone.

**The Solution:** Scan the image **before** pushing it. If vulnerabilities are found, the workflow stops and the image never gets pushed. Only safe images make it to DockerHub.

## How It Works in Your Workflow

Your CI/CD pipeline now follows this simple flow:

```
1. Build image → Create the Docker image locally
2. Scan image → Check for CRITICAL and HIGH severity vulnerabilities
3. Push image → Only if scan passes (no dangerous vulnerabilities found)
```

**What Happens:**
- ✅ **If scan passes:** Image is pushed to DockerHub (safe to use)
- ❌ **If scan fails:** Workflow stops, image is NOT pushed (keeps vulnerabilities out)

### See It in Action (From Your Workflow)

Here's the actual code that scans your images:

```yaml
# Step 6: Scan backend image for vulnerabilities
- name: Scan backend image with Trivy
  uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.DOCKERHUB_USERNAME }}/${{ env.BACKEND_IMAGE }}:${{ steps.tag.outputs.tag }}
    severity: 'CRITICAL,HIGH'
    exit-code: '1'  # Fail workflow if vulnerabilities found
```

**What this does:**
- Scans the image you just built
- Only reports CRITICAL and HIGH severity issues (ignores minor ones)
- Stops the workflow (`exit-code: '1'`) if dangerous vulnerabilities are found

## Image Tags: Managing Different Versions

**What are tags?** Tags are like labels on your Docker images. They help you identify which version you're using.

### Your Workflow's Tagging Strategy

Your CI/CD automatically tags images based on what you push:

```yaml
# From your workflow - determines the tag
if [[ "${{ github.ref }}" == refs/tags/* ]]; then
  TAG="${{ github.ref_name }}"        # v1.0.0 → tag is "v1.0.0"
elif [[ "${{ github.ref }}" == refs/heads/main ]]; then
  TAG="latest"                         # main branch → tag is "latest"
else
  TAG="${{ github.ref_name }}"         # develop branch → tag is "develop"
fi
```

### Real Examples from Your Images

When you push code, your images get tagged like this:

| What You Push | Image Tag | Full Image Name |
|--------------|-----------|-----------------|
| Push to `main` branch | `latest` | `yourusername/humor-game-backend:latest` |
| Create tag `v1.0.0` | `v1.0.0` | `yourusername/humor-game-backend:v1.0.0` |
| Push to `develop` branch | `develop` | `yourusername/humor-game-backend:develop` |

**Why this matters:**
- `latest` = most recent stable version
- `v1.0.0` = specific version you can always go back to
- `develop` = work-in-progress version

### Pulling Images with Tags

```bash
# Pull the latest version
docker pull yourusername/humor-game-backend:latest

# Pull a specific version
docker pull yourusername/humor-game-backend:v1.0.0

# Pull development version
docker pull yourusername/humor-game-backend:develop
```

## SHA Digests: Immutable Image References

**What is a SHA digest?** It's a unique fingerprint for your image. Even if the tag changes, the SHA stays the same.

### Understanding SHA vs Tags

**Tags can change:**
```bash
# Today, "latest" might point to version 1.0
yourusername/humor-game-backend:latest  # Could be v1.0

# Tomorrow, "latest" might point to version 2.0
yourusername/humor-game-backend:latest  # Now it's v2.0 (different image!)
```

**SHA digests never change:**
```bash
# This SHA always points to the exact same image, forever
yourusername/humor-game-backend@sha256:abc123def456...
# Even if you push a new "latest", this SHA still points to the old image
```

### Why Use SHA Digests?

**Problem with tags:**
- `latest` tag can change → You might get a different image than expected
- Tags can be overwritten → Hard to track what you're actually running

**Solution with SHA:**
- SHA is permanent → Always points to the exact same image
- Immutable reference → Perfect for production deployments

### Example: Tag vs SHA

```bash
# Using tag (can change)
docker pull yourusername/humor-game-backend:latest
# ⚠️ Tomorrow, "latest" might be a different image!

# Using SHA (never changes)
docker pull yourusername/humor-game-backend@sha256:abc123def456789...
# ✅ This always pulls the exact same image, forever
```

### Finding Your Image's SHA

After pushing, DockerHub shows the SHA:

```bash
# View image details on DockerHub or use:
docker inspect yourusername/humor-game-backend:latest | grep -i sha256
```

**Output:**
```
"RepoDigests": [
  "yourusername/humor-game-backend@sha256:abc123def456789..."
]
```

## Where to See Results

After a workflow runs, check your GitHub repository:
1. Go to **Security** tab
2. Click **Code scanning alerts**
3. See all vulnerabilities Trivy found (if any)

### Visual Example of Scan Results

When Trivy finds vulnerabilities, you'll see:

```
🔍 Scanning: yourusername/humor-game-backend:latest

❌ CRITICAL: CVE-2024-1234 in package: openssl
   Description: Remote code execution vulnerability
   Fixed in version: 1.1.1t

⚠️ HIGH: CVE-2024-5678 in package: node
   Description: Denial of service vulnerability
   Fixed in version: 18.17.0

✅ Scan complete: 2 vulnerabilities found
❌ Workflow failed: Image not pushed to DockerHub
```

## Real-World Example

Imagine you're building a house (your Docker image):
- **Without scanning:** You build it, ship it, and later discover it has weak foundations (vulnerabilities). Too late - it's already shipped!
- **With scanning:** You build it, inspect it for problems, fix any issues found, THEN ship it. Only safe houses get shipped.

That's exactly what Trivy does - it inspects your Docker images before they're "shipped" to DockerHub.

## Quick Reference: Your Workflow Steps

Here's what happens in order when you push code:

```yaml
# 1. Build backend image (locally, not pushed yet)
- name: Build backend image
  push: false  # ← Not pushed yet!

# 2. Scan backend image
- name: Scan backend image with Trivy
  severity: 'CRITICAL,HIGH'  # ← Only checks serious issues

# 3. Upload scan results to GitHub
- name: Upload backend Trivy results to GitHub Security
  # ← Results appear in Security tab

# 4. Push backend image (only if scan passed)
- name: Push backend image to DockerHub
  push: true  # ← Only reaches here if no CRITICAL/HIGH vulnerabilities

# Same process for frontend...
```

## Key Takeaways

✅ **Image Scanning** = Security check before pushing  
✅ **Image Tags** = Version labels (`latest`, `v1.0.0`, `develop`)  
✅ **SHA Digests** = Permanent, immutable image references  
✅ **Scan Before Push** = Vulnerable images never reach DockerHub  
✅ **Results in GitHub** = Check Security tab → Code scanning alerts  

## Common Commands

```bash
# Pull latest image
docker pull yourusername/humor-game-backend:latest

# Pull specific version
docker pull yourusername/humor-game-backend:v1.0.0

# Pull by SHA (most reliable)
docker pull yourusername/humor-game-backend@sha256:abc123...

# Check image SHA
docker inspect yourusername/humor-game-backend:latest | grep RepoDigests

# View scan results
# Go to: GitHub repo → Security → Code scanning alerts
```

