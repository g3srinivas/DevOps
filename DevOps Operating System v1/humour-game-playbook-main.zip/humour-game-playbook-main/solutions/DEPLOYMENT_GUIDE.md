# Complete Deployment Guide: Step-by-Step Infrastructure & Application Setup

**For 100% beginners who clone this repository and want to deploy everything from scratch.**

This guide walks you through deploying the entire infrastructure and application using Terraform targets and Kubernetes manifests in the correct order. Every command is explained, and we show you exactly what to expect at each step.

**⚠️ Important for Beginners:**
- Read each step completely before running commands
- Don't skip verification steps
- If something doesn't match expected output, stop and troubleshoot
- This will take 2-3 hours for first-time setup

---

## 📋 Prerequisites

Before starting, ensure you have:

- [ ] AWS CLI configured (`aws configure`)
- [ ] Terraform installed (`terraform --version`)
- [ ] kubectl installed (`kubectl version --client`)
- [ ] Helm installed (`helm version`)
- [ ] Docker installed (for building/pushing images)
- [ ] Access to AWS account with appropriate permissions
- [ ] Domain name (optional, for Route53/ACM)

### How to Check Prerequisites

**Don't know if you have these? Run these commands:**

```bash
# Check AWS CLI
aws --version
# Expected: aws-cli/2.x.x or similar
# If error: Install AWS CLI from https://aws.amazon.com/cli/

# Check Terraform
terraform --version
# Expected: Terraform v1.x.x
# If error: Install Terraform from https://www.terraform.io/downloads

# Check kubectl
kubectl version --client
# Expected: Client Version: version.Info{...}
# If error: Install kubectl from https://kubernetes.io/docs/tasks/tools/

# Check Helm
helm version
# Expected: version.BuildInfo{Version:"v3.x.x",...}
# If error: Install Helm from https://helm.sh/docs/intro/install/

# Check Docker
docker --version
# Expected: Docker version 20.x.x or similar
# If error: Install Docker from https://docs.docker.com/get-docker/
```

**If any command shows an error, install that tool before continuing.**

---

## 🎯 Deployment Strategy

We'll deploy in phases using Terraform targets to ensure dependencies are met:

1. **Phase 1: Foundation** - VPC, Networking, Security Groups
2. **Phase 2: Data Layer** - RDS, ElastiCache
3. **Phase 3: Compute** - EKS Cluster, Nodes
4. **Phase 4: Container Registry** - ECR
5. **Phase 5: Load Balancing** - ALB, Ingress
6. **Phase 6: Monitoring & Security** - CloudTrail, Flow Logs, Secrets Manager, CloudWatch

---

## Step 0: Initial Setup

### What We're Doing
Setting up Terraform configuration files with your specific values. Think of this as telling Terraform "this is my AWS account, these are my preferences."

### Step 0.1: Navigate to Terraform Directory

```bash
# Open terminal and navigate to the project
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"

# Verify you're in the right place
ls
# You should see files like: variables.tf, terraform.tfvars, vpc.tf, etc.
```

**What this does:** Changes your terminal to the Terraform directory so all commands run in the right place.

**Expected output:** List of Terraform files (variables.tf, terraform.tfvars, etc.)

---

### Step 0.2: Configure AWS Credentials

**Before Terraform can create anything, it needs to know who you are in AWS.**

```bash
# Check if AWS CLI is configured
aws sts get-caller-identity
```

**Expected output:**
```json
{
    "UserId": "AIDA...",
    "Account": "123456789012",
    "Arn": "arn:aws:iam::123456789012:user/yourname"
}
```

**If you get an error:**
```bash
# Configure AWS CLI
aws configure
# You'll be asked for:
# - AWS Access Key ID: (get from AWS Console → IAM → Users → Security Credentials)
# - AWS Secret Access Key: (get from same place)
# - Default region: us-east-1
# - Default output format: json
```

**⚠️ Important:** You need AWS credentials with permissions to create:
- VPC, Subnets, Security Groups
- EKS Clusters
- RDS Instances
- ElastiCache Clusters
- ECR Repositories
- IAM Roles and Policies
- S3 Buckets
- CloudWatch, CloudTrail, etc.

---

### Step 0.3: Edit terraform.tfvars

**This file contains YOUR specific values. Terraform uses these instead of defaults.**

1. **Open `terraform.tfvars` in a text editor:**
```bash
# On Mac/Linux:
open terraform.tfvars
# Or use: nano terraform.tfvars, vim terraform.tfvars, or your favorite editor

# On Windows:
notepad terraform.tfvars
```

2. **Find and update these values:**

```hcl
# ⚠️ CRITICAL: Change this to something unique!
bucket_name_prefix = "your-unique-prefix-12345"  
# Why: S3 bucket names must be globally unique across ALL AWS accounts
# Example: "my-name-h-game-2024" (use your name + date)

# ⚠️ CRITICAL: Change this password!
rds_password = "YourSecurePassword123!"
# Why: Default password is insecure
# Requirements: At least 8 characters, mix of letters, numbers, symbols

# Optional: Set your email for alerts
alert_email = "your-email@example.com"
# Or leave empty: alert_email = ""  (disables email alerts)
```

3. **Save the file**

**What this does:** Tells Terraform to use YOUR values instead of defaults. Without this, Terraform might fail or create resources with default/insecure values.

---

### Step 0.4: Initialize Terraform

**This downloads the AWS provider plugin Terraform needs to talk to AWS.**

```bash
cd h-game-terraform
terraform init
```

**Expected output:**
```
Initializing the backend...
Initializing provider plugins...
- Finding hashicorp/aws versions matching "~> 6.0"...
- Installing hashicorp/aws v6.x.x...
- Installed hashicorp/aws v6.x.x
...
Terraform has been successfully initialized!
```

**What this does:**
- Downloads AWS provider plugin
- Sets up backend (where Terraform stores state)
- Prepares Terraform to create AWS resources

**If you see errors:**
- "No valid credential sources": Run `aws configure` (see Step 0.2)
- "Provider not found": Check internet connection, Terraform downloads from internet
- "Backend configuration error": Check your backend.tf file

**✅ Checkpoint:** You should see "Terraform has been successfully initialized!" at the end.

---

## Phase 1: Foundation (VPC, Networking, Security Groups)

### What We're Building
Think of this as building the foundation of a house:
- **VPC** = Your private network in AWS (like a private neighborhood)
- **Subnets** = Sections of your network (like blocks in the neighborhood)
- **Internet Gateway** = Door to the internet
- **NAT Gateway** = Allows private subnets to access internet (but internet can't access them)
- **Security Groups** = Firewall rules (who can talk to what)

**Why first:** Everything else (databases, servers, etc.) needs to live inside this network.

---

### Step 1.1: Create VPC and Basic Networking

**What this does:** Creates your private network and divides it into sections.

```bash
cd h-game-terraform

# Create VPC, Internet Gateway, and Subnets
terraform apply -target=aws_vpc.main \
  -target=aws_internet_gateway.main \
  -target=aws_subnet.public \
  -target=aws_subnet.private \
  -target=aws_route_table.public \
  -target=aws_route_table_association.public \
  -auto-approve
```

**What `-target` means:** Only create these specific resources (not everything at once).

**What `-auto-approve` means:** Don't ask "yes/no", just do it (saves time).

**Expected output:**
```
aws_vpc.main: Creating...
aws_vpc.main: Creation complete after 3s [id=vpc-0abc123...]
aws_internet_gateway.main: Creating...
aws_internet_gateway.main: Creation complete after 2s [id=igw-0def456...]
...
Apply complete! Resources: 6 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 1-2 minutes

**If you see errors:**
- "Error: InvalidParameterValue": Check your terraform.tfvars values
- "Error: UnauthorizedOperation": Your AWS user doesn't have permissions
- "Error: VpcLimitExceeded": You've hit AWS account limits (contact AWS support)

---

### Step 1.2: Create NAT Gateway

**What this does:** Allows resources in private subnets (like databases) to access the internet, but prevents the internet from accessing them directly. This is a security best practice.

```bash
# Create NAT Gateway (for private subnet internet access)
terraform apply -target=aws_eip.nat \
  -target=aws_nat_gateway.main \
  -target=aws_route_table.private \
  -target=aws_route_table_association.private \
  -auto-approve
```

**Expected output:**
```
aws_eip.nat[0]: Creating...
aws_eip.nat[0]: Creation complete after 2s [id=eipalloc-0abc123...]
aws_nat_gateway.main[0]: Creating...
aws_nat_gateway.main[0]: Still creating... [30s elapsed]
aws_nat_gateway.main[0]: Creation complete after 1m5s [id=nat-0def456...]
...
Apply complete! Resources: 4 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 1-2 minutes (NAT Gateway takes ~1 minute to create)

**💡 What's happening:** AWS is creating a NAT Gateway, which is like a one-way door - your private resources can go out to the internet, but internet can't come in.

---

### Step 1.3: Create Security Groups

**What this does:** Creates firewall rules that control who can talk to what. Like bouncers at different doors.

```bash
# Create Security Groups (firewall rules)
terraform apply -target=aws_security_group.alb \
  -target=aws_security_group.database \
  -target=aws_security_group.cache \
  -target=aws_security_group.eks_cluster \
  -target=aws_security_group.eks_nodes \
  -auto-approve
```

**Expected output:**
```
aws_security_group.alb: Creating...
aws_security_group.alb: Creation complete after 2s [id=sg-0abc123...]
aws_security_group.database: Creating...
...
Apply complete! Resources: 5 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 30 seconds

**💡 What's happening:** Creating 5 different "firewalls":
- `alb`: For the load balancer (allows internet traffic)
- `database`: For RDS (only allows connections from backend)
- `cache`: For ElastiCache (only allows connections from backend)
- `eks_cluster`: For Kubernetes cluster
- `eks_nodes`: For Kubernetes worker nodes

---

### Step 1.4: Verify Phase 1

**Let's make sure everything was created correctly:**

```bash
# Get VPC ID
terraform output vpc_id
# Expected: vpc-0abc123def4567890
# If empty: Something went wrong, check terraform state

# Get Public Subnet IDs
terraform output public_subnet_ids
# Expected: ["subnet-0abc123...", "subnet-0def456...", "subnet-0ghi789..."]
# Should show 3 subnets (one per availability zone)

# Get Private Subnet IDs
terraform output private_subnet_ids
# Expected: ["subnet-0xyz123...", "subnet-0uvw456...", "subnet-0rst789..."]
# Should show 3 subnets
```

**✅ Checkpoint - Did it work?**
- [ ] VPC ID shows (starts with `vpc-`)
- [ ] 3 public subnets listed
- [ ] 3 private subnets listed
- [ ] No error messages

**If something is missing:** Run `terraform plan` to see what Terraform thinks should exist. If resources show as "to be created", run the apply command again.

**🎉 Phase 1 Complete!** You now have a network foundation. Everything else will be built on top of this.

---

## Phase 2: Data Layer (RDS, ElastiCache)

### What We're Building
- **RDS (PostgreSQL)**: Your database - stores game data, user scores, etc.
- **ElastiCache (Redis)**: Your cache - stores temporary data for fast access

**Why second:** Your application needs databases to store and retrieve data. Without databases, the app can't work.

**💡 Beginner Explanation:**
- **Database** = Like a filing cabinet that stores permanent information
- **Cache** = Like a sticky note on your desk for quick reminders

---

### Step 2.1: Create RDS Subnet Group and Parameter Group

**What this does:** 
- **Subnet Group**: Tells RDS which subnets it can use (must be private subnets for security)
- **Parameter Group**: Database settings (like PostgreSQL version, timezone, etc.)

```bash
cd h-game-terraform

# Create RDS Subnet Group and Parameter Group
terraform apply -target=aws_db_subnet_group.main \
  -target=aws_db_parameter_group.postgres \
  -auto-approve
```

**Expected output:**
```
aws_db_subnet_group.main: Creating...
aws_db_subnet_group.main: Creation complete after 2s [id=h-game-learning-db-subnet-group]
aws_db_parameter_group.postgres: Creating...
aws_db_parameter_group.postgres: Creation complete after 2s [id=h-game-learning-postgres-params]
Apply complete! Resources: 2 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 30 seconds

**✅ Checkpoint:** Should see "Creation complete" for both resources.

---

### Step 2.2: Create RDS Database Instance

**What this does:** Creates the actual PostgreSQL database server. This is where your game data will be stored.

**⚠️ Important:** This step takes 5-10 minutes. RDS needs time to:
1. Launch a database server
2. Install PostgreSQL
3. Configure it
4. Make it available

```bash
# Create RDS Instance (PostgreSQL database)
terraform apply -target=aws_db_instance.postgres \
  -auto-approve
```

**Expected output:**
```
aws_db_instance.postgres: Creating...
aws_db_instance.postgres: Still creating... [30s elapsed]
aws_db_instance.postgres: Still creating... [1m0s elapsed]
aws_db_instance.postgres: Still creating... [2m0s elapsed]
...
aws_db_instance.postgres: Creation complete after 5m30s [id=db-ABC123...]
Apply complete! Resources: 1 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 5-10 minutes (this is normal, databases take time to create)

**💡 What's happening:** AWS is:
1. Starting a database server (like starting a computer)
2. Installing PostgreSQL software
3. Creating your database
4. Setting up backups
5. Making it accessible

**While waiting:** You can see progress in the terminal. Don't cancel this!

---

### Step 2.3: Create ElastiCache Subnet Group

**What this does:** Tells ElastiCache which subnets it can use (also private subnets for security).

```bash
# Create ElastiCache Subnet Group
terraform apply -target=aws_elasticache_subnet_group.main \
  -auto-approve
```

**Expected output:**
```
aws_elasticache_subnet_group.main: Creating...
aws_elasticache_subnet_group.main: Creation complete after 2s [id=h-game-learning-cache-subnet-group]
Apply complete! Resources: 1 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 30 seconds

---

### Step 2.4: Create ElastiCache Cluster

**What this does:** Creates the Redis cache server for fast data access.

**⚠️ Important:** This also takes 5-10 minutes.

```bash
# Create ElastiCache Cluster (Redis cache)
terraform apply -target=aws_elasticache_cluster.redis \
  -auto-approve
```

**Expected output:**
```
aws_elasticache_cluster.redis: Creating...
aws_elasticache_cluster.redis: Still creating... [30s elapsed]
aws_elasticache_cluster.redis: Still creating... [1m0s elapsed]
...
aws_elasticache_cluster.redis: Creation complete after 6m15s [id=h-game-redis]
Apply complete! Resources: 1 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 5-10 minutes

**💡 What's happening:** AWS is creating a Redis cache server, similar to RDS but faster (in-memory storage).

---

### Step 2.5: Wait for Databases to Be Ready

**Why:** Even though Terraform says "Creation complete", the databases might still be starting up. We need to wait until they're actually ready to accept connections.

```bash
# Check RDS status
aws rds describe-db-instances \
  --db-instance-identifier h-game-postgres \
  --query 'DBInstances[0].DBInstanceStatus' \
  --output text
```

**Expected output:** `available`

**If you see:**
- `creating`: Still starting up, wait 2-3 more minutes
- `backing-up`: Creating first backup, wait 1-2 minutes
- `available`: ✅ Ready to use!

```bash
# Check ElastiCache status
aws elasticache describe-cache-clusters \
  --cache-cluster-id h-game-redis \
  --query 'CacheClusters[0].CacheClusterStatus' \
  --output text
```

**Expected output:** `available`

**If you see:**
- `creating`: Still starting up, wait 2-3 more minutes
- `available`: ✅ Ready to use!

**⏱️ Time:** If status is "creating", wait 2-5 minutes and check again.

**💡 Pro tip:** You can keep checking until both show "available":
```bash
# Keep checking until ready (runs every 30 seconds)
while true; do
  RDS_STATUS=$(aws rds describe-db-instances --db-instance-identifier h-game-postgres --query 'DBInstances[0].DBInstanceStatus' --output text)
  CACHE_STATUS=$(aws elasticache describe-cache-clusters --cache-cluster-id h-game-redis --query 'CacheClusters[0].CacheClusterStatus' --output text)
  echo "RDS: $RDS_STATUS | Cache: $CACHE_STATUS"
  if [ "$RDS_STATUS" = "available" ] && [ "$CACHE_STATUS" = "available" ]; then
    echo "✅ Both databases are ready!"
    break
  fi
  sleep 30
done
```

---

### Step 2.6: Get Database Endpoints

**What this does:** Gets the addresses where your application will connect to the databases.

```bash
# Get RDS endpoint (where to connect to database)
terraform output rds_endpoint
```

**Expected output:**
```
h-game-postgres.abc123xyz.us-east-1.rds.amazonaws.com:5432
```

**What this means:**
- `h-game-postgres`: Database name
- `abc123xyz.us-east-1.rds.amazonaws.com`: Server address
- `:5432`: Port (PostgreSQL default port)

```bash
# Get ElastiCache endpoint (where to connect to cache)
terraform output elasticache_endpoint
```

**Expected output:**
```
h-game-redis.abc123.ng.0001.use1.cache.amazonaws.com
```

**💡 Save these endpoints!** You'll need them later when configuring your application.

**✅ Checkpoint - Did it work?**
- [ ] RDS status = `available`
- [ ] ElastiCache status = `available`
- [ ] RDS endpoint shows (starts with `h-game-postgres`)
- [ ] ElastiCache endpoint shows (starts with `h-game-redis`)

**🎉 Phase 2 Complete!** You now have databases ready. Your application can store and retrieve data.

---

## Phase 3: Compute (EKS Cluster, Nodes)

### What We're Building
- **EKS Cluster**: Kubernetes control plane (the "brain" that manages everything)
- **EKS Nodes**: Worker servers that run your applications (the "muscle")

**Why third:** You need a place to run your applications. EKS is like a factory that runs your containers.

**💡 Beginner Explanation:**
- **EKS Cluster** = The manager/orchestrator (tells workers what to do)
- **EKS Nodes** = The workers (actually run your applications)
- Think of it like a restaurant: Cluster = head chef, Nodes = kitchen staff

---

### Step 3.1: Create IAM Roles for EKS

**What this does:** Creates AWS permissions (IAM roles) that EKS needs to manage resources.

**💡 What is IAM?** IAM = Identity and Access Management. It's AWS's way of saying "who can do what."

```bash
cd h-game-terraform

# Create IAM roles and attach policies
terraform apply -target=aws_iam_role.eks_cluster \
  -target=aws_iam_role_policy_attachment.eks_cluster_policy \
  -target=aws_iam_role.eks_nodes \
  -target=aws_iam_role_policy_attachment.eks_worker_node_policy \
  -target=aws_iam_role_policy_attachment.eks_cni_policy \
  -target=aws_iam_role_policy_attachment.eks_container_registry_policy \
  -auto-approve
```

**Expected output:**
```
aws_iam_role.eks_cluster: Creating...
aws_iam_role.eks_cluster: Creation complete after 2s [id=h-game-learning-eks-cluster-role]
aws_iam_role_policy_attachment.eks_cluster_policy: Creating...
...
Apply complete! Resources: 7 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 30 seconds

**✅ Checkpoint:** Should see "Creation complete" for all 7 resources.

---

### Step 3.2: Create OIDC Provider

**What this does:** Creates an OpenID Connect provider. This allows Kubernetes to securely use AWS IAM roles.

**💡 What is OIDC?** It's a secure way for Kubernetes to prove "I am who I say I am" to AWS.

**⚠️ Note:** This might already exist if you've run this before. That's OK - Terraform will skip it.

```bash
# Create OIDC Provider (for secure IAM integration)
terraform apply -target=data.tls_certificate.eks \
  -target=aws_iam_openid_connect_provider.eks \
  -auto-approve
```

**Expected output:**
```
data.tls_certificate.eks: Reading...
data.tls_certificate.eks: Read complete after 1s [id=...]
aws_iam_openid_connect_provider.eks: Creating...
aws_iam_openid_connect_provider.eks: Creation complete after 2s [id=arn:aws:iam::...]
Apply complete! Resources: 1 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 30 seconds

**If you see:** "already exists" - that's fine! It means it was created before.

---

### Step 3.3: Create EKS Cluster

**What this does:** Creates the Kubernetes control plane. This is the "brain" that manages your applications.

**⚠️ Important:** This takes 10-15 minutes. The EKS control plane needs time to:
1. Create the Kubernetes API server
2. Set up networking
3. Configure security
4. Make it accessible

```bash
# Create EKS Cluster (Kubernetes control plane)
terraform apply -target=aws_eks_cluster.main \
  -auto-approve
```

**Expected output:**
```
aws_eks_cluster.main: Creating...
aws_eks_cluster.main: Still creating... [30s elapsed]
aws_eks_cluster.main: Still creating... [1m0s elapsed]
aws_eks_cluster.main: Still creating... [2m0s elapsed]
...
aws_eks_cluster.main: Creation complete after 12m30s [id=h-game-prod]
Apply complete! Resources: 1 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 10-15 minutes (this is normal, EKS clusters take time)

**💡 What's happening:** AWS is:
1. Creating Kubernetes API server
2. Setting up networking
3. Configuring security
4. Making the cluster accessible

**While waiting:** You can see progress in the terminal. Don't cancel this! Grab a coffee ☕

**✅ Checkpoint:** Wait until you see "Creation complete" before continuing.

---

### Step 3.4: Configure kubectl

**What this does:** Tells your local `kubectl` command how to talk to your EKS cluster.

**💡 What is kubectl?** It's the command-line tool to control Kubernetes (like `git` for Git, but for Kubernetes).

```bash
# Configure kubectl to connect to your EKS cluster
aws eks update-kubeconfig --name h-game-prod --region us-east-1
```

**Expected output:**
```
Added new context arn:aws:eks:us-east-1:123456789012:cluster/h-game-prod to /Users/yourname/.kube/config
```

**What this does:** Creates a configuration file that tells kubectl "when I run kubectl commands, talk to THIS cluster."

**Test the connection:**
```bash
# Test kubectl connection
kubectl get nodes
```

**Expected output (first time, before nodes are created):**
```
No resources found
```

**This is OK!** Nodes haven't been created yet. We'll create them next.

**If you see an error:**
- "Unable to connect to the server": Cluster might still be creating, wait 2-3 more minutes
- "error: exec: 'kubectl'": kubectl not installed (see Prerequisites)

---

### Step 3.5: Create EKS Node Group

**What this does:** Creates the worker servers (nodes) that actually run your applications.

**⚠️ Important:** This takes 5-10 minutes. Nodes need time to:
1. Launch EC2 instances
2. Install Kubernetes software
3. Join the cluster
4. Become ready

```bash
# Create EKS Node Group (worker servers)
terraform apply -target=aws_eks_node_group.main \
  -auto-approve
```

**Expected output:**
```
aws_eks_node_group.main: Creating...
aws_eks_node_group.main: Still creating... [30s elapsed]
aws_eks_node_group.main: Still creating... [1m0s elapsed]
...
aws_eks_node_group.main: Creation complete after 6m15s [id=h-game-prod:h-game-nodes]
Apply complete! Resources: 1 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 5-10 minutes

**💡 What's happening:** AWS is:
1. Launching EC2 instances (servers)
2. Installing Kubernetes software on them
3. Connecting them to your cluster
4. Making them ready to run applications

---

### Step 3.6: Wait for Nodes to Be Ready

**Why:** Even though Terraform says "Creation complete", nodes might still be joining the cluster.

```bash
# Check cluster status
aws eks describe-cluster --name h-game-prod \
  --query 'cluster.status' --output text
```

**Expected output:** `ACTIVE`

**If you see:**
- `CREATING`: Still starting up, wait 2-3 more minutes
- `ACTIVE`: ✅ Ready!

```bash
# Check nodes
kubectl get nodes
```

**Expected output (after nodes are ready):**
```
NAME                          STATUS   ROLES    AGE   VERSION
ip-10-0-11-254.ec2.internal   Ready    <none>   2m    v1.29.15-eks-...
ip-10-0-13-93.ec2.internal    Ready    <none>   2m    v1.29.15-eks-...
```

**What you're looking for:**
- `STATUS` column should show `Ready` (not `NotReady`)
- Should see 2 nodes (based on `eks_node_desired_size = 2` in terraform.tfvars)

**If nodes show `NotReady`:**
- Wait 2-3 more minutes (nodes are still joining)
- Check again: `kubectl get nodes`

**If you see "No resources found":**
- Nodes might still be creating
- Wait 2-3 minutes and check again
- Or check: `kubectl get nodes -w` (watch mode, updates automatically)

**⏱️ Time:** If nodes show `NotReady`, wait 2-5 minutes and check again.

**✅ Checkpoint - Did it work?**
- [ ] Cluster status = `ACTIVE`
- [ ] At least 2 nodes show `Ready` status
- [ ] No error messages

**🎉 Phase 3 Complete!** You now have a Kubernetes cluster with worker nodes. You can run applications!

---

## Phase 4: Container Registry (ECR)

### What We're Building
- **ECR Repositories**: Private storage for your Docker images (like a private app store)

**Why fourth:** Before Kubernetes can run your application, it needs the Docker images. ECR is where those images are stored.

**💡 Beginner Explanation:**
- **Docker Image** = A package containing your application code
- **ECR** = A secure storage place for those packages
- Think of it like: Docker Image = a boxed product, ECR = the warehouse

---

### Step 4.1: Create ECR Repositories

**What this does:** Creates two "storage rooms" in ECR - one for backend images, one for frontend images.

```bash
cd h-game-terraform

# Create ECR Repositories
terraform apply -target=aws_ecr_repository.backend \
  -target=aws_ecr_repository.frontend \
  -target=aws_ecr_lifecycle_policy.backend \
  -target=aws_ecr_lifecycle_policy.frontend \
  -auto-approve
```

**Expected output:**
```
aws_ecr_repository.backend: Creating...
aws_ecr_repository.backend: Creation complete after 2s [id=h-game-backend]
aws_ecr_repository.frontend: Creating...
aws_ecr_repository.frontend: Creation complete after 2s [id=h-game-frontend]
aws_ecr_lifecycle_policy.backend: Creating...
...
Apply complete! Resources: 4 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 30 seconds

**✅ Checkpoint:** Should see "Creation complete" for all 4 resources.

---

### Step 4.2: Get Repository URLs

**What this does:** Gets the addresses where you'll push your Docker images.

```bash
# Get backend repository URL
terraform output ecr_backend_repository_url
```

**Expected output:**
```
334091769766.dkr.ecr.us-east-1.amazonaws.com/h-game-backend
```

**What this means:**
- `334091769766`: Your AWS account ID
- `dkr.ecr.us-east-1.amazonaws.com`: ECR service address
- `h-game-backend`: Repository name

```bash
# Get frontend repository URL
terraform output ecr_frontend_repository_url
```

**Expected output:**
```
334091769766.dkr.ecr.us-east-1.amazonaws.com/h-game-frontend
```

**💡 Save these URLs!** You'll need them to push images.

---

### Step 4.3: Authenticate Docker to ECR

**What this does:** Gives Docker permission to push images to your ECR repositories.

**💡 Why needed:** ECR is private. You need to prove you're allowed to push images.

```bash
# Get your AWS account ID and region
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
AWS_REGION=$(aws configure get region)

# Print them to verify
echo "Account ID: $AWS_ACCOUNT_ID"
echo "Region: $AWS_REGION"
```

**Expected output:**
```
Account ID: 334091769766
Region: us-east-1
```

**If you see errors:**
- "Unable to locate credentials": Run `aws configure` (see Step 0.2)

```bash
# Authenticate Docker to ECR
aws ecr get-login-password --region $AWS_REGION | \
  docker login --username AWS --password-stdin \
  $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com
```

**Expected output:**
```
Login Succeeded
```

**What this does:**
1. Gets a temporary password from AWS
2. Logs Docker into ECR using that password
3. Now Docker can push/pull images

**If you see "Login Succeeded":** ✅ You're authenticated!

**If you see an error:**
- "Error: GetAuthorizationToken": Check AWS credentials (`aws configure`)
- "Error: docker: command not found": Docker not installed (see Prerequisites)

---

### Step 4.4: Build and Push Backend Image

**What this does:** 
1. Builds a Docker image from your backend code
2. Pushes it to ECR so Kubernetes can use it

**⚠️ Important:** You need your backend source code for this step.

```bash
# Get backend repository URL
cd h-game-terraform
BACKEND_REPO=$(terraform output -raw ecr_backend_repository_url)
echo "Backend repo: $BACKEND_REPO"
```

**Expected output:**
```
Backend repo: 334091769766.dkr.ecr.us-east-1.amazonaws.com/h-game-backend
```

**Navigate to your backend directory:**
```bash
# ⚠️ UPDATE THIS PATH to where your backend code is located
cd ~/path/to/your/backend  # Replace with actual path

# Verify you're in the right place (should see Dockerfile)
ls Dockerfile
# Expected: Dockerfile (the file should exist)
```

**If you don't have backend code:**
- You can use the existing image from Docker Hub temporarily
- Or skip this step and use: `veeno/humor-game-backend:v2` (not recommended for production)

**Build the image:**
```bash
# Build Docker image
docker build -t $BACKEND_REPO:latest .
```

**Expected output:**
```
Sending build context to Docker daemon...
Step 1/10 : FROM node:18-alpine
...
Successfully built abc123def456
Successfully tagged 334091769766.dkr.ecr.us-east-1.amazonaws.com/h-game-backend:latest
```

**⏱️ Time:** 2-5 minutes (depends on your code size)

**What this does:** Docker reads your `Dockerfile` and creates an image containing your application.

**Push the image:**
```bash
# Push image to ECR
docker push $BACKEND_REPO:latest
```

**Expected output:**
```
The push refers to repository [334091769766.dkr.ecr.us-east-1.amazonaws.com/h-game-backend]
abc123def456: Pushing...
...
latest: digest: sha256:abc123... size: 856
```

**⏱️ Time:** 1-3 minutes (depends on image size)

**What this does:** Uploads your image to ECR so Kubernetes can download it later.

**✅ Checkpoint:** Should see "digest: sha256:..." at the end (means push succeeded).

---

### Step 4.5: Build and Push Frontend Image

**Same process as backend, but for frontend:**

```bash
# Get frontend repository URL
cd h-game-terraform
FRONTEND_REPO=$(terraform output -raw ecr_frontend_repository_url)
echo "Frontend repo: $FRONTEND_REPO"

# Navigate to frontend directory
cd ~/path/to/your/frontend  # ⚠️ UPDATE THIS PATH

# Build image
docker build -t $FRONTEND_REPO:latest .

# Push image
docker push $FRONTEND_REPO:latest
```

**Expected output (similar to backend):**
```
Successfully built xyz789ghi012
Successfully tagged 334091769766.dkr.ecr.us-east-1.amazonaws.com/h-game-frontend:latest
The push refers to repository [...]
latest: digest: sha256:xyz789... size: 856
```

**✅ Checkpoint:** Both images pushed successfully.

---

### Step 4.6: Verify Images in ECR

**Let's make sure the images are actually in ECR:**

```bash
# List images in backend repository
aws ecr list-images --repository-name h-game-backend
```

**Expected output:**
```json
{
    "imageIds": [
        {
            "imageDigest": "sha256:abc123...",
            "imageTag": "latest"
        }
    ]
}
```

```bash
# List images in frontend repository
aws ecr list-images --repository-name h-game-frontend
```

**Expected output:**
```json
{
    "imageIds": [
        {
            "imageDigest": "sha256:xyz789...",
            "imageTag": "latest"
        }
    ]
}
```

**✅ Checkpoint - Did it work?**
- [ ] Backend repository shows `latest` tag
- [ ] Frontend repository shows `latest` tag
- [ ] Both have imageDigest (means image exists)

**🎉 Phase 4 Complete!** Your Docker images are now in ECR. Kubernetes can pull them when needed.

---

## Phase 5: Load Balancing (ALB, Ingress)

### What We're Building
- **AWS Load Balancer Controller**: Kubernetes add-on that creates ALBs automatically
- **Ingress**: Kubernetes resource that routes traffic to your applications
- **ALB (Application Load Balancer)**: Distributes internet traffic to your pods

**Why fifth:** Your applications are running, but they need a way for users on the internet to reach them. The ALB is like a receptionist that directs visitors to the right office.

**💡 Beginner Explanation:**
- **ALB** = A smart router that sends internet traffic to the right application
- **Ingress** = A rule that says "send /api requests to backend, send / requests to frontend"
- Think of it like: ALB = front desk, Ingress = directory board

---

### Step 5.1: Install AWS Load Balancer Controller

**What this does:** Installs a Kubernetes add-on that automatically creates AWS ALBs when you create Ingress resources.

**💡 What is Helm?** Helm is a package manager for Kubernetes (like `npm` for Node.js, but for Kubernetes apps).

```bash
# Add Helm repository (where the controller package is stored)
helm repo add eks https://aws.github.io/eks-charts
helm repo update
```

**Expected output:**
```
"eks" has been added to your repositories
Hang tight while we grab the latest from your chart repositories...
...Successfully got an update from the "eks" chart repository
Update Complete. ⎈Happy Helming!⎈
```

**What this does:** Downloads information about available Kubernetes packages.

```bash
# Get your cluster name
cd h-game-terraform
CLUSTER_NAME=$(terraform output -raw eks_cluster_name)
echo "Cluster name: $CLUSTER_NAME"
```

**Expected output:**
```
Cluster name: h-game-prod
```

```bash
# Install AWS Load Balancer Controller
helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system \
  --set clusterName=$CLUSTER_NAME \
  --set serviceAccount.create=false \
  --set serviceAccount.name=aws-load-balancer-controller
```

**Expected output:**
```
NAME: aws-load-balancer-controller
LAST DEPLOYED: Mon Jan 15 10:30:00 2024
NAMESPACE: kube-system
STATUS: deployed
REVISION: 1
```

**What this does:** Installs the controller that will create ALBs for you.

**Wait for controller to start:**
```bash
# Wait 30 seconds for controller to start
sleep 30

# Check if controller is running
kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller
```

**Expected output:**
```
NAME                                           READY   STATUS    RESTARTS   AGE
aws-load-balancer-controller-7d8f9c4b5-abc12   1/1     Running   0          45s
```

**What you're looking for:**
- `STATUS` should be `Running` (not `Pending` or `Error`)
- `READY` should be `1/1` (means pod is ready)

**If STATUS is `Pending` or `Error`:**
- Wait 1-2 more minutes and check again
- Check logs: `kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller`

**✅ Checkpoint:** Controller pod should be `Running`.

---

### Step 5.2: Apply ALB Security Group Rules

**What this does:** Creates firewall rules that allow the ALB to talk to your pods (backend and frontend).

**💡 Why needed:** By default, security groups block all traffic. We need to explicitly allow ALB → Pods communication.

```bash
cd h-game-terraform

# Security group rules for ALB → Pods
terraform apply -target=data.aws_security_group.eks_cluster_managed \
  -target=aws_security_group_rule.alb_to_eks_managed_nodes_backend \
  -target=aws_security_group_rule.alb_to_eks_managed_nodes_frontend \
  -auto-approve
```

**Expected output:**
```
data.aws_security_group.eks_cluster_managed: Reading...
data.aws_security_group.eks_cluster_managed: Read complete after 1s [id=sg-0abc123...]
aws_security_group_rule.alb_to_eks_managed_nodes_backend: Creating...
aws_security_group_rule.alb_to_eks_managed_nodes_backend: Creation complete after 2s [id=sgrule-0def456...]
aws_security_group_rule.alb_to_eks_managed_nodes_frontend: Creating...
aws_security_group_rule.alb_to_eks_managed_nodes_frontend: Creation complete after 2s [id=sgrule-0ghi789...]
Apply complete! Resources: 2 added, 0 changed, 0 destroyed.
```

**⏱️ Time:** 30 seconds

**✅ Checkpoint:** Should see "Creation complete" for both security group rules.

---

### Step 5.3: Deploy Kubernetes Resources

**What this does:** Deploys your applications (backend and frontend) to Kubernetes.

**💡 What we're creating:**
- **Namespace**: A "folder" in Kubernetes to organize your resources
- **ConfigMap**: Configuration settings (like environment variables)
- **Secrets**: Sensitive data (like database passwords)
- **Deployments**: Your applications (backend and frontend)
- **Services**: Network endpoints that expose your applications inside the cluster

```bash
cd k8s

# 1. Create namespace (a "folder" for your resources)
kubectl create namespace h-game
```

**Expected output:**
```
namespace/h-game created
```

**If you see "already exists":** That's OK! It means the namespace was created before.

```bash
# 2. Create ConfigMap and Secrets (configuration and passwords)
kubectl apply -f app-config.yaml
kubectl apply -f postgres-secret.yaml
kubectl apply -f redis-secret.yaml
```

**Expected output:**
```
configmap/app-config created
secret/postgres-secret created
secret/redis-secret created
```

**What this does:** Creates configuration files that your applications will use.

```bash
# 3. Update deployment files with ECR URLs
# ⚠️ IMPORTANT: You need to edit the deployment files first!

# Get your ECR repository URLs
cd ../h-game-terraform
BACKEND_REPO=$(terraform output -raw ecr_backend_repository_url)
FRONTEND_REPO=$(terraform output -raw ecr_frontend_repository_url)

echo "Backend repo: $BACKEND_REPO"
echo "Frontend repo: $FRONTEND_REPO"
```

**Expected output:**
```
Backend repo: 334091769766.dkr.ecr.us-east-1.amazonaws.com/h-game-backend
Frontend repo: 334091769766.dkr.ecr.us-east-1.amazonaws.com/h-game-frontend
```

**Now edit the deployment files:**
```bash
cd ../k8s

# Edit backend-deployment.yaml
# Find the line: image: some-image:tag
# Replace it with: image: $BACKEND_REPO:latest
# Or manually edit the file and replace the image line

# Edit frontend-deployment.yaml
# Find the line: image: some-image:tag
# Replace it with: image: $FRONTEND_REPO:latest
# Or manually edit the file and replace the image line
```

**💡 Pro tip:** You can use `sed` to automatically replace:
```bash
# Replace image in backend-deployment.yaml (if it has a placeholder)
sed -i '' "s|image:.*|image: $BACKEND_REPO:latest|g" backend-deployment.yaml

# Replace image in frontend-deployment.yaml (if it has a placeholder)
sed -i '' "s|image:.*|image: $FRONTEND_REPO:latest|g" frontend-deployment.yaml
```

**Verify the changes:**
```bash
# Check backend image
grep "image:" backend-deployment.yaml
# Should show your ECR URL

# Check frontend image
grep "image:" frontend-deployment.yaml
# Should show your ECR URL
```

```bash
# 4. Deploy backend
kubectl apply -f backend-deployment.yaml
kubectl apply -f backend-service.yaml
```

**Expected output:**
```
deployment.apps/backend created
service/backend-service created
```

```bash
# 5. Deploy frontend
kubectl apply -f frontend-deployment.yaml
kubectl apply -f frontend-service.yaml
```

**Expected output:**
```
deployment.apps/frontend created
service/frontend-service created
```

```bash
# 6. Wait for pods to be ready (this takes 1-2 minutes)
kubectl wait --for=condition=ready pod -l app=backend -n h-game --timeout=300s
kubectl wait --for=condition=ready pod -l app=frontend -n h-game --timeout=300s
```

**Expected output:**
```
pod/backend-abc123-xyz ready
pod/backend-abc123-def ready
pod/backend-abc123-ghi ready
pod/frontend-xyz789-abc ready
pod/frontend-xyz789-def ready
```

**What this does:** Waits until your pods are actually running and ready to accept traffic.

**If you see "timeout":**
- Check pod status: `kubectl get pods -n h-game`
- Check pod logs: `kubectl logs -n h-game -l app=backend`
- Common issues: Image pull errors, missing secrets, wrong configuration

**✅ Checkpoint:** All pods should be `Running` and `Ready`.

---

### Step 5.4: Create Ingress

```bash
cd k8s

# Get Terraform outputs
cd ../h-game-terraform
ALB_SG=$(terraform output -raw alb_security_group_id)
PUBLIC_SUBNETS=$(terraform output -json public_subnet_ids | jq -r 'join(",")')

# Update ingress.yaml with actual values
cd ../k8s
sed -i '' "s|REPLACE_WITH_ALB_SG|$ALB_SG|g" ingress.yaml
sed -i '' "s|REPLACE_WITH_PUBLIC_SUBNETS|$PUBLIC_SUBNETS|g" ingress.yaml

# Apply Ingress
kubectl apply -f ingress.yaml

# Wait for ALB (2-3 minutes)
echo "Waiting for ALB to be created..."
while [ -z "$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')" ]; do
  echo "Still waiting... (checking every 10 seconds)"
  sleep 10
done

ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
echo "✅ ALB created: http://$ALB_URL"
```

### Run Database Migration

```bash
cd k8s

# Apply migration ConfigMap and Job
kubectl apply -f postgres-migration-configmap.yaml
kubectl apply -f postgres-migration-job.yaml

# Watch migration
kubectl logs -f job/postgres-migration -n h-game

# Verify success
kubectl get job postgres-migration -n h-game
# Should show: COMPLETIONS 1/1
```

---

## Phase 6: Monitoring & Security (CloudTrail, Flow Logs, Secrets Manager, CloudWatch)

**Why last:** These enhance existing infrastructure.

### Apply Monitoring & Security Resources

```bash
cd h-game-terraform

# 1. CloudTrail (Audit Logging)
terraform apply -target=aws_s3_bucket.cloudtrail_logs \
  -target=aws_s3_bucket_versioning.cloudtrail_logs \
  -target=aws_s3_bucket_server_side_encryption_configuration.cloudtrail_logs \
  -target=aws_s3_bucket_policy.cloudtrail_logs \
  -target=aws_cloudtrail.main \
  -auto-approve

# 2. VPC Flow Logs
terraform apply -target=aws_cloudwatch_log_group.vpc_flow_logs \
  -target=aws_iam_role.vpc_flow_logs \
  -target=aws_iam_role_policy.vpc_flow_logs \
  -target=aws_flow_log.main \
  -auto-approve

# 3. Secrets Manager
terraform apply -target=aws_secretsmanager_secret.rds_password \
  -target=aws_secretsmanager_secret_version.rds_password \
  -target=aws_secretsmanager_secret.api_keys \
  -target=aws_secretsmanager_secret_version.api_keys \
  -target=aws_iam_policy.secrets_manager_access \
  -target=aws_iam_role_policy_attachment.secrets_manager_access \
  -auto-approve

# 4. CloudWatch Monitoring
terraform apply -target=aws_cloudwatch_log_group.eks_cluster \
  -target=aws_cloudwatch_log_group.alb_access \
  -target=aws_cloudwatch_metric_alarm.high_cpu \
  -target=aws_cloudwatch_metric_alarm.high_memory \
  -target=aws_sns_topic.alerts \
  -target=aws_sns_topic_subscription.email \
  -auto-approve
```

**⚠️ Important: SNS Email Subscription**
```bash
# Check your email for SNS subscription confirmation
# Subject: "AWS Notification - Subscription Confirmation"
# Click "Confirm subscription" link
# Without confirmation, you won't receive alerts!
```

---

## Phase 7: Auto-Scaling (Cluster Autoscaler)

**Why last:** Requires EKS cluster and nodes to be running.

### Apply Auto-Scaling Resources

```bash
cd h-game-terraform

# 1. Update node group max_size (if not already done)
# Edit terraform.tfvars: eks_node_max_size = 8
terraform apply -target=aws_eks_node_group.main \
  -auto-approve

# 2. Cluster Autoscaler IAM Policy
terraform apply -target=aws_iam_policy.cluster_autoscaler \
  -target=aws_iam_role_policy_attachment.cluster_autoscaler \
  -auto-approve

# 3. Install Cluster Autoscaler via Helm
CLUSTER_NAME=$(terraform output -raw eks_cluster_name)
AWS_REGION=$(terraform output -raw aws_region 2>/dev/null || echo "us-east-1")

helm install cluster-autoscaler autoscaler/cluster-autoscaler \
  -n kube-system \
  --set autoDiscovery.clusterName=$CLUSTER_NAME \
  --set aws.region=$AWS_REGION \
  --set extraArgs.scale-down-delay-after-add=10m \
  --set extraArgs.scale-down-unneeded-time=10m \
  --set extraArgs.scale-down-utilization-threshold=0.5

# Verify
sleep 30
kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-cluster-autoscaler
```

---

## 🚀 Complete Deployment Commands (Copy-Paste Ready)

For experienced users, here are all the commands in order (copy and paste each phase):

### Phase 1: Foundation
```bash
cd h-game-terraform
terraform apply -target=aws_vpc.main \
  -target=aws_internet_gateway.main \
  -target=aws_subnet.public \
  -target=aws_subnet.private \
  -target=aws_route_table.public \
  -target=aws_route_table_association.public \
  -target=aws_eip.nat \
  -target=aws_nat_gateway.main \
  -target=aws_route_table.private \
  -target=aws_route_table_association.private \
  -target=aws_security_group.alb \
  -target=aws_security_group.database \
  -target=aws_security_group.cache \
  -target=aws_security_group.eks_cluster \
  -target=aws_security_group.eks_nodes \
  -auto-approve
```

### Phase 2: Data Layer
```bash
terraform apply -target=aws_db_subnet_group.main \
  -target=aws_db_parameter_group.postgres \
  -target=aws_db_instance.postgres \
  -target=aws_elasticache_subnet_group.main \
  -target=aws_elasticache_cluster.redis \
  -auto-approve

# Wait for RDS and ElastiCache
aws rds wait db-instance-available --db-instance-identifier h-game-postgres
aws elasticache wait cache-cluster-available --cache-cluster-id h-game-redis
```

### Phase 3: Compute
```bash
terraform apply -target=aws_iam_role.eks_cluster \
  -target=aws_iam_role_policy_attachment.eks_cluster_policy \
  -target=aws_iam_role.eks_nodes \
  -target=aws_iam_role_policy_attachment.eks_worker_node_policy \
  -target=aws_iam_role_policy_attachment.eks_cni_policy \
  -target=aws_iam_role_policy_attachment.eks_container_registry_policy \
  -target=data.tls_certificate.eks \
  -target=aws_iam_openid_connect_provider.eks \
  -target=aws_eks_cluster.main \
  -auto-approve

# Wait for cluster
aws eks wait cluster-active --name h-game-prod
aws eks update-kubeconfig --name h-game-prod --region us-east-1

terraform apply -target=aws_eks_node_group.main -auto-approve
kubectl wait --for=condition=ready nodes --all --timeout=600s
```

### Phase 4: Container Registry
```bash
terraform apply -target=aws_ecr_repository.backend \
  -target=aws_ecr_repository.frontend \
  -target=aws_ecr_lifecycle_policy.backend \
  -target=aws_ecr_lifecycle_policy.frontend \
  -auto-approve
```

### Phase 5: Load Balancing
```bash
terraform apply -target=data.aws_security_group.eks_cluster_managed \
  -target=aws_security_group_rule.alb_to_eks_managed_nodes_backend \
  -target=aws_security_group_rule.alb_to_eks_managed_nodes_frontend \
  -auto-approve
```

### Phase 6: Monitoring & Security
```bash
terraform apply -target=aws_s3_bucket.cloudtrail_logs \
  -target=aws_s3_bucket_versioning.cloudtrail_logs \
  -target=aws_s3_bucket_server_side_encryption_configuration.cloudtrail_logs \
  -target=aws_s3_bucket_policy.cloudtrail_logs \
  -target=aws_cloudtrail.main \
  -target=aws_cloudwatch_log_group.vpc_flow_logs \
  -target=aws_iam_role.vpc_flow_logs \
  -target=aws_iam_role_policy.vpc_flow_logs \
  -target=aws_flow_log.main \
  -target=aws_secretsmanager_secret.rds_password \
  -target=aws_secretsmanager_secret_version.rds_password \
  -target=aws_secretsmanager_secret.api_keys \
  -target=aws_secretsmanager_secret_version.api_keys \
  -target=aws_iam_policy.secrets_manager_access \
  -target=aws_iam_role_policy_attachment.secrets_manager_access \
  -target=aws_cloudwatch_log_group.eks_cluster \
  -target=aws_cloudwatch_log_group.alb_access \
  -target=aws_cloudwatch_metric_alarm.high_cpu \
  -target=aws_cloudwatch_metric_alarm.high_memory \
  -target=aws_sns_topic.alerts \
  -target=aws_sns_topic_subscription.email \
  -auto-approve
```

### Phase 7: Auto-Scaling
```bash
terraform apply -target=aws_iam_policy.cluster_autoscaler \
  -target=aws_iam_role_policy_attachment.cluster_autoscaler \
  -auto-approve

# Install Cluster Autoscaler
CLUSTER_NAME=$(terraform output -raw eks_cluster_name)
AWS_REGION=$(terraform output -raw aws_region 2>/dev/null || echo "us-east-1")
helm repo add autoscaler https://kubernetes.github.io/autoscaler
helm repo update
helm install cluster-autoscaler autoscaler/cluster-autoscaler \
  -n kube-system \
  --set autoDiscovery.clusterName=$CLUSTER_NAME \
  --set aws.region=$AWS_REGION \
  --set extraArgs.scale-down-delay-after-add=10m \
  --set extraArgs.scale-down-unneeded-time=10m \
  --set extraArgs.scale-down-utilization-threshold=0.5
```

---

## 📝 Deployment Checklist

Use this checklist to track your progress:

### Infrastructure (Terraform)
- [ ] Phase 1: Foundation (VPC, Networking, Security Groups)
- [ ] Phase 2: Data Layer (RDS, ElastiCache)
- [ ] Phase 3: Compute (EKS Cluster, Nodes)
- [ ] Phase 4: Container Registry (ECR)
- [ ] Phase 5: Load Balancing (ALB Security Groups)
- [ ] Phase 6: Monitoring & Security (CloudTrail, Flow Logs, Secrets Manager, CloudWatch)
- [ ] Phase 7: Auto-Scaling (Cluster Autoscaler)

### Application (Kubernetes)
- [ ] Namespace created
- [ ] ConfigMaps and Secrets created
- [ ] Backend deployment and service
- [ ] Frontend deployment and service
- [ ] Ingress created
- [ ] Database migration completed
- [ ] Images pushed to ECR
- [ ] Pods running and healthy

### Verification
- [ ] Application accessible via ALB URL
- [ ] Health endpoint working
- [ ] Database connected
- [ ] Redis connected
- [ ] Auto-scaling tested
- [ ] CloudWatch alarms configured
- [ ] SNS email subscription confirmed

---

## 🔧 Troubleshooting

### Issue: Terraform State Lock

**Symptom:** `Error acquiring the state lock`

**Fix:**
```bash
# Get lock ID from error message, then:
terraform force-unlock -force <LOCK_ID>
```

### Issue: Resources Already Exist

**Symptom:** `ResourceAlreadyExistsException`

**Fix:**
```bash
# Import existing resource
terraform import <resource_type>.<resource_name> <resource_id>
```

### Issue: Pods Not Starting

**Symptom:** Pods in `Pending` or `ImagePullBackOff`

**Fix:**
```bash
# Check events
kubectl describe pod <pod-name> -n h-game

# Verify ECR authentication
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  $(aws sts get-caller-identity --query Account --output text).dkr.ecr.us-east-1.amazonaws.com

# Check image exists in ECR
aws ecr list-images --repository-name h-game-backend
```

### Issue: ALB Not Created

**Symptom:** Ingress has no ADDRESS

**Fix:**
```bash
# Check controller logs
kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller

# Verify IAM role
kubectl get sa aws-load-balancer-controller -n kube-system \
  -o jsonpath='{.metadata.annotations.eks\.amazonaws\.com/role-arn}'

# Restart controller
kubectl rollout restart deployment aws-load-balancer-controller -n kube-system
```

---

## 📚 Additional Resources

- **Terraform Documentation:** https://www.terraform.io/docs
- **Kubernetes Documentation:** https://kubernetes.io/docs
- **AWS EKS User Guide:** https://docs.aws.amazon.com/eks/
- **AWS Load Balancer Controller:** https://kubernetes-sigs.github.io/aws-load-balancer-controller/

---

## ✅ Final Verification

After completing all phases, verify everything works:

```bash
# Get ALB URL
ALB_URL=$(kubectl get ingress h-game -n h-game -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

# Test endpoints
curl http://$ALB_URL/health
curl http://$ALB_URL/api
curl http://$ALB_URL/api/leaderboard

# Check all pods
kubectl get pods -n h-game

# Check all nodes
kubectl get nodes

# Check cluster autoscaler
kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-cluster-autoscaler
```

---

**Congratulations!** 🎉 You've successfully deployed the entire infrastructure and application!

---

## 🎓 What You've Learned (For Beginners)

If this is your first time deploying to AWS, here's what you've accomplished:

### Infrastructure Components You Created:

1. **VPC (Virtual Private Cloud)**
   - Your own private network in AWS
   - Like having your own private internet

2. **Subnets**
   - Sections of your network
   - Public subnets: Can be accessed from internet
   - Private subnets: Hidden from internet (more secure)

3. **Security Groups**
   - Firewall rules
   - Controls who can talk to what

4. **RDS (PostgreSQL Database)**
   - Managed database service
   - Stores your application data permanently

5. **ElastiCache (Redis)**
   - Fast in-memory cache
   - Stores temporary data for quick access

6. **EKS (Kubernetes Cluster)**
   - Container orchestration platform
   - Runs and manages your applications

7. **ECR (Container Registry)**
   - Private storage for Docker images
   - Like a private app store

8. **ALB (Application Load Balancer)**
   - Distributes internet traffic to your apps
   - Like a smart router

9. **CloudWatch, CloudTrail, VPC Flow Logs**
   - Monitoring and logging services
   - Help you see what's happening

10. **Secrets Manager**
    - Secure storage for passwords and keys
    - Better than hardcoding secrets

### Key Concepts You Now Understand:

- **Infrastructure as Code (IaC)**: Using Terraform to define infrastructure in files
- **Container Orchestration**: Using Kubernetes to manage containers
- **Load Balancing**: Distributing traffic across multiple servers
- **Auto-Scaling**: Automatically adding/removing servers based on demand
- **Security Best Practices**: Using private subnets, security groups, secrets management

### Next Steps for Learning:

1. **Explore AWS Console**: Log in and see all the resources you created
2. **Read Logs**: Check CloudWatch logs to see what your applications are doing
3. **Monitor Costs**: Check AWS Billing Dashboard to see how much you're spending
4. **Experiment**: Try changing Terraform variables and see what happens
5. **Learn More**: Read AWS documentation for services you're using

---

## 🆘 Common Beginner Mistakes & How to Fix Them

### Mistake 1: Forgot to Configure AWS Credentials

**Symptom:** `Unable to locate credentials` or `Access Denied`

**Fix:**
```bash
aws configure
# Enter your AWS Access Key ID, Secret Access Key, region, and output format
```

**How to get credentials:**
1. Go to AWS Console → IAM → Users → Your User → Security Credentials
2. Create Access Key
3. Copy Access Key ID and Secret Access Key

---

### Mistake 2: Wrong Directory

**Symptom:** `No such file or directory` or `terraform: command not found`

**Fix:**
```bash
# Always check where you are
pwd
# Should show: /path/to/devops playbook/h-game-terraform

# If wrong, navigate to correct directory
cd "/Users/mac/Desktop/devops playbook/h-game-terraform"
```

---

### Mistake 3: Forgot to Initialize Terraform

**Symptom:** `Error: Could not load plugin` or `Backend configuration changed`

**Fix:**
```bash
cd h-game-terraform
terraform init
```

**When to run:** Always run `terraform init` when:
- First time using this Terraform code
- After pulling new changes from git
- After adding new providers

---

### Mistake 4: Didn't Wait for Resources to Be Ready

**Symptom:** `Error: Resource not found` or `Connection refused`

**Fix:** Always wait for resources to be ready:
- RDS: Wait until status is `available` (5-10 minutes)
- ElastiCache: Wait until status is `available` (5-10 minutes)
- EKS Cluster: Wait until status is `ACTIVE` (10-15 minutes)
- EKS Nodes: Wait until `kubectl get nodes` shows `Ready` (5-10 minutes)

**How to check:**
```bash
# For RDS
aws rds describe-db-instances --db-instance-identifier h-game-postgres \
  --query 'DBInstances[0].DBInstanceStatus' --output text

# For ElastiCache
aws elasticache describe-cache-clusters --cache-cluster-id h-game-redis \
  --query 'CacheClusters[0].CacheClusterStatus' --output text

# For EKS
aws eks describe-cluster --name h-game-prod \
  --query 'cluster.status' --output text

# For Nodes
kubectl get nodes
```

---

### Mistake 5: Wrong Image URLs in Kubernetes Deployments

**Symptom:** Pods in `ImagePullBackOff` or `ErrImagePull`

**Fix:**
```bash
# Get correct ECR URLs
cd h-game-terraform
terraform output ecr_backend_repository_url
terraform output ecr_frontend_repository_url

# Update deployment files
cd ../k8s
# Edit backend-deployment.yaml and frontend-deployment.yaml
# Replace image: line with correct ECR URLs

# Reapply
kubectl apply -f backend-deployment.yaml
kubectl apply -f frontend-deployment.yaml
```

---

### Mistake 6: Forgot to Authenticate Docker to ECR

**Symptom:** `Error: GetAuthorizationToken` or `unauthorized: authentication required`

**Fix:**
```bash
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
AWS_REGION=$(aws configure get region)
aws ecr get-login-password --region $AWS_REGION | \
  docker login --username AWS --password-stdin \
  $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com
```

**Expected output:** `Login Succeeded`

---

### Mistake 7: Didn't Confirm SNS Email Subscription

**Symptom:** Not receiving CloudWatch alerts

**Fix:**
1. Check your email inbox (and spam folder)
2. Look for email from AWS with subject: "AWS Notification - Subscription Confirmation"
3. Click the "Confirm subscription" link
4. You should see: "Subscription confirmed!"

**Without confirmation:** You won't receive any alerts, even if alarms trigger.

---

### Mistake 8: Running Commands in Wrong Order

**Symptom:** `Error: depends_on` or `Resource not found`

**Fix:** Always follow the phases in order:
1. Phase 1: Foundation (VPC, Networking)
2. Phase 2: Data Layer (RDS, ElastiCache)
3. Phase 3: Compute (EKS)
4. Phase 4: Container Registry (ECR)
5. Phase 5: Load Balancing (ALB, Ingress)
6. Phase 6: Monitoring & Security
7. Phase 7: Auto-Scaling

**Why:** Each phase depends on the previous one. You can't create a database before you have a network!

---

### Mistake 9: Not Checking Pod Logs When Things Break

**Symptom:** Application not working, but don't know why

**Fix:**
```bash
# Check pod status
kubectl get pods -n h-game

# Check pod logs
kubectl logs -n h-game <pod-name>

# Check all backend logs
kubectl logs -n h-game -l app=backend

# Check pod events (why it's failing)
kubectl describe pod <pod-name> -n h-game
```

**Common log errors:**
- `Connection refused`: Database not ready or wrong endpoint
- `ImagePullBackOff`: Wrong image URL or ECR authentication issue
- `CrashLoopBackOff`: Application error, check logs

---

### Mistake 10: Not Saving Important Outputs

**Symptom:** Need database endpoint or ALB URL but forgot to save it

**Fix:** Always save important outputs:
```bash
# Save to file
cd h-game-terraform
terraform output > outputs.txt

# Or save specific values
terraform output rds_endpoint > rds-endpoint.txt
terraform output elasticache_endpoint > redis-endpoint.txt

# Get ALB URL
kubectl get ingress h-game -n h-game \
  -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' > alb-url.txt
```

---

## 💡 Pro Tips for Beginners

1. **Read Error Messages Carefully**
   - AWS error messages usually tell you exactly what's wrong
   - Copy the error message and search for it online

2. **Use `terraform plan` Before `terraform apply`**
   - Shows you what will be created/changed
   - Helps catch mistakes before they happen

3. **Check AWS Console**
   - Sometimes it's easier to see what's happening in the web console
   - Go to AWS Console → Services → Find your resource

4. **Use `kubectl get` to Check Status**
   - `kubectl get pods -n h-game`: See all pods
   - `kubectl get services -n h-game`: See all services
   - `kubectl get ingress -n h-game`: See ingress status

5. **Don't Panic if Something Takes Time**
   - RDS takes 5-10 minutes to create (normal!)
   - EKS takes 10-15 minutes to create (normal!)
   - ALB takes 2-3 minutes to create (normal!)

6. **Keep a Log of What You Did**
   - Write down commands you ran
   - Note any errors and how you fixed them
   - Helps if you need to do it again

7. **Test Incrementally**
   - Don't wait until the end to test
   - Test after each phase
   - Easier to find problems early

---

## 📞 Getting Help

If you're stuck:

1. **Check the Error Message**
   - Copy the exact error
   - Search for it on Google or Stack Overflow

2. **Check AWS Documentation**
   - AWS has excellent documentation
   - Search for the service name + "documentation"

3. **Check Terraform Documentation**
   - https://registry.terraform.io/providers/hashicorp/aws/latest/docs
   - Search for the resource type you're using

4. **Check Kubernetes Documentation**
   - https://kubernetes.io/docs/
   - Search for the resource type (Deployment, Service, Ingress)

5. **Ask for Help**
   - Stack Overflow (tag: terraform, kubernetes, aws)
   - AWS Forums
   - Terraform Community

---

**Remember:** Everyone was a beginner once. Don't give up! 🚀

