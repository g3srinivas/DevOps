# Complete Infrastructure Destruction Guide

**⚠️ WARNING: This will DELETE ALL resources. This action cannot be undone!**

This guide will help you completely destroy all infrastructure resources.

---

## Step 1: Delete Kubernetes Resources

**Why first:** Kubernetes resources might reference AWS resources, so delete them first.

```bash
# Delete all Kubernetes resources in h-game namespace
kubectl delete namespace h-game

# Wait for namespace to be deleted
kubectl wait --for=delete namespace/h-game --timeout=300s

# Delete AWS Load Balancer Controller (if installed)
helm uninstall aws-load-balancer-controller -n kube-system

# Delete Cluster Autoscaler (if installed)
helm uninstall cluster-autoscaler -n kube-system

# Verify all resources are deleted
kubectl get all --all-namespaces
```

---

## Step 2: Destroy Terraform Infrastructure

**This will delete ALL AWS resources created by Terraform.**

```bash
cd h-game-terraform

# Destroy everything
terraform destroy -auto-approve
```

**Expected time:** 15-30 minutes (some resources take time to delete)

**What gets deleted:**
- EKS Cluster and Nodes
- RDS Database
- ElastiCache Redis
- ECR Repositories (and all images)
- ALB and related resources
- VPC, Subnets, Security Groups
- CloudTrail, VPC Flow Logs
- Secrets Manager secrets
- CloudWatch Log Groups
- SNS Topics
- All IAM roles and policies
- Everything else created by Terraform

---

## Step 3: Verify Everything is Deleted

```bash
# Check EKS clusters
aws eks list-clusters
# Should be empty or not show h-game-prod

# Check RDS instances
aws rds describe-db-instances --query 'DBInstances[?contains(DBInstanceIdentifier, `h-game`)].DBInstanceIdentifier'
# Should be empty

# Check ElastiCache clusters
aws elasticache describe-cache-clusters --query 'CacheClusters[?contains(CacheClusterId, `h-game`)].CacheClusterId'
# Should be empty

# Check ECR repositories
aws ecr describe-repositories --query 'repositories[?contains(repositoryName, `h-game`)].repositoryName'
# Should be empty

# Check ALBs
aws elbv2 describe-load-balancers --query 'LoadBalancers[?contains(LoadBalancerName, `h-game`)].LoadBalancerName'
# Should be empty

# Check VPCs
aws ec2 describe-vpcs --filters "Name=tag:Project,Values=h-game" --query 'Vpcs[*].VpcId'
# Should be empty
```

---

## Step 4: Clean Up Terraform State

```bash
cd h-game-terraform

# Remove Terraform state files (optional, but ensures clean slate)
rm -rf .terraform
rm -f terraform.tfstate terraform.tfstate.backup
rm -rf .terraform.lock.hcl

# Note: This removes local state. If using remote state (S3), you may want to keep .terraform/
```

---

## Step 5: Clean Up kubectl Context

```bash
# Remove EKS cluster context from kubectl
kubectl config delete-context $(kubectl config get-contexts -o name | grep h-game)

# Or remove all contexts (if you want a complete clean)
# kubectl config delete-context $(kubectl config get-contexts -o name)
```

---

## Step 6: Final Verification

```bash
# List all resources with h-game tag
aws resourcegroupstaggingapi get-resources \
  --tag-filters Key=Project,Values=h-game \
  --query 'ResourceTagMappingList[*].ResourceARN'

# Should return empty or minimal (only tags, not actual resources)
```

---

## ⚠️ Important Notes

1. **S3 Buckets:** If you created S3 buckets (like for CloudTrail logs), they might not be deleted if they contain objects. You'll need to empty them first:
   ```bash
   # List buckets
   aws s3 ls | grep h-game
   
   # Empty and delete each bucket
   aws s3 rm s3://bucket-name --recursive
   aws s3 rb s3://bucket-name
   ```

2. **CloudWatch Log Groups:** Some log groups might persist. Delete manually if needed:
   ```bash
   aws logs describe-log-groups --query 'logGroups[?contains(logGroupName, `h-game`)].logGroupName' --output text | \
     xargs -I {} aws logs delete-log-group --log-group-name {}
   ```

3. **IAM Roles:** Some IAM roles might have dependencies. Check and delete manually:
   ```bash
   aws iam list-roles --query 'Roles[?contains(RoleName, `h-game`)].RoleName' --output text
   ```

4. **NAT Gateway:** Takes 5-10 minutes to delete (AWS limitation)

5. **RDS Snapshots:** Final snapshots might be created. Delete them:
   ```bash
   aws rds describe-db-snapshots --query 'DBSnapshots[?contains(DBSnapshotIdentifier, `h-game`)].DBSnapshotIdentifier' --output text | \
     xargs -I {} aws rds delete-db-snapshot --db-snapshot-identifier {}
   ```

---

## 🎯 Quick Destroy (All-in-One)

If you want to destroy everything quickly:

```bash
# 1. Delete Kubernetes resources
kubectl delete namespace h-game --ignore-not-found=true
helm uninstall aws-load-balancer-controller -n kube-system --ignore-not-found=true
helm uninstall cluster-autoscaler -n kube-system --ignore-not-found=true

# 2. Destroy Terraform
cd h-game-terraform
terraform destroy -auto-approve

# 3. Wait for completion
echo "✅ Destruction complete! Verify with: aws eks list-clusters"
```

---

**After destruction:** Your AWS account should be clean, and you can start fresh tomorrow for DevSecOps practices!

