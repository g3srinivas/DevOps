# Alert: ServiceDown

## Description
Backend service is down or unreachable.

## Severity
Critical

## Symptoms
- No requests to backend service
- Health check failing
- Pods not running
- `up{job="backend-service"}` == 0

## Possible Causes
1. Pod crashes (OOM, errors)
2. Deployment scaled to 0
3. Network issues
4. Resource constraints
5. Node failures

## Investigation Steps
1. **Check pod status:**
   ```bash
   kubectl get pods -l app=backend -n h-game
   ```

2. **Check pod logs:**
   ```bash
   kubectl logs -l app=backend -n h-game --tail=50
   ```

3. **Check events:**
   ```bash
   kubectl get events --field-selector involvedObject.name=backend -n h-game --sort-by='.lastTimestamp'
   ```

4. **Check metrics in Grafana:**
   - Open: H-Game Unified Observability dashboard
   - Check Service Status panel

5. **Check logs in Loki:**
   ```logql
   {namespace="h-game", app="backend"} |= "error"
   ```

6. **Check traces in Jaeger:**
   - Service: `h-game-backend`
   - Look for failed requests

## Resolution Steps
1. **If pods crashed:**
   - Check logs for errors
   - Fix code if needed
   - Redeploy: `kubectl rollout restart deployment/backend -n h-game`

2. **If scaled to 0:**
   ```bash
   kubectl scale deployment backend --replicas=3 -n h-game
   ```

3. **If resource constraints:**
   - Check resource usage: `kubectl top pods -n h-game`
   - Increase resources in deployment if needed

4. **If network issues:**
   - Check service: `kubectl get svc backend-service -n h-game`
   - Check ingress: `kubectl get ingress -n h-game`

5. **If node failures:**
   - Check nodes: `kubectl get nodes`
   - Pods will be rescheduled automatically

## Prevention
- Set appropriate resource limits and requests
- Implement health checks (liveness/readiness probes)
- Monitor pod restarts
- Set up alerting for pod crashes
- Use HPA for automatic scaling

