# Alert: HighErrorRate

## Description
Error rate exceeds 1% for more than 5 minutes.

## Severity
Critical

## Symptoms
- High number of 4xx/5xx responses
- Users reporting errors
- Error rate > 1%
- `rate(http_errors_total[5m]) / rate(http_requests_total[5m]) > 0.01`

## Possible Causes
1. Application bugs
2. Database connection issues
3. External API failures
4. Configuration errors
5. Resource exhaustion
6. Recent deployment issues

## Investigation Steps
1. **Check error logs in Loki:**
   ```logql
   {namespace="h-game", app="backend"} |= "error"
   {namespace="h-game", app="backend"} | json | level="error"
   ```

2. **Check error metrics in Grafana:**
   - Open: H-Game Unified Observability dashboard
   - Check Error Rate panel
   - Check which endpoints are failing

3. **Check traces in Jaeger:**
   - Service: `h-game-backend`
   - Filter by errors
   - Look for slow/failed spans

4. **Check recent deployments:**
   ```bash
   kubectl get deployments -n h-game
   kubectl rollout history deployment/backend -n h-game
   ```

5. **Check database connectivity:**
   ```bash
   BACKEND_POD=$(kubectl get pods -l app=backend -n h-game -o jsonpath='{.items[0].metadata.name}')
   kubectl exec -n h-game $BACKEND_POD -- env | grep DB
   ```

6. **Check error patterns:**
   - Are errors specific to certain endpoints?
   - Are errors time-based?
   - Are errors user-specific?

## Resolution Steps
1. **Identify error pattern from logs:**
   - Look for common error messages
   - Check error frequency
   - Identify affected endpoints

2. **Check recent code changes:**
   - Review git history
   - Check if recent deployment caused issue

3. **Rollback if recent deployment caused issue:**
   ```bash
   kubectl rollout undo deployment/backend -n h-game
   ```

4. **Fix root cause:**
   - Fix code bugs
   - Fix configuration
   - Fix database connectivity
   - Fix external API issues

5. **Redeploy with fix:**
   ```bash
   kubectl rollout restart deployment/backend -n h-game
   ```

## Prevention
- Comprehensive testing before deployment
- Gradual rollouts (canary deployments)
- Error rate monitoring
- Automated error alerting
- Code review process
- Staging environment testing

