# Alert: [Alert Name]

## Description
[What this alert means]

## Severity
[Critical/Warning]

## Symptoms
- [Symptom 1]
- [Symptom 2]

## Possible Causes
1. [Cause 1]
2. [Cause 2]

## Investigation Steps
1. Check metrics in Grafana: [Dashboard URL]
2. Check logs in Loki: [LogQL query]
3. Check traces in Jaeger: [Service name]

## Resolution Steps
1. [Step 1]
2. [Step 2]

## Prevention
- [Prevention step 1]
- [Prevention step 2]

