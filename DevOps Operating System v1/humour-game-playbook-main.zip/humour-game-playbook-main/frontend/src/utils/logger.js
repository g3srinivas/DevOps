// Structured logging for frontend (JSON format for Loki)
const log = (level, message, metadata = {}) => {
  const logEntry = {
    timestamp: new Date().toISOString(),
    level,
    message,
    service: 'h-game-frontend',
    ...metadata
  };
  
  // Output as JSON string for Promtail to scrape
  console.log(JSON.stringify(logEntry));
};

export const logger = {
  info: (message, metadata) => log('info', message, metadata),
  warn: (message, metadata) => log('warn', message, metadata),
  error: (message, metadata) => log('error', message, metadata),
  debug: (message, metadata) => log('debug', message, metadata)
};

