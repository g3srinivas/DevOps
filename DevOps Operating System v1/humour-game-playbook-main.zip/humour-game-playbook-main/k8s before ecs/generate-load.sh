#!/bin/bash

# ============================================
# LOAD GENERATOR SCRIPT
# ============================================
# Generates HTTP load on the backend to test HPA scaling
# 
# Usage:
#   ./generate-load.sh
#   Press Ctrl+C to stop

# Get the Ingress IP (MicroK8s node IP)
INGRESS_IP=$(kubectl get nodes -o wide 2>/dev/null | grep -v NAME | awk '{print $6}')

# Fallback to localhost if kubectl fails
if [ -z "$INGRESS_IP" ]; then
  INGRESS_IP="localhost"
  echo "⚠️  Could not get node IP, using localhost"
fi

# For EC2, you'll need the EC2 public IP
# Uncomment and replace with your EC2 public IP:
# INGRESS_IP="54.123.45.67"

echo "🚀 Generating load on backend..."
echo "📍 Target: http://${INGRESS_IP}/api/health"
echo "🎯 HPA will scale up when CPU > 70% or Memory > 80%"
echo "⏹️  Press Ctrl+C to stop"
echo ""

# Counter for requests
REQUEST_COUNT=0

# Trap Ctrl+C to show summary
trap 'echo ""; echo "📊 Load generation stopped"; echo "📈 Total requests sent: $REQUEST_COUNT"; exit 0' INT

while true; do
  # Make concurrent requests (10 parallel requests)
  for i in {1..10}; do
    curl -s -H "Host: game.localhost" \
         http://${INGRESS_IP}/api/health > /dev/null 2>&1 &
    ((REQUEST_COUNT++))
  done
  
  # Small delay to prevent overwhelming the system
  sleep 0.1
  
  # Show progress every 100 requests
  if [ $((REQUEST_COUNT % 100)) -eq 0 ]; then
    echo "📊 Requests sent: $REQUEST_COUNT"
  fi
done

