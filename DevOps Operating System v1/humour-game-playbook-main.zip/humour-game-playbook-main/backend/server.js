// Backend API Server - Humor Memory Game
// API-only server for separated frontend/backend architecture

// Initialize OpenTelemetry tracing FIRST (before any other imports)
require('./tracing');

require('dotenv').config();
const express = require('express');
const { trace, context } = require('@opentelemetry/api');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

// Import custom modules
const database = require('./models/database');
const redisClient = require('./utils/redis');

// Helper function to trace database queries
const traceDatabaseQuery = (query, params) => {
  const tracer = trace.getTracer('h-game-backend');
  const span = tracer.startSpan('database_query', {
    attributes: {
      'db.system': 'postgresql',
      'db.statement': query.substring(0, 500), // Limit statement length
      'db.params_count': params ? params.length : 0,
    },
  });
  
  return span;
};
const { metricsMiddleware, metricsEndpoint, updateGameMetrics, syncExistingGameData, initializeMetricsWithSampleData } = require('./middleware/metrics');
const logger = require('./logger');
const crypto = require('crypto');

// Create Express application
const app = express();
const PORT = process.env.PORT || 3001;

// ========================================
// MIDDLEWARE SETUP
// ========================================

// Security middleware
app.use(
  helmet({
    crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: false, // Let frontend handle CSP
  })
);

// CORS configuration for separated frontend
// Parse CORS_ORIGIN environment variable - support both string and array formats
let corsOrigins = [
  'http://localhost:3000', // For local development
  'http://localhost:3002', // For local development
  'http://localhost:80',   // For local development
  'http://frontend',       // Kubernetes service name
  'https://gameapp.games:8443',  // Add your domain for production
];

if (process.env.CORS_ORIGIN) {
  // If CORS_ORIGIN is set, parse it (support comma-separated strings)
  if (process.env.CORS_ORIGIN.includes(',')) {
    corsOrigins = process.env.CORS_ORIGIN.split(',').map(origin => origin.trim());
  } else {
    corsOrigins = [process.env.CORS_ORIGIN];
  }
}

app.use(
  cors({
    origin: corsOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  })
);

// Compression for better performance
app.use(compression());

// Request ID middleware (for log correlation)
app.use((req, res, next) => {
  req.id = crypto.randomBytes(16).toString('hex');
  res.setHeader('X-Request-ID', req.id);
  next();
});

// OpenTelemetry tracing middleware
app.use((req, res, next) => {
  const tracer = trace.getTracer('h-game-backend');
  const span = tracer.startSpan('http_request', {
    attributes: {
      'http.method': req.method,
      'http.url': req.url,
      'http.route': req.route ? req.route.path : req.path,
      'http.user_agent': req.get('user-agent'),
      'http.client_ip': req.ip,
    },
  });
  
  // Store span in request for later use
  req.span = span;
  
  // Run request in span context
  context.with(trace.setSpan(context.active(), span), () => {
    res.on('finish', () => {
      span.setAttribute('http.status_code', res.statusCode);
      span.setAttribute('http.status_text', res.statusMessage || 'OK');
      span.end();
    });
    
    next();
  });
});

// Structured logging middleware (with trace correlation)
app.use((req, res, next) => {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    const span = trace.getActiveSpan();
    const logData = {
      request_id: req.id,
      method: req.method,
      path: req.path,
      status_code: res.statusCode,
      duration_ms: duration,
      user_agent: req.get('user-agent'),
      ip: req.ip
    };
    
    // Add trace context to logs
    if (span) {
      const spanContext = span.spanContext();
      logData.trace_id = spanContext.traceId;
      logData.span_id = spanContext.spanId;
    }
    
    logger.info('HTTP request', logData);
  });
  
  next();
});

// Request logging (morgan for compatibility, but structured logs are primary)
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  message: {
    error: 'Too many requests from this IP, please try again later! 🐌',
    hint: 'Take a break and come back for more memory fun! 😄',
  },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// Prometheus metrics middleware (must be before routes)
app.use(metricsMiddleware);

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ========================================
// HEALTH CHECK ENDPOINT
// ========================================

app.get('/health', async (req, res) => {
  try {
    // Check database connection
    const dbCheck = await database.query('SELECT 1 as healthy');

    // Check Redis connection
    const redisCheck = await redisClient.ping();

    res.status(200).json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: dbCheck.rows[0].healthy === 1 ? 'connected' : 'error',
        redis: redisCheck === 'PONG' ? 'connected' : 'error',
        api: 'running',
      },
      version: process.env.npm_package_version || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
    });
  } catch (error) {
    logger.error('Health check failed', {
      request_id: req.id,
      error: error.message,
      stack: error.stack
    });
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: 'Service unavailable',
      message: 'The game API is taking a short break! 🎮💤',
    });
  }
});

// ========================================
// PROMETHEUS METRICS ENDPOINT
// ========================================

// Metrics are now handled by the Prometheus middleware

app.get('/metrics', metricsEndpoint);

// Debug endpoint to manually trigger metrics sync
app.get('/debug/sync-metrics', async (req, res) => {
  try {
    logger.info('Manual metrics sync triggered', { request_id: req.id });
    await syncExistingGameData(database);
    res.json({ success: true, message: 'Metrics sync completed' });
  } catch (error) {
    logger.error('Manual metrics sync failed', {
      request_id: req.id,
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ success: false, error: error.message });
  }
});

// Simple test endpoint to verify routing
app.get('/debug/test', (req, res) => {
  res.json({ success: true, message: 'Debug test endpoint working!', timestamp: new Date().toISOString() });
});

// Simple metrics test endpoint
app.get('/debug/simple-metrics', (req, res) => {
  try {
    logger.info('Simple metrics test triggered', { request_id: req.id });
    
    // Just set basic metrics without complex objects
    res.json({ 
      success: true, 
      message: 'Simple metrics test working!',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error('Simple metrics test failed', {
      request_id: req.id,
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ success: false, error: error.message });
  }
});

// Metrics are now handled by the Prometheus middleware

// ========================================
// API ROUTES
// ========================================

// API welcome endpoint
app.get('/api', (req, res) => {
  res.json({
    message: 'Welcome to the Humor Memory Game API! 🎮😂',
    version: '1.0.0',
    endpoints: {
      game: {
        'POST /api/game/start': 'Start a new game session',
        'POST /api/game/match': 'Submit a card match',
        'POST /api/game/complete': 'Complete a game and save score',
        'GET /api/game/:gameId': 'Get game details',
      },
      scores: {
        'GET /api/scores/:username': 'Get user scores and stats',
        'POST /api/scores/user': 'Create or update user',
      },
      leaderboard: {
        'GET /api/leaderboard': 'Get top players (cached)',
        'GET /api/leaderboard/fresh': 'Get fresh leaderboard data',
      },
    },
    health: '/api/health',
    documentation: 'API-only backend for separated architecture! 🎯',
  });
});

// API health endpoint (for nginx proxy)
app.get('/api/health', async (req, res) => {
  try {
    // Check database connection
    const dbCheck = await database.query('SELECT 1 as healthy');

    // Check Redis connection
    const redisCheck = await redisClient.ping();

    res.status(200).json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: dbCheck.rows[0].healthy === 1 ? 'connected' : 'error',
        redis: redisCheck === 'PONG' ? 'connected' : 'error',
        api: 'running',
      },
      version: process.env.npm_package_version || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
    });
  } catch (error) {
    logger.error('API health check failed', {
      request_id: req.id,
      error: error.message,
      stack: error.stack
    });
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: 'Service unavailable',
      message: 'The game API is taking a short break! 🎮💤',
    });
  }
});

// Import and mount API routes (moved after other middleware to avoid conflicts)
let gameRoutes;
let scoreRoutes;
let leaderboardRoutes;

try {
  gameRoutes = require('./routes/game');
  scoreRoutes = require('./routes/scores');
  leaderboardRoutes = require('./routes/leaderboard');

  // Mount API routes
  app.use('/api/game', gameRoutes);
  app.use('/api/scores', scoreRoutes);
  app.use('/api/leaderboard', leaderboardRoutes);
} catch (error) {
  logger.error('Error loading route modules', {
    error: error.message,
    stack: error.stack
  });
  logger.warn('Server starting in limited mode - some routes may not be available');
}

// ========================================
// ERROR HANDLING
// ========================================

// 404 handler for API routes
app.use('/api/*', (req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: 'API endpoint not found! 🔍',
    path: req.path,
    suggestion: 'Check /api for available endpoints',
  });
});

// Handle non-API routes (since this is API-only)
// REMOVED: This was causing frontend requests to be intercepted by backend
// app.use('*', (req, res) => {
//   res.status(404).json({
//     error: 'API Server Only',
//     message: 'This is an API-only server. Frontend is served separately! 🎮',
//     suggestion: 'Access the game at your frontend URL',
//   });
// });

// Global error handler
app.use((err, req, res, next) => {
  logger.error('Unhandled error', {
    request_id: req.id,
    method: req.method,
    path: req.path,
    error: err.message,
    stack: err.stack,
    status: err.status || 500
  });

  const isDevelopment = process.env.NODE_ENV !== 'production';

  res.status(err.status || 500).json({
    error: 'Internal Server Error',
    message: isDevelopment
      ? err.message
      : 'Something went wrong! Our devs are probably laughing at this bug right now! 😅',
    ...(isDevelopment && { stack: err.stack }),
    timestamp: new Date().toISOString(),
  });
});

app.disable('etag'); // disable ETag caching completely

// ========================================
// DATABASE AND REDIS INITIALIZATION
// ========================================

async function initializeServices() {
  try {
    logger.info('Connecting to database...');
    await database.testConnection();
    logger.info('Database connected successfully');

    logger.info('Connecting to Redis...');
    await redisClient.connect();
    logger.info('Redis connected successfully');

    return true;
  } catch (error) {
    logger.error('Failed to initialize services', {
      error: error.message,
      stack: error.stack
    });
    return false;
  }
}

// ========================================
// SERVER STARTUP
// ========================================

async function startServer() {
  try {
    // Initialize database and Redis connections
    const servicesReady = await initializeServices();

    if (!servicesReady) {
      logger.error('Cannot start server - services not ready');
      process.exit(1);
    }

    // Start the HTTP server
    const server = app.listen(PORT, '0.0.0.0', async () => {
      logger.info('Humor Memory Game API Server started', {
        port: PORT,
        environment: process.env.NODE_ENV || 'development'
      });
      
      // Initialize metrics with sample data first
      try {
        initializeMetricsWithSampleData();
        logger.info('Metrics initialized with sample data');
      } catch (error) {
        logger.error('Failed to initialize metrics with sample data', {
          error: error.message,
          stack: error.stack
        });
      }
      
      // Then try to sync existing game data to metrics
      try {
        await syncExistingGameData(database);
        logger.info('Existing game data synced to metrics');
      } catch (error) {
        logger.error('Failed to sync existing game data to metrics', {
          error: error.message,
          stack: error.stack
        });
      }
    });

    // Graceful shutdown handling
    process.on('SIGTERM', () => gracefulShutdown(server));
    process.on('SIGINT', () => gracefulShutdown(server));
  } catch (error) {
    logger.error('Failed to start server', {
      error: error.message,
      stack: error.stack
    });
    process.exit(1);
  }
}

// ========================================
// GRACEFUL SHUTDOWN
// ========================================

async function gracefulShutdown(server) {
  logger.info('Received shutdown signal. Starting graceful shutdown...');

  server.close(async () => {
    logger.info('HTTP server closed');

    try {
      await database.close();
      logger.info('Database connections closed');

      await redisClient.quit();
      logger.info('Redis connection closed');

      logger.info('Graceful shutdown completed');
      process.exit(0);
    } catch (error) {
      logger.error('Error during graceful shutdown', {
        error: error.message,
        stack: error.stack
      });
      process.exit(1);
    }
  });

  // Force close after 10 seconds
  setTimeout(() => {
    logger.error('Could not close connections in time, forcefully shutting down');
    process.exit(1);
  }, 10000);
}

// Start the server if this file is run directly
if (require.main === module) {
  startServer();
}

// Health check endpoint
app.get('/health', async (req, res) => {
  try {
    // Check database connection
    await database.query('SELECT 1');

    // Check Redis connection
    await redisClient.ping();

    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: process.env.APP_VERSION || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
      services: {
        database: 'healthy',
        redis: 'healthy',
        api: 'healthy',
      },
    });
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error.message,
    });
  }
});

module.exports = app;
