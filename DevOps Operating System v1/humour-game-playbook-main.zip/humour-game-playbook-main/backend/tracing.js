// OpenTelemetry tracing setup for H-Game backend
const { NodeSDK } = require('@opentelemetry/sdk-node');
const { OTLPTraceExporter } = require('@opentelemetry/exporter-trace-otlp-http');
const { HttpInstrumentation } = require('@opentelemetry/instrumentation-http');
const { ExpressInstrumentation } = require('@opentelemetry/instrumentation-express');
const { Resource } = require('@opentelemetry/resources');
const { SemanticResourceAttributes } = require('@opentelemetry/semantic-conventions');

// Configure OTLP exporter (sends traces to Jaeger via OTLP protocol)
// Port 4318 is OTLP HTTP, port 4317 is OTLP gRPC
const jaegerEndpoint = process.env.JAEGER_ENDPOINT || 'http://jaeger.monitoring.svc.cluster.local:4318/v1/traces';
console.log('🔍 Jaeger endpoint:', jaegerEndpoint);

const otlpExporter = new OTLPTraceExporter({
  url: jaegerEndpoint,
  // Add headers if needed
  headers: {},
});

// Initialize OpenTelemetry SDK
const sdk = new NodeSDK({
  resource: new Resource({
    [SemanticResourceAttributes.SERVICE_NAME]: 'h-game-backend',
    [SemanticResourceAttributes.SERVICE_VERSION]: process.env.npm_package_version || '1.0.0',
  }),
  traceExporter: otlpExporter,
  instrumentations: [
    new HttpInstrumentation(),
    new ExpressInstrumentation(),
  ],
});

// Start the SDK
sdk.start();

console.log('✅ OpenTelemetry initialized for h-game-backend');
console.log('🔍 Service name: h-game-backend');
console.log('🔍 Jaeger endpoint:', jaegerEndpoint);

// Handle shutdown gracefully
process.on('SIGTERM', () => {
  sdk.shutdown()
    .then(() => console.log('OpenTelemetry SDK shut down successfully'))
    .catch((error) => console.error('Error shutting down OpenTelemetry SDK', error))
    .finally(() => process.exit(0));
});

module.exports = sdk;

