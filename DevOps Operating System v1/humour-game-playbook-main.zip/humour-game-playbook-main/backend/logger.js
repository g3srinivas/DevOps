// Structured logging with Winston for Loki aggregation
const winston = require('winston');
const { trace } = require('@opentelemetry/api');

// Custom format to inject trace context
const traceContextFormat = winston.format((info) => {
  const span = trace.getActiveSpan();
  if (span) {
    const spanContext = span.spanContext();
    info.trace_id = spanContext.traceId;
    info.span_id = spanContext.spanId;
  }
  return info;
});

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    traceContextFormat(),
    winston.format.json()
  ),
  defaultMeta: {
    service: 'h-game-backend',
    environment: process.env.NODE_ENV || 'production'
  },
  transports: [
    new winston.transports.Console({
      format: winston.format.json()
    })
  ]
});

module.exports = logger;

