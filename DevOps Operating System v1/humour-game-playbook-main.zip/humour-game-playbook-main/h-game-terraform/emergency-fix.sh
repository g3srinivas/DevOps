#!/bin/bash
# Emergency Fix Script - Run this to resolve the CI/CD failures immediately

set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║   Terraform CI/CD Emergency Fix                               ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Check if we're in the right directory
if [ ! -f "backend.tf" ]; then
    echo "❌ Error: backend.tf not found. Please run this from h-game-terraform directory."
    echo "   cd h-game-terraform"
    echo "   ./emergency-fix.sh"
    exit 1
fi

echo "This script will:"
echo "  1. Remove conflicting resources from state"
echo "  2. Let imports.tf re-import them properly"
echo "  3. Run terraform plan to verify"
echo ""
read -p "Continue? (y/n) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 1
fi

echo ""
echo "📋 Step 1: Initializing Terraform..."
terraform init

echo ""
echo "🗑️  Step 2: Removing conflicting resources from state..."
echo "   (These will be re-imported automatically)"

# Remove CloudWatch log group if it exists in state
terraform state rm aws_cloudwatch_log_group.eks_cluster 2>/dev/null && \
    echo "   ✓ Removed CloudWatch log group from state" || \
    echo "   ⊘ CloudWatch log group not in state (OK)"

# Remove ECR repositories if they exist in state
terraform state rm aws_ecr_repository.backend 2>/dev/null && \
    echo "   ✓ Removed backend ECR repository from state" || \
    echo "   ⊘ Backend ECR repository not in state (OK)"

terraform state rm aws_ecr_repository.frontend 2>/dev/null && \
    echo "   ✓ Removed frontend ECR repository from state" || \
    echo "   ⊘ Frontend ECR repository not in state (OK)"

# Remove Secrets Manager secrets if they exist in state
terraform state rm aws_secretsmanager_secret.rds_password 2>/dev/null && \
    echo "   ✓ Removed RDS password secret from state" || \
    echo "   ⊘ RDS password secret not in state (OK)"

terraform state rm aws_secretsmanager_secret.api_keys 2>/dev/null && \
    echo "   ✓ Removed API keys secret from state" || \
    echo "   ⊘ API keys secret not in state (OK)"

echo ""
echo "📝 Step 3: Running terraform plan..."
echo "   Terraform will now import the resources automatically..."
echo ""

# Check if terraform.tfvars exists or if we need RDS_PASSWORD from environment
if [ -f "terraform.tfvars" ]; then
    PLAN_CMD="terraform plan -out=tfplan"
elif [ -n "$RDS_PASSWORD" ]; then
    PLAN_CMD="terraform plan -var=\"rds_password=$RDS_PASSWORD\" -out=tfplan"
else
    echo "⚠️  Warning: No terraform.tfvars found and RDS_PASSWORD not set"
    echo "   Plan may fail if rds_password is required"
    PLAN_CMD="terraform plan -out=tfplan"
fi

# Run terraform plan (this will trigger the imports)
if eval "$PLAN_CMD"; then
    echo ""
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║   ✓ SUCCESS - Fix Complete!                                   ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo ""
    echo "What happened:"
    echo "  • Removed conflicting resources from state"
    echo "  • Terraform automatically imported existing AWS resources"
    echo "  • Your state is now synchronized with AWS"
    echo ""
    echo "Next steps:"
    echo "  1. Review the plan above"
    echo "  2. If it looks good, run: terraform apply tfplan"
    echo "  3. Commit and push your changes to trigger CI/CD"
    echo ""
    echo "Your CI/CD should now work! 🎉"
else
    echo ""
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║   ⚠️  Plan Failed - Manual Review Needed                      ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo ""
    echo "The plan failed. This could mean:"
    echo "  • Some resources still have conflicts"
    echo "  • Missing required variables (e.g., rds_password)"
    echo "  • AWS credentials not configured"
    echo ""
    echo "Check the error above and run 'terraform plan' again after fixing."
    exit 1
fi

