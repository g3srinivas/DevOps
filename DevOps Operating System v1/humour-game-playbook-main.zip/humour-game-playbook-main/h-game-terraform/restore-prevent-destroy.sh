#!/bin/bash
# Restore prevent_destroy blocks after destruction

set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║   Restoring prevent_destroy Blocks                            ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

if [ ! -f "cloudwatch.tf.backup" ]; then
    echo "❌ No backup files found. Nothing to restore."
    exit 1
fi

echo "Restoring original files..."
cp cloudwatch.tf.backup cloudwatch.tf
cp ecr.tf.backup ecr.tf
cp secrets-manager.tf.backup secrets-manager.tf

echo "   ✓ Files restored"
echo ""
echo "Cleaning up backups..."
rm -f cloudwatch.tf.backup ecr.tf.backup secrets-manager.tf.backup

echo "   ✓ Backups removed"
echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║   ✓ Restore Complete                                          ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

