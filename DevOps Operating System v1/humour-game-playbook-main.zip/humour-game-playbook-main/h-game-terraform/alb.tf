# ============================================
# APPLICATION LOAD BALANCER (DISABLED - Using Ingress Instead)
# ============================================
# NOTE: We're now using Kubernetes Ingress which automatically creates and manages ALB
# These resources are commented out but kept for reference
# 
# The Ingress controller creates:
# - ALB automatically
# - Target groups automatically  
# - Listener rules automatically
# See: k8s/ingress.yaml

# ============================================
# TARGET GROUP (DISABLED)
# ============================================
# resource "aws_lb_target_group" "backend" {
#   name        = "${local.name_prefix}-backend-tg-ip"
#   port        = var.backend_port
#   protocol    = "HTTP"
#   vpc_id      = aws_vpc.main.id
#   target_type = "ip"
# 
#   health_check {
#     enabled             = true
#     healthy_threshold   = var.alb_health_check_healthy_threshold
#     unhealthy_threshold = var.alb_health_check_unhealthy_threshold
#     timeout             = var.alb_health_check_timeout
#     interval            = var.alb_health_check_interval
#     path                = var.alb_health_check_path
#     protocol            = "HTTP"
#     matcher             = "200"
#   }
# 
#   deregistration_delay = var.alb_deregistration_delay
# 
#   tags = merge(
#     local.common_tags,
#     {
#       Name = "${local.name_prefix}-backend-tg"
#       Task = "T7"
#     }
#   )
# 
#   lifecycle {
#     create_before_destroy = true
#   }
# }

# ============================================
# APPLICATION LOAD BALANCER (DISABLED)
# ============================================
# resource "aws_lb" "main" {
#   name               = var.alb_name
#   internal           = false
#   load_balancer_type = "application"
# 
#   subnets = [
#     aws_subnet.public[0].id,
#     aws_subnet.public[1].id,
#     aws_subnet.public[2].id,
#   ]
# 
#   security_groups = [aws_security_group.alb.id]
#   enable_deletion_protection = var.alb_enable_deletion_protection
#   enable_http2 = true
#   enable_cross_zone_load_balancing = true
# 
#   tags = merge(
#     local.common_tags,
#     {
#       Name = var.alb_name
#       Task = "T7"
#     }
#   )
# }

# ============================================
# ALB LISTENER (DISABLED)
# ============================================
# resource "aws_lb_listener" "http" {
#   load_balancer_arn = aws_lb.main.arn
#   port              = "80"
#   protocol          = "HTTP"
# 
#   default_action {
#     type             = "forward"
#     target_group_arn = aws_lb_target_group.backend.arn
#   }
# 
#   tags = merge(
#     local.common_tags,
#     {
#       Name = "${local.name_prefix}-alb-listener-http"
#       Task = "T7"
#     }
#   )
# }
