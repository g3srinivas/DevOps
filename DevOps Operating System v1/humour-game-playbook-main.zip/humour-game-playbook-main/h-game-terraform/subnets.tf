# ============================================
# SUBNETS
# ============================================
# Network segments within the VPC
# Public subnets: Direct internet access
# Private subnets: No direct internet access

# ============================================
# PUBLIC SUBNETS
# ============================================
# Subnets with direct internet access
# Used for: Load balancers, NAT gateways, bastion hosts

resource "aws_subnet" "public" {
  count = length(var.public_subnet_cidrs)

  vpc_id                  = aws_vpc.main.id
  cidr_block              = var.public_subnet_cidrs[count.index]
  availability_zone       = var.availability_zones[count.index]
  map_public_ip_on_launch = true # Auto-assign public IPs

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-public-subnet-${count.index + 1}"
      Type = "public"
      Task = "T1"
    }
  )
}

# ============================================
# PRIVATE SUBNETS
# ============================================
# Subnets WITHOUT direct internet access
# Used for: Application servers, databases, internal services
# These are truly "private" - no direct internet access

resource "aws_subnet" "private" {
  count = length(var.private_subnet_cidrs)

  vpc_id            = aws_vpc.main.id
  cidr_block        = var.private_subnet_cidrs[count.index]
  availability_zone = var.availability_zones[count.index]
  # map_public_ip_on_launch = false (default) - no public IPs

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-private-subnet-${count.index + 1}"
      Type = "private"
      Task = "T1"
    }
  )
}

# Output: Public subnet IDs
output "public_subnet_ids" {
  description = "IDs of the public subnets"
  value       = aws_subnet.public[*].id
}

# Output: Private subnet IDs
output "private_subnet_ids" {
  description = "IDs of the private subnets"
  value       = aws_subnet.private[*].id
}

