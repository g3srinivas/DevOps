# ============================================
# EKS NODE GROUP
# ============================================
# EC2 instances that run your Pods
# Managed by EKS control plane

resource "aws_eks_node_group" "main" {
  cluster_name    = aws_eks_cluster.main.name  # Which cluster
  node_group_name = var.node_group_name        # Node group name (from variable)
  node_role_arn   = aws_iam_role.eks_nodes.arn # IAM role for nodes
  subnet_ids = [
    aws_subnet.private[0].id, # Private subnet 1
    aws_subnet.private[1].id, # Private subnet 2
    aws_subnet.private[2].id, # Private subnet 3
  ]

  # Instance configuration
  instance_types = [var.eks_node_instance_type] # From variable (default: t3.medium)

  # Scaling configuration
  scaling_config {
    desired_size = var.eks_node_desired_size # From variable
    min_size     = var.eks_node_min_size     # From variable
    max_size     = var.eks_node_max_size     # From variable
  }

  # Update configuration
  update_config {
    max_unavailable = 1 # Update 1 node at a time (zero downtime)
  }

  # Use Spot instances (save 50% cost)
  capacity_type = var.node_capacity_type # From variable (SPOT or ON_DEMAND)

  # Disk size for nodes
  disk_size = 20 # GB - default is 20GB

  timeouts {
    create = "90m" # Increased timeout for node group creation
    update = "90m"
    delete = "30m"
  }

  # ⚠️ Spot Instance Note:
  # Spot instances can be interrupted by AWS with 2-minute warning
  # When interrupted:
  # - Kubernetes detects node is gone
  # - Pods are automatically rescheduled to other nodes
  # - Cluster autoscaler replaces the node if needed
  # - Your application continues running (zero downtime!)
  # 
  # For learning: This is acceptable (saves 50% cost)
  # For production: Consider On-Demand for critical workloads
  #                 Or use Spot with proper PodDisruptionBudgets

  # AMI (Amazon Machine Image) - EKS optimized
  # EKS automatically uses the correct AMI for your Kubernetes version

  # 💡 Internet Access Note:
  # Nodes are in private subnets (from T1) and need internet access to:
  # - Pull container images from ECR (from T8)
  # - Download Kubernetes components
  # - Access AWS APIs
  # 
  # This is handled by NAT Gateway (from T2) which routes private subnet
  # traffic to internet. Nodes automatically use NAT Gateway via private
  # route table configured in T2.

  # Remote access (SSH) - Optional, for debugging
  # remote_access {
  #   ec2_ssh_key = "your-key-pair-name"  # Uncomment if you want SSH access
  # }

  # Labels and taints (for advanced scheduling)
  # We'll keep it simple for now

  # Ensure cluster, IAM roles, and VPC CNI exist first
  # Why: Node group needs cluster, IAM roles, and VPC CNI installed before nodes join
  # VPC CNI must exist so nodes can get pod IPs when they join the cluster
  depends_on = [
    aws_eks_cluster.main,                                         # Cluster must exist first
    aws_iam_role_policy_attachment.eks_worker_node_policy,        # IAM role policies
    aws_iam_role_policy_attachment.eks_cni_policy,                # Network permissions
    aws_iam_role_policy_attachment.eks_container_registry_policy, # ECR access permissions
    aws_eks_addon.vpc_cni,                                        # VPC CNI must be installed before nodes join
  ]

  # Lifecycle to handle updates gracefully
  lifecycle {
    create_before_destroy = true
    ignore_changes = [
      scaling_config[0].desired_size # Allow cluster autoscaler to manage this
    ]
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-eks-nodes"
      Task = "T4"
    }
  )
}

# Output: Node group name
output "eks_node_group_name" {
  description = "Name of the EKS node group"
  value       = aws_eks_node_group.main.node_group_name
}

# Output: Node group status
output "eks_node_group_status" {
  description = "Status of the EKS node group"
  value       = aws_eks_node_group.main.status
}

