# ============================================
# CLUSTER AUTOSCALER IAM POLICY
# ============================================
# IAM policy for EKS Cluster Autoscaler
# Allows autoscaler to manage node groups

resource "aws_iam_policy" "cluster_autoscaler" {
  name        = "${local.name_prefix}-cluster-autoscaler-policy"
  description = "Policy for EKS Cluster Autoscaler to manage node groups"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "autoscaling:DescribeAutoScalingGroups",
          "autoscaling:DescribeAutoScalingInstances",
          "autoscaling:DescribeLaunchConfigurations",
          "autoscaling:DescribeScalingActivities",
          "autoscaling:DescribeTags",
          "ec2:DescribeInstanceTypes",
          "ec2:DescribeLaunchTemplateVersions"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "autoscaling:SetDesiredCapacity",
          "autoscaling:TerminateInstanceInAutoScalingGroup",
          "ec2:DescribeImages",
          "ec2:GetInstanceTypesFromInstanceRequirements",
          "eks:DescribeNodegroup"
        ]
        Resource = "*"
      }
    ]
  })

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-cluster-autoscaler-policy"
      Task = "T9"
    }
  )
}

# Attach policy to EKS node role (from T3)
# Note: For production, use IRSA (IAM Roles for Service Accounts) instead
# This is a simplified approach for learning
resource "aws_iam_role_policy_attachment" "cluster_autoscaler" {
  role       = aws_iam_role.eks_nodes.name # From T3
  policy_arn = aws_iam_policy.cluster_autoscaler.arn

  # Explicit dependencies: Ensure role and policy exist before attachment
  # This prevents race conditions with AWS IAM eventual consistency
  depends_on = [
    aws_iam_role.eks_nodes,
    aws_iam_policy.cluster_autoscaler,
  ]
}

