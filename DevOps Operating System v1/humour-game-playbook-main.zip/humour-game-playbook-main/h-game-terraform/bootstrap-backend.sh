#!/bin/bash
# Bootstrap Script for Terraform Backend
# Creates S3 bucket and DynamoDB table for Terraform state

set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║   Terraform Backend Bootstrap                                   ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Configuration (matches backend.tf)
BUCKET_NAME="h-game-tfstate-playbook-1769734069"
DYNAMODB_TABLE="h-game-terraform-state-lock"
REGION="us-east-1"

# Check AWS CLI
if ! command -v aws &> /dev/null; then
    echo "❌ Error: AWS CLI not found. Please install it first."
    echo "   https://aws.amazon.com/cli/"
    exit 1
fi

# Check AWS credentials
if ! aws sts get-caller-identity &> /dev/null; then
    echo "❌ Error: AWS credentials not configured."
    echo "   Run: aws configure"
    exit 1
fi

echo "📋 Configuration:"
echo "   S3 Bucket:     $BUCKET_NAME"
echo "   DynamoDB Table: $DYNAMODB_TABLE"
echo "   Region:        $REGION"
echo ""

read -p "Continue? (y/n) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 1
fi

echo ""
echo "📦 Step 1: Creating S3 bucket for Terraform state..."

# Check if bucket exists
if aws s3api head-bucket --bucket "$BUCKET_NAME" 2>/dev/null; then
    echo "   ✓ Bucket already exists: $BUCKET_NAME"
else
    # Create bucket
    if [ "$REGION" == "us-east-1" ]; then
        # us-east-1 doesn't need LocationConstraint
        aws s3api create-bucket --bucket "$BUCKET_NAME" --region "$REGION"
    else
        aws s3api create-bucket \
            --bucket "$BUCKET_NAME" \
            --region "$REGION" \
            --create-bucket-configuration LocationConstraint="$REGION"
    fi
    echo "   ✓ Created S3 bucket: $BUCKET_NAME"
fi

# Enable versioning
aws s3api put-bucket-versioning \
    --bucket "$BUCKET_NAME" \
    --versioning-configuration Status=Enabled \
    --region "$REGION" 2>/dev/null || echo "   ⊘ Versioning already enabled"
echo "   ✓ Enabled versioning"

# Enable encryption
aws s3api put-bucket-encryption \
    --bucket "$BUCKET_NAME" \
    --server-side-encryption-configuration '{
        "Rules": [{
            "ApplyServerSideEncryptionByDefault": {
                "SSEAlgorithm": "AES256"
            }
        }]
    }' \
    --region "$REGION" 2>/dev/null || echo "   ⊘ Encryption already configured"
echo "   ✓ Enabled encryption"

# Block public access
aws s3api put-public-access-block \
    --bucket "$BUCKET_NAME" \
    --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true" \
    --region "$REGION" 2>/dev/null || echo "   ⊘ Public access block already configured"
echo "   ✓ Blocked public access"

echo ""
echo "🗄️  Step 2: Creating DynamoDB table for state locking..."

# Check if table exists
if aws dynamodb describe-table --table-name "$DYNAMODB_TABLE" --region "$REGION" 2>/dev/null | grep -q "TableStatus"; then
    echo "   ✓ Table already exists: $DYNAMODB_TABLE"
else
    # Create table
    aws dynamodb create-table \
        --table-name "$DYNAMODB_TABLE" \
        --attribute-definitions AttributeName=LockID,AttributeType=S \
        --key-schema AttributeName=LockID,KeyType=HASH \
        --billing-mode PAY_PER_REQUEST \
        --region "$REGION" \
        --tags Key=Name,Value="Terraform State Lock" Key=ManagedBy,Value="Terraform"
    
    echo "   ✓ Created DynamoDB table: $DYNAMODB_TABLE"
    echo "   ⏳ Waiting for table to be active..."
    
    # Wait for table to be active
    aws dynamodb wait table-exists --table-name "$DYNAMODB_TABLE" --region "$REGION"
    echo "   ✓ Table is active"
fi

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║   ✓ SUCCESS - Backend Ready!                                   ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "  1. Copy terraform.tfvars.example to terraform.tfvars"
echo "  2. Edit terraform.tfvars with your values"
echo "  3. Run: terraform init"
echo "  4. Run: terraform plan"
echo "  5. Run: terraform apply"
echo ""

