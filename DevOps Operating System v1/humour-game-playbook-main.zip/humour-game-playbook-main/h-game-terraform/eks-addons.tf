# ============================================
# EKS ADDONS
# ============================================
# Required addons for EKS cluster functionality
# VPC CNI: Pod networking (REQUIRED - nodes won't become Ready without it)
# CoreDNS: DNS resolution (REQUIRED)
# kube-proxy: Network proxy (REQUIRED)

# ============================================
# VPC CNI ADDON (REQUIRED)
# ============================================
# Provides pod networking - nodes can't become Ready without this
resource "aws_eks_addon" "vpc_cni" {
  cluster_name = aws_eks_cluster.main.name
  addon_name   = "vpc-cni"

  # Use latest compatible version
  addon_version = null # Let EKS choose compatible version

  # Resolve conflicts by overwriting
  resolve_conflicts_on_update = "OVERWRITE"
  resolve_conflicts_on_create = "OVERWRITE"

  # IAM role for VPC CNI (uses node role - simplified for learning)
  # For production, create dedicated service account with IRSA
  service_account_role_arn = null # Uses node role

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-vpc-cni"
      Task = "T3"
    }
  )

  # Dependencies: Only cluster needed - VPC CNI MUST exist before nodes join
  depends_on = [
    aws_eks_cluster.main,
  ]

  # Timeout configuration - VPC CNI usually installs quickly
  timeouts {
    create = "30m"  # 30 minutes should be enough for VPC CNI
    update = "30m"
    delete = "15m"
  }
}

# ============================================
# CoreDNS ADDON (REQUIRED)
# ============================================
# Provides DNS resolution for pods
resource "aws_eks_addon" "coredns" {
  cluster_name = aws_eks_cluster.main.name
  addon_name   = "coredns"

  # Use latest compatible version
  addon_version = null # Let EKS choose compatible version

  # Resolve conflicts by overwriting
  resolve_conflicts_on_update = "OVERWRITE"
  resolve_conflicts_on_create = "OVERWRITE"

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-coredns"
      Task = "T3"
    }
  )

  # Dependencies: Wait for nodes to exist so CoreDNS pods can schedule
  depends_on = [
    aws_eks_cluster.main,
    aws_eks_node_group.main,  # Nodes must exist
    aws_eks_addon.vpc_cni,    # VPC CNI must be installed
  ]

  # Timeout configuration - CoreDNS can take longer, especially if nodes are slow to become Ready
  timeouts {
    create = "40m"  # Increased from default 20m to handle slow node readiness
    update = "30m"
    delete = "15m"
  }
}

# ============================================
# kube-proxy ADDON (REQUIRED)
# ============================================
# Network proxy for service networking
resource "aws_eks_addon" "kube_proxy" {
  cluster_name = aws_eks_cluster.main.name
  addon_name   = "kube-proxy"

  # Use latest compatible version
  addon_version = null # Let EKS choose compatible version

  # Resolve conflicts by overwriting
  resolve_conflicts_on_update = "OVERWRITE"
  resolve_conflicts_on_create = "OVERWRITE"

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-kube-proxy"
      Task = "T3"
    }
  )

  # Dependencies: Wait for nodes to exist so kube-proxy pods can schedule
  depends_on = [
    aws_eks_cluster.main,
    aws_eks_node_group.main,  # Nodes must exist
    aws_eks_addon.vpc_cni,    # VPC CNI must be installed
  ]

  # Timeout configuration - kube-proxy usually installs quickly
  timeouts {
    create = "30m"  # 30 minutes should be enough for kube-proxy
    update = "30m"
    delete = "15m"
  }
}

# Outputs
output "vpc_cni_addon_arn" {
  description = "ARN of VPC CNI addon"
  value       = aws_eks_addon.vpc_cni.arn
}

output "coredns_addon_arn" {
  description = "ARN of CoreDNS addon"
  value       = aws_eks_addon.coredns.arn
}

output "kube_proxy_addon_arn" {
  description = "ARN of kube-proxy addon"
  value       = aws_eks_addon.kube_proxy.arn
}

