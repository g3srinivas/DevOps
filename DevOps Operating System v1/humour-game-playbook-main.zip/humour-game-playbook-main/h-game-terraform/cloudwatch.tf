# ============================================
# CLOUDWATCH MONITORING
# ============================================
# Logs, metrics, and alarms for infrastructure monitoring

# CloudWatch Log Group for EKS
resource "aws_cloudwatch_log_group" "eks_cluster" {
  name              = "/aws/eks/${var.eks_cluster_name}/cluster"
  retention_in_days = 7

  lifecycle {
    prevent_destroy = false # Temporarily disabled for destroy
    ignore_changes  = [retention_in_days]
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-eks-logs"
      Task = "T9"
    }
  )
}

# CloudWatch Log Group for ALB Access Logs
resource "aws_cloudwatch_log_group" "alb_access" {
  name              = "/aws/alb/${var.project_name}/access"
  retention_in_days = 7

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-alb-logs"
      Task = "T9"
    }
  )
}

# CloudWatch Metric Alarm: High CPU Usage
resource "aws_cloudwatch_metric_alarm" "high_cpu" {
  alarm_name          = "${local.name_prefix}-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EKS"
  period              = 300 # 5 minutes
  statistic           = "Average"
  threshold           = 80 # Alert if CPU > 80%
  alarm_description   = "Alert when CPU usage exceeds 80%"

  dimensions = {
    ClusterName = aws_eks_cluster.main.name
  }

  alarm_actions = var.alert_email != "" ? [aws_sns_topic.alerts.arn] : []
  ok_actions    = var.alert_email != "" ? [aws_sns_topic.alerts.arn] : []

  # Explicit dependencies: Ensure EKS cluster and SNS topic exist before creating alarm
  depends_on = [
    aws_eks_cluster.main,
    aws_sns_topic.alerts,
  ]

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-cpu-alarm"
      Task = "T9"
    }
  )
}

# CloudWatch Metric Alarm: High Memory Usage
resource "aws_cloudwatch_metric_alarm" "high_memory" {
  alarm_name          = "${local.name_prefix}-high-memory"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "MemoryUtilization"
  namespace           = "AWS/EKS"
  period              = 300
  statistic           = "Average"
  threshold           = 80
  alarm_description   = "Alert when memory usage exceeds 80%"

  dimensions = {
    ClusterName = aws_eks_cluster.main.name
  }

  alarm_actions = var.alert_email != "" ? [aws_sns_topic.alerts.arn] : []
  ok_actions    = var.alert_email != "" ? [aws_sns_topic.alerts.arn] : []

  # Explicit dependencies: Ensure EKS cluster and SNS topic exist before creating alarm
  depends_on = [
    aws_eks_cluster.main,
    aws_sns_topic.alerts,
  ]

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-memory-alarm"
      Task = "T9"
    }
  )
}

