# ============================================
# AWS CERTIFICATE MANAGER (ACM) - OPTIONAL
# ============================================
# Free SSL/TLS certificates for HTTPS
# Must be in us-east-1 for ALB (AWS requirement)
#
# ⚠️ PREREQUISITES:
# - Domain name configured in Route53 (route53.tf)
# - Route53 hosted zone must exist
# - Ingress-managed ALB must exist
#
# 📝 NOTE: If you don't have a domain, skip this file.
#    You can use HTTP for learning/testing.

# ============================================
# VARIABLES (Add to variables.tf if not exists)
# ============================================
# These should be in variables.tf, but shown here for reference:
#
# variable "certificate_domain" {
#   description = "Domain for ACM certificate (can be wildcard, e.g., *.yourdomain.com)"
#   type        = string
#   default     = ""  # Empty = skip ACM setup
# }

# ============================================
# SSL CERTIFICATE
# ============================================
# Request SSL certificate from ACM
# Must be in us-east-1 for ALB (AWS requirement)
resource "aws_acm_certificate" "main" {
  count = var.certificate_domain != "" ? 1 : 0 # Only create if certificate domain provided

  domain_name       = var.certificate_domain # e.g., *.yourdomain.com or game.yourdomain.com
  validation_method = "DNS"                  # DNS validation (recommended)

  # Subject Alternative Names (optional - for multiple domains)
  # subject_alternative_names = ["www.yourdomain.com"]

  # Wait for validation (certificate must be validated before use)
  lifecycle {
    create_before_destroy = true
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-ssl-cert"
      Task = "T7"
    }
  )

  # Must be in us-east-1 for ALB
  provider = aws.us_east_1 # Ensure this provider is configured
}

# ============================================
# ROUTE53 RECORDS FOR CERTIFICATE VALIDATION
# ============================================
# ACM needs DNS records to validate certificate ownership
# These records are automatically created in Route53
resource "aws_route53_record" "cert_validation" {
  for_each = var.certificate_domain != "" && var.domain_name != "" ? {
    for dvo in aws_acm_certificate.main[0].domain_validation_options : dvo.domain_name => {
      name   = dvo.resource_record_name
      record = dvo.resource_record_value
      type   = dvo.resource_record_type
    }
  } : {}

  allow_overwrite = true
  name            = each.value.name
  records         = [each.value.record]
  ttl             = 60
  type            = each.value.type
  zone_id         = aws_route53_zone.main[0].zone_id # Route53 zone must exist
}

# ============================================
# CERTIFICATE VALIDATION
# ============================================
# Waits for certificate to be validated via DNS records
resource "aws_acm_certificate_validation" "main" {
  count = var.certificate_domain != "" ? 1 : 0 # Only create if certificate domain provided

  certificate_arn = aws_acm_certificate.main[0].arn

  # DNS validation records (automatically created above)
  validation_record_fqdns = [for record in aws_route53_record.cert_validation : record.fqdn]

  # Wait for validation (may take 5-10 minutes)
  timeouts {
    create = "10m" # Allow up to 10 minutes for validation
  }

  provider = aws.us_east_1 # Must match certificate provider
}

# ============================================
# OUTPUTS
# ============================================

# Output: Certificate ARN (needed for Ingress HTTPS annotation)
output "certificate_arn" {
  description = "ARN of the SSL certificate (use this in Ingress annotations)"
  value       = var.certificate_domain != "" ? try(aws_acm_certificate_validation.main[0].certificate_arn, "Certificate not validated yet") : null
}

# Output: Certificate status
output "certificate_status" {
  description = "Status of SSL certificate"
  value       = var.certificate_domain != "" ? try(aws_acm_certificate.main[0].status, "Not created") : null
}

