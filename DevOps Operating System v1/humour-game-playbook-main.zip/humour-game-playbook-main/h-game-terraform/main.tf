# Main Terraform configuration
# Infrastructure resources are organized in separate files

