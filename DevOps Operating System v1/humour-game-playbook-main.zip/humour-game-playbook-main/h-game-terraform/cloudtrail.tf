# ============================================
# CLOUDTRAIL (AUDIT LOGGING)
# ============================================
# Logs all AWS API calls for security auditing
# Required for compliance and security investigations

# Data sources (required for S3 bucket naming)
# Note: aws_caller_identity.current is already defined in iam.tf
# Using var.aws_region instead of data source

# S3 bucket for CloudTrail logs
# Note: Using account ID ensures unique bucket name
resource "aws_s3_bucket" "cloudtrail_logs" {
  bucket = "${local.name_prefix}-cloudtrail-logs-${data.aws_caller_identity.current.account_id}" # aws_caller_identity defined in iam.tf

  # Lifecycle rule: Prevent accidental deletion of audit logs
  # lifecycle {
  #   prevent_destroy = true  # Critical: Audit logs must never be deleted
  # }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-cloudtrail-logs"
      Task = "T9"
    }
  )
}

# S3 bucket versioning (for audit trail)
resource "aws_s3_bucket_versioning" "cloudtrail_logs" {
  bucket = aws_s3_bucket.cloudtrail_logs.id

  versioning_configuration {
    status = "Enabled"
  }
}

# S3 bucket encryption
resource "aws_s3_bucket_server_side_encryption_configuration" "cloudtrail_logs" {
  bucket = aws_s3_bucket.cloudtrail_logs.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# S3 bucket policy for CloudTrail
resource "aws_s3_bucket_policy" "cloudtrail_logs" {
  bucket = aws_s3_bucket.cloudtrail_logs.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AWSCloudTrailAclCheck"
        Effect = "Allow"
        Principal = {
          Service = "cloudtrail.amazonaws.com"
        }
        Action   = "s3:GetBucketAcl"
        Resource = aws_s3_bucket.cloudtrail_logs.arn
      },
      {
        Sid    = "AWSCloudTrailWrite"
        Effect = "Allow"
        Principal = {
          Service = "cloudtrail.amazonaws.com"
        }
        Action   = "s3:PutObject"
        Resource = "${aws_s3_bucket.cloudtrail_logs.arn}/*"
        Condition = {
          StringEquals = {
            "s3:x-amz-acl" = "bucket-owner-full-control"
          }
        }
      }
    ]
  })
}

# CloudTrail trail
resource "aws_cloudtrail" "main" {
  name           = "${local.name_prefix}-cloudtrail"
  s3_bucket_name = aws_s3_bucket.cloudtrail_logs.id

  # Log all API calls
  include_global_service_events = true # Log all AWS services

  # Enable log file validation (detects tampering)
  enable_log_file_validation = true

  # Enable log file integrity validation
  enable_logging = true

  # Event selector (log all events)
  event_selector {
    read_write_type                  = "All"
    include_management_events        = true
    exclude_management_event_sources = []
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-cloudtrail"
      Task = "T9"
    }
  )

  depends_on = [aws_s3_bucket_policy.cloudtrail_logs]
}

# Output: CloudTrail ARN
output "cloudtrail_arn" {
  description = "ARN of the CloudTrail trail"
  value       = aws_cloudtrail.main.arn
}

