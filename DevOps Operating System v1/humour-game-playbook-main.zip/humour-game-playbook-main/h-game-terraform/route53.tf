# ============================================
# ROUTE53 DNS (OPTIONAL - Requires Domain Name)
# ============================================
# Maps custom domain to Ingress-managed ALB
# Example: game.yourdomain.com → ALB DNS
#
# ⚠️ PREREQUISITES:
# - Domain name registered (e.g., yourdomain.com)
# - Domain registrar access (to update nameservers)
# - Ingress-managed ALB must exist first (run Ingress setup first)
#
# 📝 NOTE: If you don't have a domain, skip this file.
#    You can use the ALB DNS name for learning/testing.

# ============================================
# VARIABLES (Add to variables.tf if not exists)
# ============================================
# These should be in variables.tf, but shown here for reference:
#
# variable "domain_name" {
#   description = "Domain name for the application (e.g., yourdomain.com)"
#   type        = string
#   default     = ""  # Empty = skip Route53 setup
# }
#
# variable "app_subdomain" {
#   description = "Subdomain for the application (e.g., game for game.yourdomain.com)"
#   type        = string
#   default     = "game"
# }

# ============================================
# HOSTED ZONE (DNS Zone for Your Domain)
# ============================================
# Only create if domain_name is provided
resource "aws_route53_zone" "main" {
  count = var.domain_name != "" ? 1 : 0 # Only create if domain provided

  name = var.domain_name

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-route53-zone"
      Task = "T7"
    }
  )
}

# ============================================
# DATA SOURCE: Find Ingress-Managed ALB
# ============================================
# Since ALB is created by Ingress (not Terraform), we find it by name
# The Ingress controller creates ALB with name from annotation:
# alb.ingress.kubernetes.io/load-balancer-name: h-game-alb-ingress
data "aws_lb" "ingress_managed" {
  count = var.domain_name != "" ? 1 : 0 # Only query if domain provided

  name = "h-game-alb-ingress" # Must match Ingress annotation

  depends_on = [
    # Ensure Ingress has created the ALB
    # This is a soft dependency - ALB may not exist yet
  ]
}

# ============================================
# A RECORD: Maps Subdomain to ALB
# ============================================
# Creates DNS record: game.yourdomain.com → ALB DNS
resource "aws_route53_record" "alb" {
  count = var.domain_name != "" ? 1 : 0 # Only create if domain provided

  zone_id = aws_route53_zone.main[0].zone_id
  name    = "${var.app_subdomain}.${var.domain_name}" # e.g., game.yourdomain.com
  type    = "A"

  # Alias record pointing to Ingress-managed ALB
  alias {
    name                   = data.aws_lb.ingress_managed[0].dns_name
    zone_id                = data.aws_lb.ingress_managed[0].zone_id
    evaluate_target_health = true # Health check enabled
  }

  # Note: aws_route53_record doesn't support tags
}

# ============================================
# OUTPUTS
# ============================================

# Output: Nameservers (update your domain registrar with these)
output "route53_nameservers" {
  description = "Nameservers for your domain (update your registrar)"
  value       = var.domain_name != "" ? aws_route53_zone.main[0].name_servers : []

  # Only output if Route53 zone was created
  depends_on = [aws_route53_zone.main]
}

# Output: Custom domain URL
output "custom_domain_url" {
  description = "Custom domain URL for your application"
  value       = var.domain_name != "" ? "http://${var.app_subdomain}.${var.domain_name}" : null
}

# Output: ALB DNS (for reference)
output "ingress_alb_dns" {
  description = "DNS name of Ingress-managed ALB"
  value       = var.domain_name != "" ? try(data.aws_lb.ingress_managed[0].dns_name, "ALB not found - ensure Ingress is applied first") : null
}

