# ============================================
# RDS POSTGRESQL (Managed Database)
# ============================================
# AWS managed PostgreSQL
# Replaces: PostgreSQL StatefulSet (from K2)

# ============================================
# DB SUBNET GROUP
# ============================================
# Tells RDS which subnets to use
# RDS needs subnets in multiple AZs

resource "aws_db_subnet_group" "main" {
  name = "${local.name_prefix}-db-subnet-group"
  subnet_ids = [
    aws_subnet.private[0].id, # Private subnet 1 (us-east-1a)
    aws_subnet.private[1].id, # Private subnet 2 (us-east-1b)
    aws_subnet.private[2].id, # Private subnet 3 (us-east-1c)
  ]

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-db-subnet-group"
      Task = "T5"
    }
  )
}

# Output: Subnet group name
output "db_subnet_group_name" {
  description = "Name of the DB subnet group"
  value       = aws_db_subnet_group.main.name
}

# ============================================
# DB PARAMETER GROUP
# ============================================
# Custom database configuration
# Allows you to tune PostgreSQL settings

resource "aws_db_parameter_group" "postgres" {
  family = "postgres15" # PostgreSQL 15 family
  name   = "${local.name_prefix}-postgres-params"

  # Example parameters (optional - defaults work fine)
  # parameter {
  #   name  = "max_connections"
  #   value = "100"
  # }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-postgres-params"
      Task = "T5"
    }
  )
}

# ============================================
# RDS POSTGRESQL INSTANCE
# ============================================
# Managed PostgreSQL database
# AWS handles: Backups, updates, monitoring

resource "aws_db_instance" "postgres" {
  # Basic configuration
  identifier     = var.rds_db_identifier  # Database identifier (from variable)
  engine         = "postgres"             # Database engine
  engine_version = "15.15"                # PostgreSQL version (latest 15.x available on RDS)
  instance_class = var.rds_instance_class # Instance size (from variable)

  # Storage configuration
  allocated_storage     = 20    # Initial storage (GB)
  max_allocated_storage = 100   # Auto-scaling max (GB)
  storage_type          = "gp3" # Storage type (General Purpose SSD)
  storage_encrypted     = true  # Encrypt storage at rest

  # Database configuration
  db_name  = var.rds_db_name  # Database name (from variable)
  username = var.rds_username # Master username (from variable)
  password = var.rds_password # Master password (from variable - set in terraform.tfvars)
  port     = var.rds_port     # PostgreSQL port (from variable)
  # ⚠️ Password is stored in terraform.tfvars (not committed to Git)
  # ⚠️ In production, use AWS Secrets Manager (we'll cover in DevSecOps)

  # ============================================
  # LIFECYCLE RULES
  # ============================================
  lifecycle {
    # Prevent accidental deletion
    prevent_destroy = false # Set to true for production (prevents accidental deletion)
    # To delete: Remove this line, then destroy

    # Ignore password changes (don't update DB on every apply)
    ignore_changes = [
      password, # Don't update password on every apply (only when explicitly changed)
    ]

    # Note: create_before_destroy cannot be used with RDS
  }

  # Lifecycle Rules Explained:
  # - prevent_destroy = false: Currently false for learning (can destroy easily)
  #   Production: Set to true to prevent accidental deletion
  #   To delete: Remove this line, then destroy
  # - ignore_changes = [password]: Don't update database password on every apply
  #   Prevents unnecessary downtime
  #   Change password manually if needed

  # Network configuration
  db_subnet_group_name   = aws_db_subnet_group.main.name    # Which subnets to use
  vpc_security_group_ids = [aws_security_group.database.id] # Security group (only backend can access)
  publicly_accessible    = false                            # No public access (private subnet)

  # Parameter group
  parameter_group_name = aws_db_parameter_group.postgres.name

  # Backup configuration
  backup_retention_period = 7                     # Keep backups for 7 days (free)
  backup_window           = "03:00-04:00"         # Backup window (UTC)
  maintenance_window      = "mon:04:00-mon:05:00" # Maintenance window (UTC)

  # CloudWatch Logs (for monitoring and troubleshooting)
  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]
  # Exports PostgreSQL logs to CloudWatch
  # - postgresql: General PostgreSQL logs
  # - upgrade: Database upgrade logs
  # Note: CloudWatch Logs has a small cost (~$0.50/GB ingested), but useful for debugging

  # Multi-AZ (for high availability)
  # Skip for learning (saves $15/month)
  # multi_az = true  # Uncomment for production

  # Deletion protection (prevent accidental deletion)
  deletion_protection = false # Set to true for production

  # Skip final snapshot for learning (saves time on destroy)
  skip_final_snapshot = true # Set to false for production

  # Tags
  tags = merge(
    local.common_tags,
    {
      Name = var.rds_db_identifier
      Task = "T5"
    }
  )

  # Ensure subnet group and security group exist first
  depends_on = [
    aws_db_subnet_group.main,
    aws_db_parameter_group.postgres,
    aws_security_group.database,
  ]

  # Timeout configuration - RDS instance creation typically takes 10-20 minutes
  timeouts {
    create = "30m"  # 30 minutes should be enough for RDS creation
    update = "60m"  # Updates can take longer (instance class changes, etc.)
    delete = "30m"  # Deletion includes final snapshot
  }
}

# Output: RDS endpoint (connection string)
output "rds_endpoint" {
  description = "RDS instance endpoint"
  value       = aws_db_instance.postgres.endpoint
}

# Output: RDS address (hostname for connection)
output "rds_address" {
  description = "RDS instance address"
  value       = aws_db_instance.postgres.address
}

# Output: RDS port
output "rds_port" {
  description = "RDS instance port"
  value       = var.rds_port # From variable
}

