# ============================================
# ROUTE TABLES
# ============================================
# Control where traffic is routed
# Public route table: Routes to Internet Gateway
# Private route tables: Routes to NAT Gateway (when added in T2)

# ============================================
# ROUTE TABLE: PUBLIC SUBNETS
# ============================================
# Routes traffic from public subnets to internet via Internet Gateway

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = var.internet_route_cidr # 0.0.0.0/0 = all internet traffic
    gateway_id = aws_internet_gateway.main.id
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-public-rt"
      Type = "public"
      Task = "T1"
    }
  )
}

# Associate public subnets with public route table
resource "aws_route_table_association" "public" {
  count = length(aws_subnet.public)

  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

# ============================================
# ROUTE TABLE: PRIVATE SUBNETS
# ============================================
# Routes traffic from private subnets (no direct internet access)
# Note: NAT Gateway route will be added in T2

resource "aws_route_table" "private" {
  count = length(aws_subnet.private)

  vpc_id = aws_vpc.main.id

  # Route: Send all internet traffic to NAT Gateway
  # Note: NAT Gateway will be created in T2
  # This route will be added when NAT Gateway exists
  # For now (T1), private subnets have no internet route (truly private)

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-private-rt-${count.index + 1}"
      Type = "private"
      Task = "T1"
    }
  )

  # Route will be added in T2 via separate aws_route resource
  # This keeps T1 and T2 separate and allows incremental updates
}

# ============================================
# NAT GATEWAY ROUTE FOR PRIVATE SUBNETS
# ============================================
# Adds NAT Gateway route to existing private route tables
# This updates the route tables created in T1

resource "aws_route" "private_nat" {
  count = var.enable_nat_gateway ? length(aws_route_table.private) : 0

  route_table_id         = aws_route_table.private[count.index].id
  destination_cidr_block = var.internet_route_cidr
  nat_gateway_id         = aws_nat_gateway.main.id

  depends_on = [aws_nat_gateway.main]
}

# Associate private subnets with private route tables
resource "aws_route_table_association" "private" {
  count = length(aws_subnet.private)

  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private[count.index].id
}

