# ============================================
# TERRAFORM IMPORT BLOCKS
# ============================================
# Automatically import existing AWS resources into Terraform state
# This replaces unreliable shell commands in CI/CD workflows
#
# How it works:
# 1. Terraform reads these blocks during `terraform plan`
# 2. If resource exists in AWS but not in state, it imports automatically
# 3. No shell hacks, no silent failures - just works

# CloudWatch log group - commented out (destroyed)
# Uncomment if you need to import existing log group
# import {
#   to = aws_cloudwatch_log_group.eks_cluster
#   id = "/aws/eks/h-game-prod/cluster"
# }

# ECR repositories - commented out (destroyed)
# Uncomment if you need to import existing repositories
# import {
#   to = aws_ecr_repository.backend
#   id = "h-game-backend"
# }
# 
# import {
#   to = aws_ecr_repository.frontend
#   id = "h-game-frontend"
# }

# Secrets Manager imports - using ARN format
# Note: ARNs have random suffixes. Only uncomment if secrets actually exist in AWS.
# To check: aws secretsmanager list-secrets --query "SecretList[?contains(Name, 'h-game')]"
# 
# Currently commented out - secrets don't exist, Terraform will create them automatically via secrets-manager.tf
# Uncomment and update ARNs ONLY if secrets already exist in AWS and you want to import them:
# import {
#   to = aws_secretsmanager_secret.rds_password
#   id = "arn:aws:secretsmanager:us-east-1:334091769766:secret:h-game/rds/password-XXXXX"
# }
# 
# import {
#   to = aws_secretsmanager_secret.api_keys
#   id = "arn:aws:secretsmanager:us-east-1:334091769766:secret:h-game/api/keys-XXXXX"
# }

