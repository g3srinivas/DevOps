# Terraform Infrastructure for H-Game

This directory contains Terraform configuration for deploying the H-Game infrastructure on AWS, including:
- VPC with public/private subnets
- EKS (Kubernetes) cluster
- RDS PostgreSQL database
- ElastiCache Redis
- ECR container registries
- Application Load Balancer (via Kubernetes Ingress)
- CloudWatch monitoring and alerts
- Secrets Manager for credentials
- And more...

## Prerequisites

Before running Terraform, ensure you have:

1. **AWS CLI configured** with appropriate credentials
   ```bash
   aws configure
   ```

2. **Terraform installed** (version >= 1.0)
   ```bash
   terraform version
   ```

3. **AWS Permissions** - Your AWS credentials need permissions for:
   - VPC, EC2, EKS, RDS, ElastiCache, ALB, ECR
   - IAM (to create roles and policies)
   - S3, DynamoDB (for Terraform state backend)
   - CloudWatch, CloudTrail, Secrets Manager
   - Route53, ACM (if using custom domain)

4. **Backend Resources** - S3 bucket and DynamoDB table for Terraform state
   - See [Backend Setup](#backend-setup) below

## Quick Start

### 1. Backend Setup (One-Time)

Terraform state is stored in S3 with DynamoDB locking. These must exist before running Terraform:

**Option A: Manual Creation**

```bash
# Create S3 bucket for state
aws s3 mb s3://h-game-tfstate-playbook-1769734069 --region us-east-1

# Enable versioning
aws s3api put-bucket-versioning \
  --bucket h-game-tfstate-playbook-1769734069 \
  --versioning-configuration Status=Enabled

# Create DynamoDB table for state locking
aws dynamodb create-table \
  --table-name h-game-terraform-state-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region us-east-1
```

**Option B: Use Bootstrap Script**

```bash
./bootstrap-backend.sh
```

### 2. Configure Variables

```bash
# Copy example file
cp terraform.tfvars.example terraform.tfvars

# Edit with your values
# ⚠️ IMPORTANT: Set a secure RDS password!
# Password must be at least 16 characters with uppercase, lowercase, and numbers
nano terraform.tfvars  # or use your preferred editor
```

### 3. Initialize Terraform

```bash
terraform init
```

### 4. Plan Changes

```bash
terraform plan
```

### 5. Apply Changes

```bash
terraform apply
```

**Note:** This will create a lot of resources. First apply may take 15-30 minutes.

## Important Notes

### RDS Password Requirements

The RDS password in `terraform.tfvars` must meet these requirements:
- At least 16 characters
- At least one uppercase letter (A-Z)
- At least one lowercase letter (a-z)
- At least one number (0-9)

Example: `MySecurePassword123456`

### Two-Step Apply for Secrets

If you're creating RDS for the first time:
1. First apply creates RDS (but secret has empty host)
2. Second apply updates secret with RDS endpoint

This is normal and expected. The secret will be updated automatically.

### State Management

- **State is stored in S3** - Never delete the S3 bucket!
- **State locking uses DynamoDB** - Prevents concurrent modifications
- **State contains sensitive data** - Even though encrypted, be careful with backups

### Parallelism

Terraform is configured to reduce parallelism to avoid AWS API rate limiting. If you still encounter throttling:

```bash
terraform apply -parallelism=3
```

### Common Issues

#### "Resource Already Exists" Error

This usually means:
1. State is out of sync with AWS
2. Resource was created manually or by another process
3. Previous apply was interrupted

**Fix:**
```bash
# Check if resource exists in AWS
aws <service> describe-<resource> --name <name>

# If it exists, import it:
terraform import <resource_type>.<name> <resource_id>

# Or remove from state if you want Terraform to recreate it:
terraform state rm <resource_type>.<name>
```

#### "Security Group Not Found" Error

This can happen if EKS cluster security groups aren't ready yet. The fixes in this repo add explicit dependencies to prevent this.

**Fix:** Run `terraform apply` again. The dependencies ensure proper ordering.

#### IAM Permission Errors

Ensure your AWS credentials have sufficient permissions. See [Prerequisites](#prerequisites) above.

## File Structure

- `main.tf` - Basic S3 bucket (learning resource)
- `vpc.tf` - VPC and Internet Gateway
- `subnets.tf` - Public and private subnets
- `route-tables.tf` - Route tables and associations
- `nat-gateway.tf` - NAT Gateway for private subnet internet access
- `security-groups.tf` - Security groups for all resources
- `eks-cluster.tf` - EKS Kubernetes cluster
- `eks-nodes.tf` - EKS worker node group
- `rds.tf` - RDS PostgreSQL database
- `elasticache.tf` - ElastiCache Redis
- `ecr.tf` - ECR container registries
- `alb.tf` - Application Load Balancer (disabled - using Ingress)
- `secrets-manager.tf` - AWS Secrets Manager for credentials
- `cloudwatch.tf` - CloudWatch logs and alarms
- `sns-alerts.tf` - SNS topic for email alerts
- `iam.tf` - IAM roles and policies
- `provider.tf` - Terraform and provider configuration
- `backend.tf` - Remote state backend configuration
- `variables.tf` - Variable definitions
- `locals.tf` - Local values
- `terraform.tfvars` - Your actual values (gitignored)
- `terraform.tfvars.example` - Example values (safe to commit)

## Destroying Infrastructure

⚠️ **Warning:** This will delete ALL resources, including databases!

```bash
terraform destroy
```

**Note:** Some resources have `prevent_destroy = false` for learning purposes. In production, set this to `true` for critical resources.

## CI/CD Integration

This Terraform configuration is designed to work with GitHub Actions. See `.github/workflows/terraform.yml` for the CI/CD pipeline.

The pipeline:
1. Validates Terraform syntax
2. Runs security scanning (Checkov)
3. Plans changes on pull requests
4. Applies changes on merge to main

## Troubleshooting

### State Lock Issues

If Terraform is stuck with a lock:

```bash
# Check who has the lock
aws dynamodb get-item \
  --table-name h-game-terraform-state-lock \
  --key '{"LockID":{"S":"<lock-id>"}}'

# Force unlock (use with caution!)
terraform force-unlock <lock-id>
```

### State Out of Sync

If state doesn't match AWS:

```bash
# Refresh state
terraform refresh

# Or import missing resources
terraform import <resource_type>.<name> <resource_id>
```

## Additional Resources

- [Terraform AWS Provider Documentation](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)
- [EKS Best Practices](https://aws.github.io/aws-eks-best-practices/)
- [Terraform State Management](https://www.terraform.io/docs/language/state/index.html)

## Support

For issues or questions:
1. Check [TERRAFORM_FIXES.md](./TERRAFORM_FIXES.md) for known issues and fixes
2. Check [RECREATION_ISSUES_ANALYSIS.md](./RECREATION_ISSUES_ANALYSIS.md) for setup issues
3. Review Terraform logs: `terraform apply -debug`

