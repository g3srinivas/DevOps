# ============================================
# VPC (Virtual Private Cloud)
# ============================================
# Your private network in AWS
# Like your home network (192.168.x.x) but in the cloud

resource "aws_vpc" "main" {
  # CIDR block: IP address range for your network
  # Uses variable instead of hardcoded value
  cidr_block = var.vpc_cidr

  # Enable DNS hostnames (required for EKS)
  # Allows resources to have DNS names like: ip-10-0-1-5.ec2.internal
  enable_dns_hostnames = true

  # Enable DNS resolution (required for EKS)
  # Allows resources to resolve DNS names
  enable_dns_support = true

  # Tags: Labels for organization (uses locals for common tags)
  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-vpc"
      Task = "T1"
    }
  )
}

# Output: VPC ID (needed for other resources)
output "vpc_id" {
  description = "ID of the VPC"
  value       = aws_vpc.main.id
}

# Output: Internet Gateway ID
output "internet_gateway_id" {
  description = "ID of the Internet Gateway"
  value       = aws_internet_gateway.main.id
}

# ============================================
# INTERNET GATEWAY
# ============================================
# Allows resources in public subnets to access the internet
# Think of it as the "front door" to the internet

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-igw"
      Task = "T1"
    }
  )
}

# Output: VPC CIDR block (for reference)
output "vpc_cidr" {
  description = "CIDR block of the VPC"
  value       = aws_vpc.main.cidr_block
}

