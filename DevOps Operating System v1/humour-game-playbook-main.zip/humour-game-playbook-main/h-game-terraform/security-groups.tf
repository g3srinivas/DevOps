# ============================================
# SECURITY GROUPS
# ============================================
# Firewall rules that control traffic
# Default: Deny all (nothing gets through)
# Rules: Allow specific traffic only

# ============================================
# ALB (Application Load Balancer) Security Group
# ============================================
# Allows internet traffic to reach Load Balancer
resource "aws_security_group" "alb" {
  name        = "${local.name_prefix}-alb-sg"
  description = "Security group for Application Load Balancer"
  vpc_id      = aws_vpc.main.id

  # Ingress Rule: Allow HTTP from internet
  ingress {
    description = "HTTP from internet"
    from_port   = var.http_port # HTTP port (from variable)
    to_port     = var.http_port
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"] # From anywhere (internet)
  }

  # Ingress Rule: Allow HTTPS from internet
  ingress {
    description = "HTTPS from internet"
    from_port   = var.https_port # HTTPS port (from variable)
    to_port     = var.https_port
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"] # From anywhere (internet)
  }

  # Egress: Allow all (ALB needs to forward to backend)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1" # All protocols
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-alb-sg"
      Task = "T2"
    }
  )
}

# ============================================
# Backend Security Group (Legacy - kept for compatibility)
# ============================================
# Allows ALB to reach backend, backend to reach database/cache
resource "aws_security_group" "backend" {
  name        = "${local.name_prefix}-backend-sg"
  description = "Security group for backend Pods"
  vpc_id      = aws_vpc.main.id

  # Ingress Rule: Allow HTTP from ALB only
  ingress {
    description     = "HTTP from ALB"
    from_port       = var.backend_port # Backend port (from variable)
    to_port         = var.backend_port
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id] # Only from ALB!
  }

  # Egress: Allow all (backend needs to reach database, cache, internet)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-backend-sg"
      Task = "T2"
    }
  )
}

# ============================================
# Backend Pod Security Group (for IP target type)
# ============================================
# Security group specifically for backend pods with pod ENIs
# Allows ALB to reach pods directly on port 3001
resource "aws_security_group" "backend_pods" {
  name_prefix = "${local.name_prefix}-backend-pods-"
  description = "Security group for H-Game backend pods (pod ENI)"
  vpc_id      = aws_vpc.main.id

  # Ingress: Allow ALB to reach backend pods
  ingress {
    description     = "HTTP from ALB to backend pods"
    from_port       = var.backend_port # 3001
    to_port         = var.backend_port
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
  }

  # Egress: Allow all outbound (pods need to reach RDS, etc.)
  egress {
    description = "Allow all outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-backend-pods-sg"
      Task = "T7"
    }
  )
}

# ============================================
# Database Security Group
# ============================================
# Allows backend to reach database, nothing else
resource "aws_security_group" "database" {
  name        = "${local.name_prefix}-database-sg"
  description = "Security group for RDS PostgreSQL"
  vpc_id      = aws_vpc.main.id

  # Ingress Rule: Allow PostgreSQL from backend Pods
  ingress {
    description     = "PostgreSQL from backend"
    from_port       = var.postgres_port # PostgreSQL port (from variable)
    to_port         = var.postgres_port
    protocol        = "tcp"
    security_groups = [aws_security_group.backend.id] # Backend Pods
  }

  # Ingress Rule: Allow PostgreSQL from EKS cluster security group
  # Note: EKS automatically creates a security group for the cluster
  # This allows Pods running on EKS nodes to access RDS
  ingress {
    description     = "PostgreSQL from EKS cluster"
    from_port       = var.postgres_port # PostgreSQL port (from variable)
    to_port         = var.postgres_port
    protocol        = "tcp"
    security_groups = [aws_eks_cluster.main.vpc_config[0].cluster_security_group_id] # EKS cluster security group
  }

  # Ingress Rule: Allow PostgreSQL from EKS nodes security group (for compatibility)
  ingress {
    description     = "PostgreSQL from EKS nodes"
    from_port       = var.postgres_port # PostgreSQL port (from variable)
    to_port         = var.postgres_port
    protocol        = "tcp"
    security_groups = [aws_security_group.eks_nodes.id] # EKS worker nodes security group
  }

  # Egress: Allow all (database needs to respond)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-database-sg"
      Task = "T2"
    }
  )

  # Explicit dependency: EKS cluster must exist before we can reference its security group
  # This prevents race conditions where security group is created before EKS cluster
  depends_on = [
    aws_eks_cluster.main, # EKS cluster must exist first
  ]
}

# ============================================
# Cache Security Group
# ============================================
# Allows backend to reach cache, nothing else
resource "aws_security_group" "cache" {
  name        = "${local.name_prefix}-cache-sg"
  description = "Security group for ElastiCache Redis"
  vpc_id      = aws_vpc.main.id

  # Ingress Rule: Allow Redis from backend Pods
  ingress {
    description     = "Redis from backend"
    from_port       = var.redis_port # Redis port (from variable)
    to_port         = var.redis_port
    protocol        = "tcp"
    security_groups = [aws_security_group.backend.id] # Backend Pods
  }

  # Ingress Rule: Allow Redis from EKS cluster security group
  # Note: EKS automatically creates a security group for the cluster
  # This allows Pods running on EKS nodes to access ElastiCache
  ingress {
    description     = "Redis from EKS cluster"
    from_port       = var.redis_port # Redis port (from variable)
    to_port         = var.redis_port
    protocol        = "tcp"
    security_groups = [aws_eks_cluster.main.vpc_config[0].cluster_security_group_id] # EKS cluster security group
  }

  # Ingress Rule: Allow Redis from EKS nodes security group (for compatibility)
  ingress {
    description     = "Redis from EKS nodes"
    from_port       = var.redis_port # Redis port (from variable)
    to_port         = var.redis_port
    protocol        = "tcp"
    security_groups = [aws_security_group.eks_nodes.id] # EKS worker nodes security group
  }

  # Egress: Allow all (cache needs to respond)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-cache-sg"
      Task = "T2"
    }
  )

  # Explicit dependency: EKS cluster must exist before we can reference its security group
  # This prevents race conditions where security group is created before EKS cluster
  depends_on = [
    aws_eks_cluster.main, # EKS cluster must exist first
  ]
}

# ============================================
# EKS Cluster Security Group
# ============================================
# Allows cluster communication
resource "aws_security_group" "eks_cluster" {
  name        = "${local.name_prefix}-eks-cluster-sg"
  description = "Security group for EKS cluster"
  vpc_id      = aws_vpc.main.id

  # Ingress: Allow cluster communication (will be configured by EKS)
  # EKS will add its own rules automatically

  # Egress: Allow all (cluster needs to communicate)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-eks-cluster-sg"
      Task = "T2"
    }
  )
}

# ============================================
# EKS Node Group Security Group
# ============================================
# Allows worker nodes to communicate
resource "aws_security_group" "eks_nodes" {
  name        = "${local.name_prefix}-eks-nodes-sg"
  description = "Security group for EKS worker nodes"
  vpc_id      = aws_vpc.main.id

  # Ingress: Allow from cluster and other nodes
  ingress {
    description     = "From cluster"
    from_port       = 1025 # Kubernetes ports
    to_port         = 65535
    protocol        = "tcp"
    security_groups = [aws_security_group.eks_cluster.id]
  }

  ingress {
    description = "From nodes"
    from_port   = 1025
    to_port     = 65535
    protocol    = "tcp"
    self        = true # Allow from other nodes in same group
  }

  # Ingress: Allow ALB to reach pods on backend port (for IP target type)
  ingress {
    description     = "HTTP from ALB to backend pods"
    from_port       = var.backend_port # Backend port (3001)
    to_port         = var.backend_port
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id] # From ALB security group
  }

  # Egress: Allow all (nodes need to pull images, communicate)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-eks-nodes-sg"
      Task = "T2"
    }
  )
}

# ============================================
# EKS-Managed Security Group Rule
# ============================================
# EKS automatically creates a security group for the cluster
# This rule allows ALB to reach backend pods on the EKS-managed security group
# We find it by querying for the security group with the cluster name tag
data "aws_security_group" "eks_cluster_managed" {
  filter {
    name   = "tag:aws:eks:cluster-name"
    values = [aws_eks_cluster.main.name]
  }
  filter {
    name   = "tag:Name"
    values = ["eks-cluster-sg-${aws_eks_cluster.main.name}-*"]
  }
}

# Add ingress rule to the EKS-managed security group for backend (port 3001)
resource "aws_security_group_rule" "alb_to_eks_managed_nodes_backend" {
  description              = "Allow ALB to reach backend pods on EKS-managed node security group"
  type                     = "ingress"
  from_port                = var.backend_port
  to_port                  = var.backend_port
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.alb.id
  security_group_id        = data.aws_security_group.eks_cluster_managed.id

  # Explicit dependencies: EKS cluster and node group must exist before EKS-managed security group is available
  # This prevents "security group not found" errors
  depends_on = [
    aws_eks_cluster.main,
    aws_eks_node_group.main, # Node group creation triggers EKS-managed security group creation
  ]

  lifecycle {
    create_before_destroy = true
  }
}

# Add ingress rule to the EKS-managed security group for frontend (port 80)
resource "aws_security_group_rule" "alb_to_eks_managed_nodes_frontend" {
  description              = "Allow ALB to reach frontend pods on EKS-managed node security group"
  type                     = "ingress"
  from_port                = 80
  to_port                  = 80
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.alb.id
  security_group_id        = data.aws_security_group.eks_cluster_managed.id

  # Explicit dependencies: EKS cluster and node group must exist before EKS-managed security group is available
  # This prevents "security group not found" errors
  depends_on = [
    aws_eks_cluster.main,
    aws_eks_node_group.main, # Node group creation triggers EKS-managed security group creation
  ]

  lifecycle {
    create_before_destroy = true
  }
}

# Outputs: Security Group IDs (needed for other resources)
output "alb_security_group_id" {
  description = "ID of ALB security group"
  value       = aws_security_group.alb.id
}

output "backend_security_group_id" {
  description = "ID of backend security group"
  value       = aws_security_group.backend.id
}

output "backend_pod_security_group_id" {
  description = "Security group ID for backend pods (pod ENI)"
  value       = aws_security_group.backend_pods.id
}

output "database_security_group_id" {
  description = "ID of database security group"
  value       = aws_security_group.database.id
}

output "cache_security_group_id" {
  description = "ID of cache security group"
  value       = aws_security_group.cache.id
}

output "eks_nodes_security_group_id" {
  description = "ID of EKS nodes security group"
  value       = aws_security_group.eks_nodes.id
}

