# ============================================
# EKS CLUSTER
# ============================================
# AWS managed Kubernetes control plane
# AWS runs: API server, etcd, controller manager
# You run: Worker nodes (in T4)

resource "aws_eks_cluster" "main" {
  name     = var.eks_cluster_name         # Cluster name (from variable)
  role_arn = aws_iam_role.eks_cluster.arn # IAM role for cluster
  version  = var.kubernetes_version       # Kubernetes version (from variable)

  # Bootstrap self-managed addons (must match existing cluster)
  bootstrap_self_managed_addons = false

  # VPC Configuration
  vpc_config {
    # Subnets where cluster will create resources
    # Use private subnets (more secure)
    # ✅ FIX: Use count-based subnet references (matches T1 implementation)
    subnet_ids = [
      aws_subnet.private[0].id, # Private subnet 1
      aws_subnet.private[1].id, # Private subnet 2
      aws_subnet.private[2].id, # Private subnet 3
    ]

    # Endpoint access configuration
    endpoint_private_access = true # Allow access from VPC
    endpoint_public_access  = true # Allow access from internet (for kubectl)

    # Security groups for cluster
    # EKS will create additional security groups automatically
    security_group_ids = [aws_security_group.eks_cluster.id]
  }

  # Enable logging (optional but recommended)
  enabled_cluster_log_types = var.enable_cluster_logging ? var.cluster_log_types : [] # From variables

  depends_on = [
    aws_iam_role_policy_attachment.eks_cluster_policy,
    aws_cloudwatch_log_group.eks_cluster,
  ]

  # Timeout configuration - EKS cluster creation typically takes 15-20 minutes
  timeouts {
    create = "30m"  # 30 minutes should be enough for cluster creation
    update = "60m"  # Updates can take longer (version upgrades, etc.)
    delete = "30m"
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-eks-cluster"
      Task = "T3"
    }
  )
}

# Output: Cluster name
output "eks_cluster_name" {
  description = "Name of the EKS cluster"
  value       = aws_eks_cluster.main.name
}

# Output: Cluster endpoint (for kubectl)
output "eks_cluster_endpoint" {
  description = "Endpoint for EKS cluster"
  value       = aws_eks_cluster.main.endpoint
}

# Output: Cluster version
output "eks_cluster_version" {
  description = "Kubernetes version of the cluster"
  value       = aws_eks_cluster.main.version
}

