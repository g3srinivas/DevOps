# ============================================
# AWS SECRETS MANAGER
# ============================================
# Secure credential storage with encryption
# Replaces: Kubernetes Secrets (base64-encoded)
# Better: Encrypted at rest, automatic rotation, IAM integration

# Note: aws_caller_identity.current and aws_region.current are already defined
# in iam.tf and cloudtrail.tf respectively

# RDS Database Password Secret
resource "aws_secretsmanager_secret" "rds_password" {
  name        = "${var.project_name}/rds/password"
  description = "RDS PostgreSQL database password"

  lifecycle {
    prevent_destroy = false # Temporarily disabled for destroy
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-rds-password"
      Task = "T9"
    }
  )
}

# RDS Database Password Secret Version
# ⚠️ Uses existing RDS password from T5 (var.rds_password)
resource "aws_secretsmanager_secret_version" "rds_password" {
  secret_id = aws_secretsmanager_secret.rds_password.id

  # Use existing RDS password from T5 (from terraform.tfvars)
  secret_string = jsonencode({
    username = var.rds_username # From variable (T5)
    password = var.rds_password # From variable (T5) - existing password
    engine   = "postgres"
    host     = try(aws_db_instance.postgres.address, "") # From T5 (will be empty if RDS doesn't exist yet)
    port     = var.postgres_port                         # From variable (T2)
    dbname   = var.rds_db_name                           # From variable (T5)
  })

  # ⚠️ IMPORTANT: RDS Dependency Note
  # - RDS is created in T5 (RDS PostgreSQL Migration)
  # - If you haven't completed T5 yet, the host field will be empty (that's OK)
  # - After creating RDS in T5, run terraform apply again to update the secret with the RDS endpoint
  # - The try() function handles missing RDS gracefully (no error if RDS doesn't exist)

  # Explicit dependency: Ensure RDS instance exists (if it does) before creating secret version
  # This ensures secret contains the correct RDS endpoint
  depends_on = [aws_db_instance.postgres]

  # Note: Removed ignore_changes to allow Terraform to update secret when RDS endpoint changes
  # If you manually change the secret, Terraform will overwrite it on next apply
  # This ensures state consistency and prevents "resource already exists" errors
}

# API Keys Secret (example - for external APIs)
resource "aws_secretsmanager_secret" "api_keys" {
  name        = "${var.project_name}/api/keys"
  description = "External API keys for backend"

  lifecycle {
    prevent_destroy = false # Temporarily disabled for destroy
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-api-keys"
      Task = "T9"
    }
  )
}

# API Keys Secret Version (example)
resource "aws_secretsmanager_secret_version" "api_keys" {
  secret_id = aws_secretsmanager_secret.api_keys.id

  secret_string = jsonencode({
    external_api_key    = "your-api-key-here" # ⚠️ Replace with actual key
    payment_gateway_key = "your-payment-key"  # ⚠️ Replace with actual key
  })

  # Note: Removed ignore_changes to allow Terraform to manage secret values
  # If you manually change the secret, Terraform will overwrite it on next apply
  # This ensures state consistency and prevents "resource already exists" errors
  # To prevent overwrites, set actual values in terraform.tfvars and use variables
}

# IAM Policy for EKS Pods to access Secrets Manager
# This allows backend Pods to retrieve secrets
resource "aws_iam_policy" "secrets_manager_access" {
  name        = "${local.name_prefix}-secrets-manager-access"
  description = "Allow EKS Pods to read secrets from Secrets Manager"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret"
        ]
        Resource = [
          aws_secretsmanager_secret.rds_password.arn,
          aws_secretsmanager_secret.api_keys.arn
        ]
      },
      {
        Effect = "Allow"
        Action = [
          "kms:Decrypt"
        ]
        Resource = "*" # KMS key for Secrets Manager encryption
        Condition = {
          StringEquals = {
            "kms:ViaService" = "secretsmanager.${var.aws_region}.amazonaws.com"
          }
        }
      }
    ]
  })

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-secrets-manager-policy"
      Task = "T9"
    }
  )
}

# Attach policy to EKS node role (for Pods to access secrets)
# ⚠️ For production, use IRSA (IAM Roles for Service Accounts) instead
# This is a simplified approach for learning
# Note: aws_iam_role.eks_nodes is created in T3 (EKS Cluster task)
resource "aws_iam_role_policy_attachment" "secrets_manager_access" {
  role       = aws_iam_role.eks_nodes.name # From T3 (EKS node role)
  policy_arn = aws_iam_policy.secrets_manager_access.arn
}

# Output: Secret ARNs (for reference)
output "rds_password_secret_arn" {
  description = "ARN of the RDS password secret"
  value       = aws_secretsmanager_secret.rds_password.arn
  sensitive   = true
}

output "api_keys_secret_arn" {
  description = "ARN of the API keys secret"
  value       = aws_secretsmanager_secret.api_keys.arn
  sensitive   = true
}

